# RecentsMod — In-card collapsible actions

## UI changes
- Kept the existing overlapping Recents carousel controller and native TaskView/PagedView ownership.
- Removed the always-visible action rows from the default card state.
- Added a small centered chevron pill inside the bottom area of each task card.
- Tapping the chevron reveals the existing Split Screen, App Info, and Force Stop controls inside a translucent rounded panel at the bottom of that same card.
- Tapping the chevron again collapses the panel; changing the bound task rebuilds the action footer in its collapsed state.
- Reduced the thumbnail's bottom reservation to make room for the embedded chevron. The expanded action panel overlays the lower part of the preview rather than changing carousel page geometry.
- Added short alpha/vertical transitions for opening and closing the action panel.

## PagedView index repair retained
The supplied crash trace showed `PagedView.getPageScrolls()` indexing page 8 in an array of length 8 during `RecentsView.createTaskDismissAnimation()`. The prior custom page-count/filter/max-scroll changes remain removed so native Launcher page indexing stays consistent.

## Known limitations
- Full Android build and on-device interaction have not been run in this environment.
- Force Stop still stops the package only when the privileged permission is actually granted; removing its card from Recents remains unverified.
- Carousel appearance, swipe gestures, and panel positioning must be checked on the target Android 10 device after installing a successful build.
