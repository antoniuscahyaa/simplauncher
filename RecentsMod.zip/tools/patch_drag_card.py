#!/usr/bin/env python3
"""Patch smali: saat memindahkan (drag) aplikasi di homescreen, yang ikut bergerak adalah KARTU, bukan ikon.

Pemakaian: patch_drag_card.py <folder_decoded>

Bawaan Launcher3 menggambar drag preview BubbleTextView hanya dari ikonnya (getIcon()) dengan ukuran ikon.
Kartu homescreen berupa teks tanpa ikon, jadi yang tampak saat drag adalah ikon icon pack. Perubahan:
 1. DragPreviewProvider.createDragBitmap: untuk view kartu (HomeCards.isCardView) pakai jalur umum
    (ukuran = seluruh view).
 2. DragPreviewProvider.drawDragView: untuk view kartu gambar view-nya (latar kartu + nama), bukan ikon.
 3. BubbleTextView.getIconBounds(View,Rect,int): untuk view kartu = seluruh view, sehingga dragRect,
    offset dan outline tempat jatuh sesuai ukuran kartu.
Idempoten; gagal keras bila pola smali tidak cocok.
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_smali(class_path):
    hits = [os.path.join(d, class_path + ".smali") for d in glob.glob(os.path.join(work, "smali*"))
            if os.path.isfile(os.path.join(d, class_path + ".smali"))]
    if len(hits) != 1:
        die("smali %s ditemukan %d kali" % (class_path, len(hits)))
    return hits[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def method_span(src, header_regex, label):
    m = re.search(r"(?ms)^\.method " + header_regex + r"[^\n]*\n.*?^\.end method", src)
    if not m:
        die("method tidak ditemukan: " + label)
    return m


IS_CARD = "Lsimp/home/HomeCards;->isCardView(Landroid/view/View;)Z"
dpp = find_smali("com/android/launcher3/graphics/DragPreviewProvider")
src = read(dpp)

# ---- 1. createDragBitmap ----
if "# simp: kartu -> jalur umum (createDragBitmap)" in src:
    print("sudah dipatch: DragPreviewProvider.createDragBitmap")
else:
    m = method_span(src, r"public createDragBitmap\(\)Landroid/graphics/Bitmap;", "createDragBitmap")
    body = m.group(0)
    pat = re.compile(r"(    instance-of v3, v2, Lcom/android/launcher3/BubbleTextView;\s+)(    if-eqz v3, :cond_0\n)")
    if len(pat.findall(body)) != 1:
        die("createDragBitmap: pola instance-of BubbleTextView tidak cocok (%d)" % len(pat.findall(body)))
    ins = ("    # simp: kartu -> jalur umum (createDragBitmap)\n"
           "    if-eqz v3, :cond_0\n\n"
           "    invoke-static {v2}, " + IS_CARD + "\n\n"
           "    move-result v3\n\n"
           "    if-nez v3, :cond_0\n\n")
    body2 = pat.sub(lambda mm: mm.group(1) + ins, body, count=1)
    # baris if-eqz v3 asli dihapus (diganti ins); jalur normal lanjut ke blok BubbleTextView
    src = src[:m.start()] + body2 + src[m.end():]
    write(dpp, src)
    print("dipatch: DragPreviewProvider.createDragBitmap")

# ---- 2. drawDragView ----
src = read(dpp)
if "# simp: kartu -> gambar view (drawDragView)" in src:
    print("sudah dipatch: DragPreviewProvider.drawDragView")
else:
    m = method_span(src, r"protected drawDragView\(Landroid/graphics/Canvas;F\)V", "drawDragView")
    body = m.group(0)
    pat = re.compile(r"(    instance-of v0, p2, Lcom/android/launcher3/BubbleTextView;\s+)(    if-eqz v0, :cond_1\n)")
    if len(pat.findall(body)) != 1:
        die("drawDragView: pola instance-of BubbleTextView tidak cocok (%d)" % len(pat.findall(body)))
    ins = ("    # simp: kartu -> gambar view (drawDragView)\n"
           "    if-eqz v0, :cond_1\n\n"
           "    invoke-static {p2}, " + IS_CARD + "\n\n"
           "    move-result v0\n\n"
           "    if-nez v0, :cond_1\n\n")
    body2 = pat.sub(lambda mm: mm.group(1) + ins, body, count=1)
    write(dpp, src[:m.start()] + body2 + src[m.end():])
    print("dipatch: DragPreviewProvider.drawDragView")

# ---- 3. BubbleTextView.getIconBounds(View, Rect, int) ----
btv = find_smali("com/android/launcher3/BubbleTextView")
src = read(btv)
if "# simp: kartu -> batas = seluruh view" in src:
    print("sudah dipatch: BubbleTextView.getIconBounds")
else:
    m = method_span(src, r"public static getIconBounds\(Landroid/view/View;Landroid/graphics/Rect;I\)V", "getIconBounds")
    body = m.group(0)
    mm = re.match(r"(\.method[^\n]*\n\s*\.locals )(\d+)(\n)", body)
    if not mm:
        die("getIconBounds: .locals tidak cocok")
    locals_n = max(int(mm.group(2)), 2)
    ins = ("\n    # simp: kartu -> batas = seluruh view\n"
           "    invoke-static {p0}, " + IS_CARD + "\n\n"
           "    move-result v0\n\n"
           "    if-eqz v0, :simp_not_card\n\n"
           "    const/4 v0, 0x0\n\n"
           "    invoke-virtual {p0}, Landroid/view/View;->getWidth()I\n\n"
           "    move-result v1\n\n"
           "    invoke-virtual {p0}, Landroid/view/View;->getHeight()I\n\n"
           "    move-result p2\n\n"
           "    invoke-virtual {p1, v0, v0, v1, p2}, Landroid/graphics/Rect;->set(IIII)V\n\n"
           "    return-void\n\n"
           "    :simp_not_card\n")
    rest = body[mm.end():]
    body2 = mm.group(1) + str(locals_n) + mm.group(3) + ins + rest
    write(btv, src[:m.start()] + body2 + src[m.end():])
    print("dipatch: BubbleTextView.getIconBounds")

print("patch_drag_card selesai")
