package simp.launcher.app

import android.Manifest
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(val label: String, val component: ComponentName) {
    val key: String get() = component.flattenToShortString()
    val packageName: String get() = component.packageName
}

data class WidgetOption(val label: String, val appLabel: String, val info: AppWidgetProviderInfo)

/** Semua state launcher + penyimpanan sederhana (SharedPreferences). */
class LauncherState(private val ctx: Context) {

    private val sp = ctx.getSharedPreferences("simp_launcher", Context.MODE_PRIVATE)
    private val iconCache = HashMap<String, ImageBitmap>()
    private var wallpaperId = -2

    val widgetHost = AppWidgetHost(ctx, 1024)

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set
    var columns by mutableIntStateOf(sp.getInt("columns", 3).coerceIn(3, 4))
        private set
    var rows by mutableIntStateOf(sp.getInt("rows", 4).coerceIn(2, 8))
        private set
    var cardAlpha by mutableFloatStateOf(sp.getFloat("cardAlpha", 0.62f).coerceIn(0.2f, 0.95f))
        private set
    var blurLevel by mutableIntStateOf(sp.getInt("blurLevel", 2).coerceIn(0, 3))
        private set
    var blurDrawerBg by mutableStateOf(sp.getBoolean("blurDrawerBg", true))
        private set
    var autoText by mutableStateOf(sp.getBoolean("autoText", true))
        private set
    var widgetId by mutableIntStateOf(sp.getInt("widgetId", -1))
        private set
    var pinned by mutableStateOf(readList("pinned"))
        private set
    var recents by mutableStateOf(readList("recents"))
        private set
    var spans by mutableStateOf(readSpans())
        private set

    /** Ukuran layar (piksel), diisi dari root UI. */
    var screen by mutableStateOf(IntSize.Zero)

    /** Wallpaper yang sudah diblur; null = belum ada izin / tidak bisa dibaca. */
    var glass by mutableStateOf<WallpaperGlass?>(null)
        private set

    val pinnedApps: List<AppEntry>
        get() = pinned.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    val recentApps: List<AppEntry>
        get() = recents.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    val hasWallpaperPermission: Boolean
        get() = ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun readList(k: String): List<String> =
        sp.getString(k, null)?.split("|")?.filter { it.isNotEmpty() } ?: emptyList()

    private fun writeList(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("|")).apply()
    }

    private fun readSpans(): Map<String, Int> {
        val raw = sp.getString("spans", null) ?: return emptyMap()
        val out = HashMap<String, Int>()
        for (s in raw.split("|")) {
            val p = s.split("=")
            if (p.size == 2) {
                val n = p[1].toIntOrNull()
                if (n != null) out[p[0]] = n
            }
        }
        return out
    }

    fun reload() {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppEntry(
                    it.loadLabel(pm).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
        if (!sp.contains("pinned")) {
            pinned = apps.take(12).map { it.key }
            writeList("pinned", pinned)
        }
        if (widgetId != -1 && AppWidgetManager.getInstance(ctx).getAppWidgetInfo(widgetId) == null) {
            widgetId = -1
            sp.edit().putInt("widgetId", -1).apply()
        }
    }

    // ---- Wallpaper (blur + teks otomatis) ----

    fun loadWallpaper(force: Boolean = false) {
        if (!hasWallpaperPermission) {
            glass = null
            return
        }
        val id = try {
            WallpaperManager.getInstance(ctx).getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (t: Exception) {
            -1
        }
        if (!force && id == wallpaperId) return
        wallpaperId = id
        Thread {
            val g = WallpaperGlass.load(ctx)
            Handler(Looper.getMainLooper()).post { glass = g }
        }.start()
    }

    // ---- Pengaturan ----

    fun updateColumns(v: Int) {
        columns = v.coerceIn(3, 4)
        sp.edit().putInt("columns", columns).apply()
    }

    fun updateRows(v: Int) {
        rows = v.coerceIn(2, 8)
        sp.edit().putInt("rows", rows).apply()
    }

    fun updateCardAlpha(v: Float) {
        cardAlpha = v.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("cardAlpha", cardAlpha).apply()
    }

    fun updateBlurLevel(v: Int) {
        blurLevel = v.coerceIn(0, 3)
        sp.edit().putInt("blurLevel", blurLevel).apply()
    }

    fun updateBlurDrawerBg(v: Boolean) {
        blurDrawerBg = v
        sp.edit().putBoolean("blurDrawerBg", v).apply()
    }

    fun updateAutoText(v: Boolean) {
        autoText = v
        sp.edit().putBoolean("autoText", v).apply()
    }

    // ---- Kartu di homescreen ----

    fun pin(e: AppEntry) {
        if (e.key !in pinned) {
            pinned = pinned + e.key
            writeList("pinned", pinned)
        }
    }

    fun unpin(e: AppEntry) {
        pinned = pinned - e.key
        writeList("pinned", pinned)
    }

    fun span(e: AppEntry): Int = (spans[e.key] ?: 1).coerceIn(1, columns)

    fun setSpan(e: AppEntry, s: Int) {
        spans = spans + (e.key to s)
        sp.edit().putString("spans", spans.entries.joinToString("|") { it.key + "=" + it.value }).apply()
    }

    // ---- Widget ----

    fun widgetOptions(): List<WidgetOption> {
        val pm = ctx.packageManager
        return AppWidgetManager.getInstance(ctx).installedProviders.map { p ->
            val appLabel = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (t: Exception) {
                p.provider.packageName
            }
            val label = try {
                p.loadLabel(pm) ?: appLabel
            } catch (t: Exception) {
                appLabel
            }
            WidgetOption(label, appLabel, p)
        }.sortedBy { it.appLabel.lowercase() }
    }

    fun setWidget(id: Int) {
        if (widgetId != -1 && widgetId != id) widgetHost.deleteAppWidgetId(widgetId)
        widgetId = id
        sp.edit().putInt("widgetId", id).apply()
    }

    fun removeWidget() {
        if (widgetId != -1) widgetHost.deleteAppWidgetId(widgetId)
        widgetId = -1
        sp.edit().putInt("widgetId", -1).apply()
    }

    // ---- Ikon dan peluncuran ----

    fun icon(e: AppEntry): ImageBitmap = iconCache.getOrPut(e.key) {
        val d = try {
            ctx.packageManager.getActivityIcon(e.component)
        } catch (t: Exception) {
            ctx.packageManager.defaultActivityIcon
        }
        d.toBitmap(96, 96).asImageBitmap()
    }

    fun launch(e: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
            return
        }
        recents = (listOf(e.key) + recents.filter { it != e.key }).take(3)
        writeList("recents", recents)
    }

    fun openInfo(e: AppEntry) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }

    fun uninstall(e: AppEntry) {
        val i = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }
}
