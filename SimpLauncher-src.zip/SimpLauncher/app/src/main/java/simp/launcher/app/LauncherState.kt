package simp.launcher.app

import android.Manifest
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntSize
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONObject

data class AppEntry(val label: String, val component: ComponentName) {
    val key: String get() = component.flattenToShortString()
    val packageName: String get() = component.packageName
}

/** Kartu yang sudah ditempatkan di grid homescreen (baris/kolom mulai dari 0). */
data class Placed(val entry: AppEntry, val row: Int, val col: Int, val span: Int)

data class WidgetOption(val label: String, val appLabel: String, val info: AppWidgetProviderInfo)

/** Semua state launcher + penyimpanan sederhana (SharedPreferences). */
class LauncherState(private val ctx: Context) {

    private val sp = ctx.getSharedPreferences("simp_launcher", Context.MODE_PRIVATE)
    private val iconCache = HashMap<String, ImageBitmap>()
    private var wallpaperId = -2
    private var packMap: Map<String, String> = emptyMap()

    val widgetHost = AppWidgetHost(ctx, 1024)

    val accentColors = listOf(
        Color(0xFF2D73A6), Color(0xFF1E8E6E), Color(0xFFE07A3F),
        Color(0xFFB5456B), Color(0xFF7A5BC0), Color(0xFF14243A)
    )

    // ---- Layar utama ----
    val columns = IntPref(sp, "columns", 3, 3, 4)
    val rows = IntPref(sp, "rows", 4, 2, 8)
    val gridAlign = IntPref(sp, "gridAlign", 0, 0, 1)          // 0 bawah, 1 atas
    val cardHeight = IntPref(sp, "cardHeight", 52, 40, 72)
    val cardGap = IntPref(sp, "cardGap", 10, 4, 16)
    val cardRadius = IntPref(sp, "cardRadius", 16, 6, 26)
    val labelScale = IntPref(sp, "labelScale", 100, 80, 130)
    val textAlign = IntPref(sp, "textAlign", 0, 0, 1)          // 0 tengah, 1 kiri
    val showDate = BoolPref(sp, "showDate", true)
    val lockLayout = BoolPref(sp, "lockLayout", false)
    val moveByDrag = BoolPref(sp, "moveByDrag", true)
    val widgetScale = IntPref(sp, "widgetScale", 25, 10, 40)   // kelipatan tinggi widget, dalam persepuluhan (25 = 2,5x)

    // ---- Tampilan ----
    val cardStyle = IntPref(sp, "cardStyle", 0, 0, 1)          // 0 terang, 1 gelap
    val accent = IntPref(sp, "accent", 0, 0, 5)
    val cardAlpha = FloatPref(sp, "cardAlpha", 0.62f, 0.2f, 0.95f)
    val blurLevel = IntPref(sp, "blurLevel", 2, 0, 3)
    val blurDrawerBg = BoolPref(sp, "blurDrawerBg", true)
    val autoText = BoolPref(sp, "autoText", true)

    // ---- Ikon ----
    val iconShape = IntPref(sp, "iconShape", 0, 0, 3)          // 0 rounded, 1 lingkaran, 2 persegi, 3 asli
    val iconSize = IntPref(sp, "iconSize", 36, 28, 44)

    // ---- Drawer ----
    val drawerColumns = IntPref(sp, "drawerColumns", 3, 2, 4)
    val recentCount = IntPref(sp, "recentCount", 3, 0, 3)
    val sheetHeight = IntPref(sp, "sheetHeight", 78, 55, 95)
    val drawerScrollBar = BoolPref(sp, "drawerScrollBar", true)
    val autoKeyboard = BoolPref(sp, "autoKeyboard", false)

    // ---- Menu tekan lama ----
    val menuHomeInfo = BoolPref(sp, "menuHomeInfo", true)
    val menuHomeResize = BoolPref(sp, "menuHomeResize", true)
    val menuHomeRemove = BoolPref(sp, "menuHomeRemove", true)
    val menuHomeUninstall = BoolPref(sp, "menuHomeUninstall", true)
    val menuDrawerPin = BoolPref(sp, "menuDrawerPin", true)
    val menuDrawerInfo = BoolPref(sp, "menuDrawerInfo", true)
    val menuDrawerUninstall = BoolPref(sp, "menuDrawerUninstall", true)

    // ---- Gesture ----
    val gSwipeUp = IntPref(sp, "gSwipeUp", 1, 0, 1)            // 0 tidak ada, 1 drawer
    val gSwipeDown = IntPref(sp, "gSwipeDown", 1, 0, 1)        // 0 tidak ada, 1 panel notifikasi
    val gDoubleTap = IntPref(sp, "gDoubleTap", 0, 0, 2)        // 0 tidak ada, 1 pengaturan, 2 drawer
    val gLongPress = IntPref(sp, "gLongPress", 1, 0, 1)        // 0 tidak ada, 1 pengaturan

    // ---- Sistem ----
    val hideStatusBar = BoolPref(sp, "hideStatusBar", false)

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set
    var widgetId by mutableIntStateOf(sp.getInt("widgetId", -1))
        private set
    var pinned by mutableStateOf(readList("pinned"))
        private set
    var recents by mutableStateOf(readList("recents"))
        private set
    var hidden by mutableStateOf(readList("hidden"))
        private set
    var spans by mutableStateOf(readSpans())
        private set
    var positions by mutableStateOf(readPositions())
        private set
    var iconPack by mutableStateOf(sp.getString("iconPack", "") ?: "")
        private set
    var iconRev by mutableIntStateOf(0)
        private set

    /** Ukuran layar (piksel), diisi dari root UI. */
    var screen by mutableStateOf(IntSize.Zero)

    /** Wallpaper yang sudah diblur; null = belum ada izin / tidak bisa dibaca. */
    var glass by mutableStateOf<WallpaperGlass?>(null)
        private set

    init {
        applyIconPack()
    }

    val accentColor: Color
        get() = accentColors[accent.value.coerceIn(0, accentColors.size - 1)]

    val tintColor: Color
        get() = if (cardStyle.value == 1) Color(0xFF0E1A2A) else Color.White

    val tintLuma: Float
        get() = if (cardStyle.value == 1) 0.08f else 1f

    val baseText: Color
        get() = if (cardStyle.value == 1) Color.White else Color(0xFF14243A)

    val pinnedApps: List<AppEntry>
        get() = pinned.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    val recentApps: List<AppEntry>
        get() = recents.mapNotNull { k -> apps.firstOrNull { it.key == k } }.take(recentCount.value)

    val drawerApps: List<AppEntry>
        get() = apps.filter { it.key !in hidden }

    val hasWallpaperPermission: Boolean
        get() = ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun readList(k: String): List<String> =
        sp.getString(k, null)?.split("|")?.filter { it.isNotEmpty() } ?: emptyList()

    private fun writeList(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("|")).apply()
    }

    private fun readSpans(): Map<String, Int> {
        val raw = sp.getString("spans", null) ?: return emptyMap()
        val out = HashMap<String, Int>()
        for (s in raw.split("|")) {
            val p = s.split("=")
            if (p.size == 2) {
                val n = p[1].toIntOrNull()
                if (n != null) out[p[0]] = n
            }
        }
        return out
    }

    private fun readPositions(): Map<String, Pair<Int, Int>> {
        val raw = sp.getString("positions", null) ?: return emptyMap()
        val out = HashMap<String, Pair<Int, Int>>()
        for (s in raw.split("|")) {
            val p = s.split("=")
            if (p.size != 2) continue
            val rc = p[1].split(",")
            if (rc.size != 2) continue
            val r = rc[0].toIntOrNull()
            val c = rc[1].toIntOrNull()
            if (r != null && c != null) out[p[0]] = r to c
        }
        return out
    }

    private fun savePositions(map: Map<String, Pair<Int, Int>>) {
        positions = map
        sp.edit().putString(
            "positions",
            map.entries.joinToString("|") { it.key + "=" + it.value.first + "," + it.value.second }
        ).apply()
    }

    fun reload() {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppEntry(
                    it.loadLabel(pm).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
        if (!sp.contains("pinned")) {
            pinned = apps.take(12).map { it.key }
            writeList("pinned", pinned)
        }
        if (widgetId != -1 && AppWidgetManager.getInstance(ctx).getAppWidgetInfo(widgetId) == null) {
            widgetId = -1
            sp.edit().putInt("widgetId", -1).apply()
        }
    }

    // ---- Wallpaper (blur + teks otomatis) ----

    fun loadWallpaper(force: Boolean = false) {
        if (!hasWallpaperPermission) {
            glass = null
            return
        }
        val id = try {
            WallpaperManager.getInstance(ctx).getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (t: Exception) {
            -1
        }
        if (!force && id == wallpaperId) return
        wallpaperId = id
        Thread {
            val g = WallpaperGlass.load(ctx)
            Handler(Looper.getMainLooper()).post { glass = g }
        }.start()
    }

    // ---- Kartu di homescreen ----

    fun pin(e: AppEntry) {
        if (e.key !in pinned) {
            pinned = pinned + e.key
            writeList("pinned", pinned)
        }
    }

    fun unpin(e: AppEntry) {
        pinned = pinned - e.key
        writeList("pinned", pinned)
        if (positions.containsKey(e.key)) savePositions(positions - e.key)
    }

    fun span(e: AppEntry): Int = (spans[e.key] ?: 1).coerceIn(1, columns.value)

    fun setSpan(e: AppEntry, s: Int) {
        val cols = columns.value
        val ns = s.coerceIn(1, cols)
        val cur = gridLayout()
        val me = cur.firstOrNull { it.entry.key == e.key }
        if (me != null) {
            // Tetap di tempat bila muat; kalau bentrok, cari ruang kosong terdekat. Tidak ada ruang = batal.
            val occ = occupancyOf(cur, setOf(e.key))
            var r = me.row
            var c = me.col.coerceAtMost(cols - ns)
            if (!cellsFree(occ, r, c, ns)) {
                val idx = findSpot(occ, ns, me.row * cols + me.col)
                if (idx == -1) return
                r = idx / cols
                c = idx % cols
            }
            val m = HashMap<String, Pair<Int, Int>>(positions)
            for (p in cur) m[p.entry.key] = p.row to p.col
            m[e.key] = r to c
            savePositions(m)
        }
        spans = spans + (e.key to ns)
        sp.edit().putString("spans", spans.entries.joinToString("|") { it.key + "=" + it.value }).apply()
    }

    // ---- Grid homescreen: posisi kartu ----

    private fun occupancyOf(list: List<Placed>, skip: Set<String> = emptySet()): Array<BooleanArray> {
        val occ = Array(rows.value) { BooleanArray(columns.value) }
        for (p in list) if (p.entry.key !in skip) markCells(occ, p.row, p.col, p.span)
        return occ
    }

    private fun cellsFree(occ: Array<BooleanArray>, r: Int, c: Int, s: Int): Boolean {
        if (occ.isEmpty() || r < 0 || r >= occ.size || c < 0 || c + s > occ[0].size) return false
        for (i in c until c + s) if (occ[r][i]) return false
        return true
    }

    private fun markCells(occ: Array<BooleanArray>, r: Int, c: Int, s: Int) {
        for (i in c until c + s) occ[r][i] = true
    }

    /** Indeks sel (baris * kolom + kolom) pertama yang muat untuk [s] kolom, mulai dari [from] lalu berputar. */
    private fun findSpot(occ: Array<BooleanArray>, s: Int, from: Int): Int {
        val cols = occ[0].size
        val total = occ.size * cols
        for (n in 0 until total) {
            val i = (from + n) % total
            if (cellsFree(occ, i / cols, i % cols, s)) return i
        }
        return -1
    }

    /**
     * Posisi akhir semua kartu. Kartu dengan posisi tersimpan yang masih valid ditaruh di sana;
     * sisanya diisi berurutan dari kiri-atas (sama seperti susunan lama), melewati sel terpakai.
     */
    fun gridLayout(): List<Placed> {
        val cols = columns.value
        val total = rows.value * cols
        val occ = Array(rows.value) { BooleanArray(cols) }
        val out = ArrayList<Placed>()
        val auto = ArrayList<AppEntry>()
        for (e in pinnedApps) {
            val s = span(e)
            val p = positions[e.key]
            if (p != null && cellsFree(occ, p.first, p.second, s)) {
                markCells(occ, p.first, p.second, s)
                out.add(Placed(e, p.first, p.second, s))
            } else {
                auto.add(e)
            }
        }
        var cursor = 0
        for (e in auto) {
            val s = span(e)
            var i = cursor
            while (i < total && !cellsFree(occ, i / cols, i % cols, s)) i++
            if (i >= total) continue
            markCells(occ, i / cols, i % cols, s)
            out.add(Placed(e, i / cols, i % cols, s))
            cursor = i + s
        }
        return out
    }

    /**
     * Pindahkan kartu ke sel (row, col). Sel kosong: pindah. Terisi satu kartu: tukar posisi
     * bila muat. Di luar batas grid dijepit ke tepi. Mengembalikan true bila ada perubahan.
     */
    fun moveCard(e: AppEntry, row: Int, col: Int): Boolean {
        if (lockLayout.value) return false
        val cur = gridLayout()
        val me = cur.firstOrNull { it.entry.key == e.key } ?: return false
        val cols = columns.value
        val r = row.coerceIn(0, rows.value - 1)
        val c = col.coerceIn(0, cols - me.span)
        if (r == me.row && c == me.col) return false
        val hit = cur.filter { o ->
            o.entry.key != e.key && o.row == r && o.col < c + me.span && c < o.col + o.span
        }
        val m = HashMap<String, Pair<Int, Int>>(positions)
        for (p in cur) m[p.entry.key] = p.row to p.col
        when (hit.size) {
            0 -> m[e.key] = r to c
            1 -> {
                val x = hit[0]
                val xc = me.col.coerceAtMost(cols - x.span)
                val occ = occupancyOf(cur, setOf(e.key, x.entry.key))
                markCells(occ, r, c, me.span)
                if (!cellsFree(occ, me.row, xc, x.span)) return false
                m[e.key] = r to c
                m[x.entry.key] = me.row to xc
            }
            else -> return false
        }
        savePositions(m)
        return true
    }

    fun resetPositions() {
        savePositions(emptyMap())
    }

    fun setHidden(e: AppEntry, h: Boolean) {
        hidden = if (h) (hidden + e.key).distinct() else hidden - e.key
        writeList("hidden", hidden)
    }

    // ---- Icon pack ----

    @JvmName("chooseIconPack")
    fun setIconPack(pkg: String) {
        iconPack = pkg
        sp.edit().putString("iconPack", pkg).apply()
        applyIconPack()
    }

    private fun applyIconPack() {
        iconCache.clear()
        packMap = emptyMap()
        if (iconPack.isEmpty()) {
            iconRev += 1
            return
        }
        val pkg = iconPack
        Thread {
            val m = IconPacks.loadMap(ctx, pkg)
            Handler(Looper.getMainLooper()).post {
                packMap = m
                iconCache.clear()
                iconRev += 1
            }
        }.start()
    }

    fun iconPackLabel(): String {
        if (iconPack.isEmpty()) return "Bawaan sistem"
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(iconPack, 0)).toString()
        } catch (t: Exception) {
            iconPack
        }
    }

    // ---- Widget ----

    fun widgetOptions(): List<WidgetOption> {
        val pm = ctx.packageManager
        return AppWidgetManager.getInstance(ctx).installedProviders.map { p ->
            val appLabel = try {
                pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString()
            } catch (t: Exception) {
                p.provider.packageName
            }
            val label = try {
                p.loadLabel(pm) ?: appLabel
            } catch (t: Exception) {
                appLabel
            }
            WidgetOption(label, appLabel, p)
        }.sortedBy { it.appLabel.lowercase() }
    }

    fun setWidget(id: Int) {
        if (widgetId != -1 && widgetId != id) widgetHost.deleteAppWidgetId(widgetId)
        widgetId = id
        sp.edit().putInt("widgetId", id).apply()
    }

    fun removeWidget() {
        if (widgetId != -1) widgetHost.deleteAppWidgetId(widgetId)
        widgetId = -1
        sp.edit().putInt("widgetId", -1).apply()
    }

    // ---- Cadangan ----

    fun exportTo(uri: Uri): Boolean {
        return try {
            val o = JSONObject()
            for ((k, v) in sp.all) {
                if (k == "widgetId") continue
                when (v) {
                    is Boolean -> o.put("b:$k", v)
                    is Int -> o.put("i:$k", v)
                    is Float -> o.put("f:$k", v.toDouble())
                    is String -> o.put("s:$k", v)
                    else -> {}
                }
            }
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(o.toString(2).toByteArray()) }
            true
        } catch (t: Exception) {
            false
        }
    }

    fun importFrom(uri: Uri): Boolean {
        return try {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: return false
            val o = JSONObject(text)
            val ed = sp.edit()
            val it = o.keys()
            while (it.hasNext()) {
                val full = it.next()
                val tag = full.substringBefore(':')
                val key = full.substringAfter(':')
                when (tag) {
                    "b" -> ed.putBoolean(key, o.getBoolean(full))
                    "i" -> ed.putInt(key, o.getInt(full))
                    "f" -> ed.putFloat(key, o.getDouble(full).toFloat())
                    "s" -> ed.putString(key, o.getString(full))
                }
            }
            ed.commit()
        } catch (t: Exception) {
            false
        }
    }

    fun resetAll() {
        sp.edit().clear().commit()
    }

    // ---- Ikon dan peluncuran ----

    fun icon(e: AppEntry): ImageBitmap = iconCache.getOrPut(e.key) {
        val packName = packMap[e.component.packageName + "/" + e.component.className]
        val fromPack = if (packName != null) IconPacks.drawable(ctx, iconPack, packName) else null
        val d = fromPack ?: try {
            ctx.packageManager.getActivityIcon(e.component)
        } catch (t: Exception) {
            ctx.packageManager.defaultActivityIcon
        }
        d.toBitmap(96, 96).asImageBitmap()
    }

    fun launch(e: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
            return
        }
        recents = (listOf(e.key) + recents.filter { it != e.key }).take(3)
        writeList("recents", recents)
    }

    fun openInfo(e: AppEntry) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }

    fun uninstall(e: AppEntry) {
        val i = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }

    /** Buka panel notifikasi (refleksi; butuh izin EXPAND_STATUS_BAR). */
    fun expandNotifications() {
        try {
            val sbs = ctx.getSystemService("statusbar")
            sbs?.javaClass?.getMethod("expandNotificationsPanel")?.invoke(sbs)
        } catch (t: Throwable) {
        }
    }
}
