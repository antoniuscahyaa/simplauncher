package simp.launcher.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(val label: String, val component: ComponentName) {
    val key: String get() = component.flattenToShortString()
    val packageName: String get() = component.packageName
}

/** Semua state launcher + penyimpanan sederhana (SharedPreferences). */
class LauncherState(private val ctx: Context) {

    private val sp = ctx.getSharedPreferences("simp_launcher", Context.MODE_PRIVATE)
    private val iconCache = HashMap<String, ImageBitmap>()

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set
    var columns by mutableIntStateOf(sp.getInt("columns", 3).coerceIn(3, 4))
        private set
    var rows by mutableIntStateOf(sp.getInt("rows", 4).coerceIn(2, 8))
        private set
    var cardAlpha by mutableFloatStateOf(sp.getFloat("cardAlpha", 0.62f).coerceIn(0.2f, 0.95f))
        private set
    var pinned by mutableStateOf(readList("pinned"))
        private set
    var recents by mutableStateOf(readList("recents"))
        private set

    val pinnedApps: List<AppEntry>
        get() = pinned.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    val recentApps: List<AppEntry>
        get() = recents.mapNotNull { k -> apps.firstOrNull { it.key == k } }

    private fun readList(k: String): List<String> =
        sp.getString(k, null)?.split("|")?.filter { it.isNotEmpty() } ?: emptyList()

    private fun writeList(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("|")).apply()
    }

    fun reload() {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map {
                AppEntry(
                    it.loadLabel(pm).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
        if (!sp.contains("pinned")) {
            pinned = apps.take(12).map { it.key }
            writeList("pinned", pinned)
        }
    }

    fun updateColumns(v: Int) {
        columns = v.coerceIn(3, 4)
        sp.edit().putInt("columns", columns).apply()
    }

    fun updateRows(v: Int) {
        rows = v.coerceIn(2, 8)
        sp.edit().putInt("rows", rows).apply()
    }

    fun updateCardAlpha(v: Float) {
        cardAlpha = v.coerceIn(0.2f, 0.95f)
        sp.edit().putFloat("cardAlpha", cardAlpha).apply()
    }

    fun pin(e: AppEntry) {
        if (e.key !in pinned) {
            pinned = pinned + e.key
            writeList("pinned", pinned)
        }
    }

    fun unpin(e: AppEntry) {
        pinned = pinned - e.key
        writeList("pinned", pinned)
    }

    fun icon(e: AppEntry): ImageBitmap = iconCache.getOrPut(e.key) {
        val d = try {
            ctx.packageManager.getActivityIcon(e.component)
        } catch (t: Exception) {
            ctx.packageManager.defaultActivityIcon
        }
        d.toBitmap(96, 96).asImageBitmap()
    }

    fun launch(e: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
            return
        }
        recents = (listOf(e.key) + recents.filter { it != e.key }).take(3)
        writeList("recents", recents)
    }

    fun openInfo(e: AppEntry) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }

    fun uninstall(e: AppEntry) {
        val i = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", e.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (t: Exception) {
        }
    }
}
