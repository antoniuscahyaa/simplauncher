package simp.launcher.app

import android.content.SharedPreferences
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf

/** Preferensi bertipe yang tersimpan di SharedPreferences dan menjadi state Compose. */
class IntPref(
    private val sp: SharedPreferences,
    private val key: String,
    def: Int,
    private val lo: Int,
    private val hi: Int
) {
    private val st = mutableIntStateOf(sp.getInt(key, def).coerceIn(lo, hi))

    var value: Int
        get() = st.intValue
        set(v) {
            val c = v.coerceIn(lo, hi)
            st.intValue = c
            sp.edit().putInt(key, c).apply()
        }
}

class FloatPref(
    private val sp: SharedPreferences,
    private val key: String,
    def: Float,
    private val lo: Float,
    private val hi: Float
) {
    private val st = mutableFloatStateOf(sp.getFloat(key, def).coerceIn(lo, hi))

    var value: Float
        get() = st.floatValue
        set(v) {
            val c = v.coerceIn(lo, hi)
            st.floatValue = c
            sp.edit().putFloat(key, c).apply()
        }
}

class BoolPref(
    private val sp: SharedPreferences,
    private val key: String,
    def: Boolean
) {
    private val st = mutableStateOf(sp.getBoolean(key, def))

    var value: Boolean
        get() = st.value
        set(v) {
            st.value = v
            sp.edit().putBoolean(key, v).apply()
        }
}
