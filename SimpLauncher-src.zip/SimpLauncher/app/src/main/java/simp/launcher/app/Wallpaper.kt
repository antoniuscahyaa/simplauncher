package simp.launcher.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.roundToInt

/**
 * Salinan wallpaper berukuran kecil + versi blur-nya.
 * Android 10 tidak punya blur bawaan (RenderEffect baru ada di Android 12),
 * jadi blur dibuat dari wallpaper yang diperkecil lalu digambar ulang di belakang kartu.
 */
class WallpaperGlass(
    private val base: Bitmap,
    private val levels: List<ImageBitmap>,
    val heavy: ImageBitmap
) {
    /** n = 1..3 */
    fun level(n: Int): ImageBitmap = levels[(n - 1).coerceIn(0, levels.size - 1)]

    /** Rata-rata keterangan (0..1) wallpaper pada area layar (pecahan 0..1). */
    fun luma(screen: IntSize, fx0: Float, fy0: Float, fx1: Float, fy1: Float): Float {
        if (screen.width <= 0 || screen.height <= 0) return 0.5f
        val bw = base.width
        val bh = base.height
        val scale = maxOf(screen.width / bw.toFloat(), screen.height / bh.toFloat())
        val dw = bw * scale
        val dh = bh * scale
        val dx = (screen.width - dw) / 2f
        val dy = (screen.height - dh) / 2f
        var sum = 0.0
        var n = 0
        for (i in 0 until 8) {
            for (j in 0 until 8) {
                val sx = (fx0 + (fx1 - fx0) * (i + 0.5f) / 8f) * screen.width
                val sy = (fy0 + (fy1 - fy0) * (j + 0.5f) / 8f) * screen.height
                val bx = ((sx - dx) / scale).toInt().coerceIn(0, bw - 1)
                val by = ((sy - dy) / scale).toInt().coerceIn(0, bh - 1)
                val c = base.getPixel(bx, by)
                val r = ((c shr 16) and 0xFF) / 255.0
                val g = ((c shr 8) and 0xFF) / 255.0
                val b = (c and 0xFF) / 255.0
                sum += 0.299 * r + 0.587 * g + 0.114 * b
                n++
            }
        }
        return (sum / n).toFloat()
    }

    companion object {
        /** Mengembalikan null kalau wallpaper tidak bisa dibaca (izin ditolak / live wallpaper). */
        fun load(ctx: Context): WallpaperGlass? {
            return try {
                val d = WallpaperManager.getInstance(ctx).drawable ?: return null
                val iw = d.intrinsicWidth
                val ih = d.intrinsicHeight
                if (iw <= 0 || ih <= 0) return null
                val h = 360
                val w = maxOf(8, (iw * (h / ih.toFloat())).roundToInt())
                val base = d.toBitmap(w, h)
                WallpaperGlass(
                    base = base,
                    levels = listOf(2, 5, 9).map { blur(base, it).asImageBitmap() },
                    heavy = blur(base, 14).asImageBitmap()
                )
            } catch (t: Throwable) {
                null
            }
        }
    }
}

/** Menggambar wallpaper (crop tengah, seperti sistem) pada layar; origin = posisi node di layar. */
fun DrawScope.drawWallpaperCrop(
    bmp: ImageBitmap,
    screen: IntSize,
    origin: Offset,
    alpha: Float = 1f
) {
    if (screen.width <= 0 || screen.height <= 0) return
    val scale = maxOf(screen.width / bmp.width.toFloat(), screen.height / bmp.height.toFloat())
    val dw = bmp.width * scale
    val dh = bmp.height * scale
    val dx = (screen.width - dw) / 2f
    val dy = (screen.height - dh) / 2f
    drawImage(
        image = bmp,
        dstOffset = IntOffset((dx - origin.x).roundToInt(), (dy - origin.y).roundToInt()),
        dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
        alpha = alpha
    )
}

private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
    val n = 2 * r + 1
    val lines = if (horizontal) h else w
    val len = if (horizontal) w else h
    for (line in 0 until lines) {
        for (i in 0 until len) {
            var rs = 0
            var gs = 0
            var bs = 0
            for (k in -r..r) {
                val j = (i + k).coerceIn(0, len - 1)
                val c = if (horizontal) src[line * w + j] else src[j * w + line]
                rs += (c shr 16) and 0xFF
                gs += (c shr 8) and 0xFF
                bs += c and 0xFF
            }
            val out = (0xFF shl 24) or ((rs / n) shl 16) or ((gs / n) shl 8) or (bs / n)
            if (horizontal) dst[line * w + i] = out else dst[i * w + line] = out
        }
    }
}

/** Blur kotak 3 kali (mendekati gaussian) pada bitmap kecil. */
private fun blur(src: Bitmap, r: Int): Bitmap {
    val w = src.width
    val h = src.height
    val a = IntArray(w * h)
    src.getPixels(a, 0, w, 0, 0, w, h)
    val b = IntArray(w * h)
    repeat(3) {
        blurPass(a, b, w, h, r, true)
        blurPass(b, a, w, h, r, false)
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(a, 0, w, 0, 0, w, h)
    return out
}
