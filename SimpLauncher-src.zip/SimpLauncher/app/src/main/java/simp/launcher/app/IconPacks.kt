package simp.launcher.app

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

/** Dukungan icon pack format ADW/Nova/Apex (appfilter.xml). */
object IconPacks {

    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "com.fede.launcher.THEME_ICONPACK",
        "com.gau.go.launcherex.theme"
    )

    data class Pack(val pkg: String, val label: String)

    fun list(ctx: Context): List<Pack> {
        val pm = ctx.packageManager
        val out = LinkedHashMap<String, Pack>()
        for (a in ACTIONS) {
            try {
                for (ri in pm.queryIntentActivities(Intent(a), 0)) {
                    val p = ri.activityInfo.packageName
                    out[p] = Pack(p, ri.loadLabel(pm).toString())
                }
            } catch (t: Exception) {
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    /** Peta "paket/kelas" -> nama drawable di icon pack. */
    fun loadMap(ctx: Context, pkg: String): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            val id = res.getIdentifier("appfilter", "xml", pkg)
            val parser: XmlPullParser = if (id != 0) {
                res.getXml(id)
            } else {
                val p = XmlPullParserFactory.newInstance().newPullParser()
                p.setInput(res.assets.open("appfilter.xml"), "UTF-8")
                p
            }
            var ev = parser.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null) {
                        val s = comp.indexOf('{')
                        val e = comp.indexOf('}')
                        if (s >= 0 && e > s) {
                            val parts = comp.substring(s + 1, e).split("/")
                            if (parts.size == 2) {
                                val cls = if (parts[1].startsWith(".")) parts[0] + parts[1] else parts[1]
                                val k = parts[0] + "/" + cls
                                if (!map.containsKey(k)) map[k] = dr
                            }
                        }
                    }
                }
                ev = parser.next()
            }
        } catch (t: Throwable) {
        }
        return map
    }

    fun drawable(ctx: Context, pkg: String, name: String): Drawable? {
        return try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            var id = res.getIdentifier(name, "drawable", pkg)
            if (id == 0) id = res.getIdentifier(name, "mipmap", pkg)
            if (id == 0) null else ResourcesCompat.getDrawable(res, id, null)
        } catch (t: Throwable) {
            null
        }
    }
}
