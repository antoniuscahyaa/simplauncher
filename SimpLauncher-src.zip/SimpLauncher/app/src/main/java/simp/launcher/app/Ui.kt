@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package simp.launcher.app

import android.appwidget.AppWidgetManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items as listItems

private val Navy = Color(0xFF14243A)
private val Danger = Color(0xFFB3261E)

data class MenuAction(
    val label: String,
    val danger: Boolean = false,
    val sub: List<MenuAction>? = null,
    val action: () -> Unit = {}
)

/** Tindakan yang harus dilakukan Activity (izin, widget). */
class Actions(
    val askWallpaperPermission: () -> Unit,
    val pickWidget: (android.appwidget.AppWidgetProviderInfo) -> Unit
)

// ---------------------------------------------------------------------------
// Kaca: wallpaper yang diblur digambar di belakang kartu (Android 10 tidak punya blur bawaan)
// ---------------------------------------------------------------------------

@Composable
fun Modifier.glass(state: LauncherState, shape: Shape, tint: Float): Modifier {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val g = state.glass
    val level = state.blurLevel
    val screen = state.screen
    return this
        .onGloballyPositioned { origin = it.positionInWindow() }
        .clip(shape)
        .drawBehind {
            if (g != null && level > 0) {
                drawWallpaperCrop(g.level(level), screen, origin)
            }
            drawRect(Color.White.copy(alpha = tint))
        }
}

/** Warna teks otomatis: gelap di latar terang, putih di latar gelap. */
@Composable
private fun rememberTextColor(
    state: LauncherState,
    fx0: Float,
    fy0: Float,
    fx1: Float,
    fy1: Float,
    vararg tints: Float
): Color {
    val g = state.glass
    if (!state.autoText || g == null) return Navy
    var l = g.luma(state.screen, fx0, fy0, fx1, fy1)
    for (t in tints) l = l * (1f - t) + t
    return if (l > 0.55f) Navy else Color.White
}

// ---------------------------------------------------------------------------
// Kartu + menu tekan lama
// ---------------------------------------------------------------------------

@Composable
fun CardBox(
    modifier: Modifier,
    shape: Shape,
    state: LauncherState,
    menu: List<MenuAction>,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var open by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf<List<MenuAction>?>(null) }
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .glass(state, shape, state.cardAlpha)
            .border(1.dp, Color.White.copy(alpha = 0.7f), shape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    page = null
                    open = true
                }
            )
    ) {
        content()
        DropdownMenu(
            expanded = open,
            onDismissRequest = {
                open = false
                page = null
            }
        ) {
            val items = page ?: menu
            items.forEach { m ->
                DropdownMenuItem(
                    text = { Text(m.label, color = if (m.danger) Danger else Navy) },
                    onClick = {
                        val sub = m.sub
                        if (sub != null) {
                            page = sub
                        } else {
                            open = false
                            page = null
                            m.action()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HomeCard(state: LauncherState, entry: AppEntry, span: Int, modifier: Modifier) {
    val textColor = rememberTextColor(state, 0f, 0.5f, 1f, 0.95f, state.cardAlpha)
    val widthOptions = (1..state.columns).map { n ->
        MenuAction(
            (if (n == span) "✓  " else "") + (if (n == state.columns) "$n kolom (penuh)" else "$n kolom")
        ) { state.setSpan(entry, n) }
    }
    CardBox(
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp),
        state = state,
        menu = listOf(
            MenuAction("Info aplikasi") { state.openInfo(entry) },
            MenuAction("Ubah lebar", sub = widthOptions),
            MenuAction("Hapus dari layar") { state.unpin(entry) },
            MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) }
        ),
        onClick = { state.launch(entry) }
    ) {
        Text(
            entry.label,
            color = textColor,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 12.dp)
        )
    }
}

// ---------------------------------------------------------------------------
// Homescreen
// ---------------------------------------------------------------------------

@Composable
fun WidgetSlot(state: LauncherState, onLongPress: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val id = state.widgetId
    val info = remember(id) { AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id) }
    if (info == null) return
    val h = with(density) { info.minHeight.toDp() }.coerceIn(48.dp, 220.dp)
    val widthDp = LocalConfiguration.current.screenWidthDp - 32
    val heightDp = h.value.toInt()
    key(id) {
        AndroidView(
            factory = { c ->
                state.widgetHost.createView(c, id, info).apply {
                    setOnLongClickListener {
                        onLongPress()
                        true
                    }
                }
            },
            update = { v -> v.updateAppWidgetSize(null, widthDp, heightDp, widthDp, heightDp) },
            modifier = Modifier
                .fillMaxWidth()
                .height(h)
        )
    }
}

@Composable
fun HomeScreen(state: LauncherState, onOpenDrawer: () -> Unit, onOpenSettings: () -> Unit) {
    val dateText = remember { SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()) }
    val dateColor = rememberTextColor(state, 0f, 0f, 1f, 0.25f)
    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { onOpenSettings() })
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -80f) onOpenDrawer() },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .systemBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        // Slot di atas: widget pilihan (at-a-glance) atau tanggal bila belum ada widget.
        if (state.widgetId != -1) {
            WidgetSlot(state, onLongPress = onOpenSettings)
        } else {
            Text(
                dateText,
                style = TextStyle(
                    color = dateColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    shadow = if (dateColor == Color.White) Shadow(Color(0x66143A5A), Offset(0f, 2f), 8f) else null
                )
            )
        }
        Spacer(Modifier.weight(1f))

        val cols = state.columns
        val rowCount = state.rows
        // Susun kartu ke baris berdasarkan lebarnya (span).
        val packed = ArrayList<MutableList<Pair<AppEntry, Int>>>()
        var cur = ArrayList<Pair<AppEntry, Int>>()
        var used = 0
        for (e in state.pinnedApps) {
            val s = state.span(e)
            if (used + s > cols) {
                packed.add(cur)
                cur = ArrayList()
                used = 0
            }
            cur.add(e to s)
            used += s
        }
        if (cur.isNotEmpty()) packed.add(cur)

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val gap = 10.dp
            val colW = (maxWidth - gap * (cols - 1)) / cols
            Column {
                for (r in 0 until rowCount) {
                    val items = packed.getOrNull(r)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        horizontalArrangement = Arrangement.spacedBy(gap)
                    ) {
                        if (items != null) {
                            for (item in items) {
                                val s = item.second
                                HomeCard(state, item.first, s, Modifier.width(colW * s + gap * (s - 1)))
                            }
                        }
                    }
                    if (r < rowCount - 1) Spacer(Modifier.height(gap))
                }
            }
        }
        Spacer(Modifier.height(36.dp))
    }
}

// ---------------------------------------------------------------------------
// Drawer
// ---------------------------------------------------------------------------

@Composable
fun DrawerCard(state: LauncherState, entry: AppEntry, textColor: Color, modifier: Modifier) {
    CardBox(
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(14.dp),
        state = state,
        menu = listOf(
            MenuAction("Tambah ke layar utama") { state.pin(entry) },
            MenuAction("Info aplikasi") { state.openInfo(entry) },
            MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) }
        ),
        onClick = { state.launch(entry) }
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ikon dipotong rounded 8dp = radius kartu 14dp - padding 6dp (konsentris)
            Image(
                bitmap = remember(entry.key) { state.icon(entry) },
                contentDescription = null,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(6.dp))
            Text(
                entry.label,
                color = textColor,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String, color: Color) {
    Text(
        text,
        color = color.copy(alpha = 0.75f),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun DrawerSheet(
    state: LauncherState,
    sheetTint: Float,
    query: String,
    onQuery: (String) -> Unit
) {
    val q = query.trim()
    val list = remember(state.apps, q) {
        if (q.isEmpty()) state.apps else state.apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    val gridState = rememberLazyGridState()
    val labelColor = rememberTextColor(state, 0f, 0.3f, 1f, 0.95f, sheetTint)
    val cardTextColor = rememberTextColor(state, 0f, 0.3f, 1f, 0.95f, sheetTint, state.cardAlpha)
    val lightText = labelColor == Color.White
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.78f)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color.White.copy(alpha = sheetTint))
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 10.dp)
                .size(width = 36.dp, height = 4.dp)
                .clip(CircleShape)
                .background(labelColor.copy(alpha = 0.3f))
        )
        Spacer(Modifier.height(14.dp))
        val fieldBg = if (lightText) Color.White.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.7f)
        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Cari aplikasi") },
            singleLine = true,
            shape = RoundedCornerShape(23.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = fieldBg,
                unfocusedContainerColor = fieldBg,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = labelColor,
                unfocusedTextColor = labelColor,
                focusedPlaceholderColor = labelColor.copy(alpha = 0.6f),
                unfocusedPlaceholderColor = labelColor.copy(alpha = 0.6f),
                cursorColor = labelColor
            ),
            modifier = Modifier.fillMaxWidth()
        )
        val rec = state.recentApps
        if (q.isEmpty() && rec.isNotEmpty()) {
            SectionLabel("Terakhir dipakai", labelColor)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 0 until 3) {
                    if (i < rec.size) {
                        DrawerCard(state, rec[i], cardTextColor, Modifier.weight(1f))
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        SectionLabel("Semua aplikasi", labelColor)
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp, end = 8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                gridItems(list, key = { it.key }) { e ->
                    DrawerCard(state, e, cardTextColor, Modifier.fillMaxWidth())
                }
            }
            // Indikator scroll: pill tipis di sisi kanan
            if (gridState.canScrollForward || gridState.canScrollBackward) {
                val total = gridState.layoutInfo.totalItemsCount
                val visible = gridState.layoutInfo.visibleItemsInfo.size
                val frac = (gridState.firstVisibleItemIndex.toFloat() / maxOf(1, total - visible))
                    .coerceIn(0f, 1f)
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(y = (maxHeight - 72.dp) * frac)
                        .width(4.dp)
                        .height(72.dp)
                        .clip(CircleShape)
                        .background(labelColor.copy(alpha = 0.35f))
                )
            }
        }
    }
}

/** Wallpaper diblur penuh saat drawer terbuka (menutupi homescreen di belakang sheet). */
@Composable
fun BlurOverlay(state: LauncherState, visible: Boolean) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(240), label = "blurBg")
    val g = state.glass
    if (a > 0.01f) {
        Canvas(Modifier.fillMaxSize()) {
            if (g != null && state.blurDrawerBg) {
                drawWallpaperCrop(g.heavy, state.screen, Offset.Zero, a)
                drawRect(Navy.copy(alpha = 0.16f * a))
            } else {
                drawRect(Navy.copy(alpha = 0.35f * a))
            }
        }
    }
}

@Composable
fun Drawer(state: LauncherState, visible: Boolean, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(visible) { if (!visible) query = "" }
    val sheetTint = if (state.glass != null && state.blurDrawerBg) 0.5f else 0.92f
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            DrawerSheet(state, sheetTint, query) { query = it }
        }
    }
}

// ---------------------------------------------------------------------------
// Pengaturan + pemilih widget
// ---------------------------------------------------------------------------

@Composable
fun SettingsDialog(
    state: LauncherState,
    actions: Actions,
    onPickWidget: () -> Unit,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Selesai") } },
        title = { Text("Pengaturan") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Kolom homescreen")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (n in 3..4) {
                        FilterChip(
                            selected = state.columns == n,
                            onClick = { state.updateColumns(n) },
                            label = { Text("$n") }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Baris homescreen: ${state.rows}")
                Slider(
                    value = state.rows.toFloat(),
                    onValueChange = { state.updateRows(it.roundToInt()) },
                    valueRange = 2f..8f,
                    steps = 5
                )
                Text("Kepekatan kartu")
                Slider(
                    value = state.cardAlpha,
                    onValueChange = { state.updateCardAlpha(it) },
                    valueRange = 0.2f..0.95f
                )
                val blurName = when (state.blurLevel) {
                    0 -> "mati"
                    1 -> "rendah"
                    2 -> "sedang"
                    else -> "tinggi"
                }
                Text("Blur kartu: $blurName")
                Slider(
                    value = state.blurLevel.toFloat(),
                    onValueChange = { state.updateBlurLevel(it.roundToInt()) },
                    valueRange = 0f..3f,
                    steps = 2
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Blur wallpaper saat drawer", modifier = Modifier.weight(1f))
                    Switch(checked = state.blurDrawerBg, onCheckedChange = { state.updateBlurDrawerBg(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Teks otomatis (gelap/terang)", modifier = Modifier.weight(1f))
                    Switch(checked = state.autoText, onCheckedChange = { state.updateAutoText(it) })
                }
                if (!state.hasWallpaperPermission || state.glass == null) {
                    Text(
                        "Blur dan teks otomatis butuh akses ke wallpaper.",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    TextButton(onClick = actions.askWallpaperPermission) { Text("Izinkan akses wallpaper") }
                }
                Spacer(Modifier.height(8.dp))
                Text("Widget at a glance")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onPickWidget) { Text(if (state.widgetId == -1) "Pilih widget" else "Ganti widget") }
                    if (state.widgetId != -1) {
                        TextButton(onClick = { state.removeWidget() }) { Text("Hapus widget") }
                    }
                }
            }
        }
    )
}

@Composable
fun WidgetPickerDialog(state: LauncherState, onPick: (android.appwidget.AppWidgetProviderInfo) -> Unit, onClose: () -> Unit) {
    val options = remember { state.widgetOptions() }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Batal") } },
        title = { Text("Pilih widget") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                listItems(options, key = { it.info.provider.flattenToShortString() }) { o ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(o.info) }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(o.label, fontWeight = FontWeight.SemiBold)
                        Text(o.appLabel, fontSize = 12.sp)
                    }
                }
            }
        }
    )
}
