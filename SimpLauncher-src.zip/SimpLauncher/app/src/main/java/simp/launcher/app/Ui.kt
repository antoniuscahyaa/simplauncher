@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package simp.launcher.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Navy = Color(0xFF14243A)
private val Danger = Color(0xFFB3261E)

data class MenuAction(val label: String, val danger: Boolean = false, val action: () -> Unit)

/** Kartu dasar: kaca translusen, tap = buka, tekan lama = menu. Dipakai homescreen dan drawer. */
@Composable
fun CardBox(
    modifier: Modifier,
    shape: Shape,
    state: LauncherState,
    menu: List<MenuAction>,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .clip(shape)
            .background(Color.White.copy(alpha = state.cardAlpha))
            .border(1.dp, Color.White.copy(alpha = 0.7f), shape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    open = true
                }
            )
    ) {
        content()
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            menu.forEach { m ->
                DropdownMenuItem(
                    text = { Text(m.label, color = if (m.danger) Danger else Navy) },
                    onClick = {
                        open = false
                        m.action()
                    }
                )
            }
        }
    }
}

@Composable
fun HomeCard(state: LauncherState, entry: AppEntry, modifier: Modifier) {
    CardBox(
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp),
        state = state,
        menu = listOf(
            MenuAction("Info aplikasi") { state.openInfo(entry) },
            MenuAction("Hapus dari layar") { state.unpin(entry) },
            MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) }
        ),
        onClick = { state.launch(entry) }
    ) {
        Text(
            entry.label,
            color = Navy,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 12.dp)
        )
    }
}

@Composable
fun HomeScreen(state: LauncherState, onOpenDrawer: () -> Unit, onOpenSettings: () -> Unit) {
    val dateText = remember { SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()) }
    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { onOpenSettings() })
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -80f) onOpenDrawer() },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .systemBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        // Slot kecil di atas untuk at-a-glance. Untuk uji coba: tanggal saja. Widget menyusul.
        Text(
            dateText,
            style = TextStyle(
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                shadow = Shadow(Color(0x66143A5A), Offset(0f, 2f), 8f)
            )
        )
        Spacer(Modifier.weight(1f))
        val apps = state.pinnedApps
        val cols = state.columns
        val rowCount = state.rows
        for (r in 0 until rowCount) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (c in 0 until cols) {
                    val idx = r * cols + c
                    val m = Modifier.weight(1f)
                    if (idx < apps.size) {
                        HomeCard(state, apps[idx], m)
                    } else {
                        Spacer(m.height(52.dp))
                    }
                }
            }
            if (r < rowCount - 1) Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(36.dp))
    }
}

@Composable
fun DrawerCard(state: LauncherState, entry: AppEntry, modifier: Modifier) {
    CardBox(
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(14.dp),
        state = state,
        menu = listOf(
            MenuAction("Tambah ke layar utama") { state.pin(entry) },
            MenuAction("Info aplikasi") { state.openInfo(entry) },
            MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) }
        ),
        onClick = { state.launch(entry) }
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ikon dipotong rounded 8dp = radius kartu 14dp - padding 6dp (konsentris)
            Image(
                bitmap = remember(entry.key) { state.icon(entry) },
                contentDescription = null,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(Modifier.width(6.dp))
            Text(
                entry.label,
                color = Navy,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        color = Color(0xFF3A4A5E),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun DrawerSheet(state: LauncherState, query: String, onQuery: (String) -> Unit) {
    val q = query.trim()
    val list = remember(state.apps, q) {
        if (q.isEmpty()) state.apps else state.apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    val gridState = rememberLazyGridState()
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.78f)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color.White.copy(alpha = 0.86f))
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 10.dp)
                .size(width = 36.dp, height = 4.dp)
                .clip(CircleShape)
                .background(Navy.copy(alpha = 0.3f))
        )
        Spacer(Modifier.height(14.dp))
        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Cari aplikasi") },
            singleLine = true,
            shape = RoundedCornerShape(23.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.7f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.7f),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        val rec = state.recentApps
        if (q.isEmpty() && rec.isNotEmpty()) {
            SectionLabel("Terakhir dipakai")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 0 until 3) {
                    if (i < rec.size) {
                        DrawerCard(state, rec[i], Modifier.weight(1f))
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        SectionLabel("Semua aplikasi")
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp, end = 8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(list, key = { it.key }) { e ->
                    DrawerCard(state, e, Modifier.fillMaxWidth())
                }
            }
            // Indikator scroll: pill tipis di sisi kanan
            if (gridState.canScrollForward || gridState.canScrollBackward) {
                val total = gridState.layoutInfo.totalItemsCount
                val visible = gridState.layoutInfo.visibleItemsInfo.size
                val frac = (gridState.firstVisibleItemIndex.toFloat() / maxOf(1, total - visible))
                    .coerceIn(0f, 1f)
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(y = (maxHeight - 72.dp) * frac)
                        .width(4.dp)
                        .height(72.dp)
                        .clip(CircleShape)
                        .background(Navy.copy(alpha = 0.32f))
                )
            }
        }
    }
}

@Composable
fun Drawer(state: LauncherState, visible: Boolean, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(visible) { if (!visible) query = "" }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x47142436))
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            DrawerSheet(state, query) { query = it }
        }
    }
}

@Composable
fun SettingsDialog(state: LauncherState, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Selesai") } },
        title = { Text("Pengaturan") },
        text = {
            Column {
                Text("Kolom homescreen")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (n in 3..4) {
                        FilterChip(
                            selected = state.columns == n,
                            onClick = { state.updateColumns(n) },
                            label = { Text("$n") }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Baris homescreen: ${state.rows}")
                Slider(
                    value = state.rows.toFloat(),
                    onValueChange = { state.updateRows(it.roundToInt()) },
                    valueRange = 2f..8f,
                    steps = 5
                )
                Text("Kepekatan kartu")
                Slider(
                    value = state.cardAlpha,
                    onValueChange = { state.updateCardAlpha(it) },
                    valueRange = 0.2f..0.95f
                )
            }
        }
    )
}
