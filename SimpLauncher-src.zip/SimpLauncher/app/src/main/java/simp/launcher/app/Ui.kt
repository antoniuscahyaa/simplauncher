@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package simp.launcher.app

import android.appwidget.AppWidgetManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val Danger = Color(0xFFB3261E)

data class MenuAction(
    val label: String,
    val danger: Boolean = false,
    val sub: List<MenuAction>? = null,
    val action: () -> Unit = {}
)

/** Tindakan yang harus dilakukan Activity (izin, widget, cadangan). */
class Actions(
    val askWallpaperPermission: () -> Unit,
    val pickWidget: (android.appwidget.AppWidgetProviderInfo) -> Unit,
    val exportBackup: () -> Unit,
    val importBackup: () -> Unit,
    val resetAll: () -> Unit
)

// ---------------------------------------------------------------------------
// Kaca: wallpaper yang diblur digambar di belakang kartu (Android 10 tidak punya blur bawaan)
// ---------------------------------------------------------------------------

@Composable
fun Modifier.glass(state: LauncherState, shape: Shape, tint: Float): Modifier {
    var origin by remember { mutableStateOf(Offset.Zero) }
    val g = state.glass
    val level = state.blurLevel.value
    val screen = state.screen
    val tintColor = state.tintColor
    return this
        .onGloballyPositioned { origin = it.positionInWindow() }
        .clip(shape)
        .drawBehind {
            if (g != null && level > 0) {
                drawWallpaperCrop(g.level(level), screen, origin)
            }
            drawRect(tintColor.copy(alpha = tint))
        }
}

/** Warna teks otomatis: gelap di latar terang, putih di latar gelap. */
@Composable
private fun rememberTextColor(
    state: LauncherState,
    fallback: Color,
    fx0: Float,
    fy0: Float,
    fx1: Float,
    fy1: Float,
    vararg tints: Float
): Color {
    val g = state.glass
    if (!state.autoText.value || g == null) return fallback
    var l = g.luma(state.screen, fx0, fy0, fx1, fy1)
    val tl = state.tintLuma
    for (t in tints) l = l * (1f - t) + t * tl
    return if (l > 0.55f) Color(0xFF14243A) else Color.White
}

// ---------------------------------------------------------------------------
// Kartu + menu tekan lama
// ---------------------------------------------------------------------------

/** Callback geser kartu di homescreen (mulai, gerak dalam piksel, selesai, batal). */
class CardDrag(
    val onStart: () -> Unit,
    val onMove: (Float, Float) -> Unit,
    val onEnd: () -> Unit,
    val onCancel: () -> Unit
)

@Composable
fun CardBox(
    modifier: Modifier,
    shape: Shape,
    state: LauncherState,
    menu: List<MenuAction>,
    onClick: () -> Unit,
    drag: CardDrag? = null,
    content: @Composable BoxScope.() -> Unit
) {
    var open by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf<List<MenuAction>?>(null) }
    val haptic = LocalHapticFeedback.current
    val dragNow by rememberUpdatedState(drag)
    val menuNow by rememberUpdatedState(menu)
    val borderColor = if (state.cardStyle.value == 1) Color.White.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.7f)
    val gesture: Modifier = if (drag == null) {
        Modifier.combinedClickable(
            onClick = onClick,
            onLongClick = {
                if (menu.isNotEmpty()) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    page = null
                    open = true
                }
            }
        )
    } else {
        // Tekan lama lalu geser = pindahkan kartu. Tekan lama tanpa geser = buka menu.
        Modifier
            .clickable(onClick = onClick)
            .pointerInput(Unit) {
                var moved = 0f
                val slop = viewConfiguration.touchSlop
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        moved = 0f
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        dragNow?.onStart?.invoke()
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        moved += amount.getDistance()
                        dragNow?.onMove?.invoke(amount.x, amount.y)
                    },
                    onDragEnd = {
                        if (moved < slop) {
                            dragNow?.onCancel?.invoke()
                            if (menuNow.isNotEmpty()) {
                                page = null
                                open = true
                            }
                        } else {
                            dragNow?.onEnd?.invoke()
                        }
                    },
                    onDragCancel = {
                        dragNow?.onCancel?.invoke()
                        if (moved < slop && menuNow.isNotEmpty()) {
                            page = null
                            open = true
                        }
                    }
                )
            }
    }
    Box(
        modifier
            .glass(state, shape, state.cardAlpha.value)
            .border(1.dp, borderColor, shape)
            .then(gesture)
    ) {
        content()
        DropdownMenu(
            expanded = open,
            onDismissRequest = {
                open = false
                page = null
            }
        ) {
            val items = page ?: menu
            items.forEach { m ->
                DropdownMenuItem(
                    text = { Text(m.label, color = if (m.danger) Danger else Color(0xFF14243A)) },
                    onClick = {
                        val sub = m.sub
                        if (sub != null) {
                            page = sub
                        } else {
                            open = false
                            page = null
                            m.action()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HomeCard(state: LauncherState, entry: AppEntry, span: Int, modifier: Modifier, drag: CardDrag? = null) {
    val textColor = rememberTextColor(state, state.baseText, 0f, 0.5f, 1f, 0.95f, state.cardAlpha.value)
    val cols = state.columns.value
    val widthOptions = (1..cols).map { n ->
        MenuAction(
            (if (n == span) "✓  " else "") + (if (n == cols) "$n kolom (penuh)" else "$n kolom")
        ) { state.setSpan(entry, n) }
    }
    val locked = state.lockLayout.value
    val menu = ArrayList<MenuAction>()
    if (state.menuHomeInfo.value) menu.add(MenuAction("Info aplikasi") { state.openInfo(entry) })
    if (!locked && state.menuHomeResize.value) menu.add(MenuAction("Ubah lebar", sub = widthOptions))
    if (!locked && state.menuHomeRemove.value) menu.add(MenuAction("Hapus dari layar") { state.unpin(entry) })
    if (state.menuHomeUninstall.value) menu.add(MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) })
    CardBox(
        modifier = modifier.height(state.cardHeight.value.dp),
        shape = RoundedCornerShape(state.cardRadius.value.dp),
        state = state,
        menu = menu,
        onClick = { state.launch(entry) },
        drag = drag
    ) {
        Text(
            entry.label,
            color = textColor,
            fontSize = (13.5f * state.labelScale.value / 100f).sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(if (state.textAlign.value == 0) Alignment.Center else Alignment.CenterStart)
                .padding(horizontal = 12.dp)
        )
    }
}

// ---------------------------------------------------------------------------
// Homescreen
// ---------------------------------------------------------------------------

@Composable
fun WidgetSlot(state: LauncherState, onLongPress: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val id = state.widgetId
    val info = remember(id) { AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id) }
    if (info == null) return
    val baseH = with(density) { info.minHeight.toDp() }.coerceIn(48.dp, 220.dp)
    val h = (baseH * (state.widgetScale.value / 10f)).coerceAtMost(360.dp)
    val widthDp = LocalConfiguration.current.screenWidthDp - 32
    val heightDp = h.value.toInt()
    key(id) {
        AndroidView(
            factory = { c ->
                state.widgetHost.createView(c, id, info).apply {
                    setOnLongClickListener {
                        onLongPress()
                        true
                    }
                }
            },
            update = { v -> v.updateAppWidgetSize(null, widthDp, heightDp, widthDp, heightDp) },
            modifier = Modifier
                .fillMaxWidth()
                .height(h)
        )
    }
}

@Composable
fun HomeScreen(state: LauncherState, onOpenDrawer: () -> Unit, onOpenSettings: () -> Unit) {
    val dateText = remember { SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date()) }
    val dateColor = rememberTextColor(state, Color.White, 0f, 0f, 1f, 0.25f)
    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = { if (state.gLongPress.value == 1) onOpenSettings() },
                    onDoubleTap = {
                        when (state.gDoubleTap.value) {
                            1 -> onOpenSettings()
                            2 -> onOpenDrawer()
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -80f && state.gSwipeUp.value == 1) {
                            onOpenDrawer()
                        } else if (total > 80f && state.gSwipeDown.value == 1) {
                            state.expandNotifications()
                        }
                    },
                    onDragCancel = { },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .systemBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(2.dp))
        // Slot di atas: widget pilihan (at-a-glance) atau tanggal bila belum ada widget.
        if (state.widgetId != -1) {
            WidgetSlot(state, onLongPress = onOpenSettings)
        } else if (state.showDate.value) {
            Text(
                dateText,
                style = TextStyle(
                    color = dateColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    shadow = if (dateColor == Color.White) Shadow(Color(0x66143A5A), Offset(0f, 2f), 8f) else null
                )
            )
        }
        val alignBottom = state.gridAlign.value == 0
        if (alignBottom) Spacer(Modifier.weight(1f)) else Spacer(Modifier.height(24.dp))

        HomeGrid(state)
        if (alignBottom) Spacer(Modifier.height(36.dp)) else Spacer(Modifier.weight(1f))
    }
}

/** Grid kartu homescreen: tiap kartu diposisikan per sel; tekan lama + geser untuk memindahkan. */
@Composable
private fun HomeGrid(state: LauncherState) {
    val cols = state.columns.value
    val rowCount = state.rows.value
    val gap = state.cardGap.value.dp
    val cardH = state.cardHeight.value.dp
    val radius = state.cardRadius.value.dp
    val placed = state.gridLayout()
    val canDrag = state.moveByDrag.value && !state.lockLayout.value
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val density = LocalDensity.current

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val colW = (maxWidth - gap * (cols - 1)) / cols
        val stepX = colW + gap
        val stepY = cardH + gap
        val totalH = cardH * rowCount + gap * (rowCount - 1)
        val stepXpx = with(density) { stepX.toPx() }
        val stepYpx = with(density) { stepY.toPx() }

        // Sel tujuan (baris, kolom) dari posisi kartu yang sedang digeser, dijepit ke batas grid.
        fun targetOf(p: Placed): Pair<Int, Int> {
            val tc = ((p.col * stepXpx + dragX) / stepXpx).roundToInt().coerceIn(0, cols - p.span)
            val tr = ((p.row * stepYpx + dragY) / stepYpx).roundToInt().coerceIn(0, rowCount - 1)
            return tr to tc
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(totalH)
        ) {
            val dragged = placed.firstOrNull { it.entry.key == dragKey }
            if (dragged != null) {
                val t = targetOf(dragged)
                Box(
                    Modifier
                        .offset(stepX * t.second, stepY * t.first)
                        .width(colW * dragged.span + gap * (dragged.span - 1))
                        .height(cardH)
                        .border(2.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(radius))
                )
            }
            for (p in placed) {
                key(p.entry.key) {
                    val dragging = dragKey == p.entry.key
                    HomeCard(
                        state,
                        p.entry,
                        p.span,
                        Modifier
                            .offset {
                                IntOffset(
                                    (stepX * p.col).roundToPx() + if (dragging) dragX.roundToInt() else 0,
                                    (stepY * p.row).roundToPx() + if (dragging) dragY.roundToInt() else 0
                                )
                            }
                            .width(colW * p.span + gap * (p.span - 1))
                            .zIndex(if (dragging) 10f else 0f),
                        drag = if (canDrag) {
                            CardDrag(
                                onStart = {
                                    dragKey = p.entry.key
                                    dragX = 0f
                                    dragY = 0f
                                },
                                onMove = { dx, dy ->
                                    dragX += dx
                                    dragY += dy
                                },
                                onEnd = {
                                    val t = targetOf(p)
                                    dragKey = null
                                    dragX = 0f
                                    dragY = 0f
                                    state.moveCard(p.entry, t.first, t.second)
                                },
                                onCancel = {
                                    dragKey = null
                                    dragX = 0f
                                    dragY = 0f
                                }
                            )
                        } else {
                            null
                        }
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Drawer
// ---------------------------------------------------------------------------

@Composable
fun DrawerCard(state: LauncherState, entry: AppEntry, textColor: Color, modifier: Modifier) {
    val menu = ArrayList<MenuAction>()
    if (state.menuDrawerPin.value) menu.add(MenuAction("Tambah ke layar utama") { state.pin(entry) })
    if (state.menuDrawerInfo.value) menu.add(MenuAction("Info aplikasi") { state.openInfo(entry) })
    if (state.menuDrawerUninstall.value) menu.add(MenuAction("Copot pemasangan", danger = true) { state.uninstall(entry) })

    val cardRadius = (state.cardRadius.value - 2).coerceAtLeast(6)
    val iconSize = state.iconSize.value
    val pad = (48 - iconSize) / 2f
    // Radius ikon konsentris dengan kartu: radius kartu dikurangi padding
    val iconRadius = (cardRadius - pad).coerceAtLeast(2f)
    val iconShape: Shape = when (state.iconShape.value) {
        1 -> CircleShape
        2 -> RoundedCornerShape(3.dp)
        3 -> RectangleShape
        else -> RoundedCornerShape(iconRadius.dp)
    }
    CardBox(
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(cardRadius.dp),
        state = state,
        menu = menu,
        onClick = { state.launch(entry) }
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = pad.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                bitmap = remember(entry.key, state.iconRev) { state.icon(entry) },
                contentDescription = null,
                modifier = Modifier
                    .size(iconSize.dp)
                    .clip(iconShape)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                entry.label,
                color = textColor,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String, color: Color) {
    Text(
        text,
        color = color.copy(alpha = 0.75f),
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun DrawerSheet(
    state: LauncherState,
    sheetTint: Float,
    query: String,
    onQuery: (String) -> Unit
) {
    val q = query.trim()
    val base = state.drawerApps
    val list = remember(base, q) {
        if (q.isEmpty()) base else base.filter { it.label.contains(q, ignoreCase = true) }
    }
    val gridState = rememberLazyGridState()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (state.autoKeyboard.value) {
            try {
                focus.requestFocus()
            } catch (t: Exception) {
            }
        }
    }
    val labelColor = rememberTextColor(state, state.baseText, 0f, 0.3f, 1f, 0.95f, sheetTint)
    val cardTextColor = rememberTextColor(state, state.baseText, 0f, 0.3f, 1f, 0.95f, sheetTint, state.cardAlpha.value)
    val lightText = labelColor == Color.White
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(state.sheetHeight.value / 100f)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(state.tintColor.copy(alpha = sheetTint))
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 10.dp)
                .size(width = 36.dp, height = 4.dp)
                .clip(CircleShape)
                .background(labelColor.copy(alpha = 0.3f))
        )
        Spacer(Modifier.height(14.dp))
        val fieldBg = if (lightText) Color.White.copy(alpha = 0.18f) else Color.White.copy(alpha = 0.7f)
        TextField(
            value = query,
            onValueChange = onQuery,
            placeholder = { Text("Cari aplikasi") },
            singleLine = true,
            shape = RoundedCornerShape(23.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = fieldBg,
                unfocusedContainerColor = fieldBg,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = labelColor,
                unfocusedTextColor = labelColor,
                focusedPlaceholderColor = labelColor.copy(alpha = 0.6f),
                unfocusedPlaceholderColor = labelColor.copy(alpha = 0.6f),
                cursorColor = labelColor
            ),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focus)
        )
        val rec = state.recentApps
        if (q.isEmpty() && rec.isNotEmpty()) {
            SectionLabel("Terakhir dipakai", labelColor)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val n = state.drawerColumns.value
                for (i in 0 until n) {
                    if (i < rec.size) {
                        DrawerCard(state, rec[i], cardTextColor, Modifier.weight(1f))
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        SectionLabel("Semua aplikasi", labelColor)
        BoxWithConstraints(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(state.drawerColumns.value),
                state = gridState,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp, end = 8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(list, key = { it.key }) { e ->
                    DrawerCard(state, e, cardTextColor, Modifier.fillMaxWidth())
                }
            }
            // Indikator scroll: pill tipis di sisi kanan
            if (state.drawerScrollBar.value && (gridState.canScrollForward || gridState.canScrollBackward)) {
                val total = gridState.layoutInfo.totalItemsCount
                val visible = gridState.layoutInfo.visibleItemsInfo.size
                val frac = (gridState.firstVisibleItemIndex.toFloat() / maxOf(1, total - visible))
                    .coerceIn(0f, 1f)
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(y = (maxHeight - 72.dp) * frac)
                        .width(4.dp)
                        .height(72.dp)
                        .clip(CircleShape)
                        .background(labelColor.copy(alpha = 0.35f))
                )
            }
        }
    }
}

/** Wallpaper diblur penuh saat drawer terbuka (menutupi homescreen di belakang sheet). */
@Composable
fun BlurOverlay(state: LauncherState, visible: Boolean) {
    val a by animateFloatAsState(if (visible) 1f else 0f, tween(240), label = "blurBg")
    val g = state.glass
    val dim = Color(0xFF14243A)
    if (a > 0.01f) {
        Canvas(Modifier.fillMaxSize()) {
            if (g != null && state.blurDrawerBg.value) {
                drawWallpaperCrop(g.heavy, state.screen, Offset.Zero, a)
                drawRect(dim.copy(alpha = 0.16f * a))
            } else {
                drawRect(dim.copy(alpha = 0.35f * a))
            }
        }
    }
}

@Composable
fun Drawer(state: LauncherState, visible: Boolean, onClose: () -> Unit) {
    var query by remember { mutableStateOf("") }
    LaunchedEffect(visible) { if (!visible) query = "" }
    val sheetTint = if (state.glass != null && state.blurDrawerBg.value) 0.5f else 0.92f
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it }
        ) {
            DrawerSheet(state, sheetTint, query) { query = it }
        }
    }
}
