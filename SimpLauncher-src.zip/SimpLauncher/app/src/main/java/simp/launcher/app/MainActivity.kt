package simp.launcher.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {

    private lateinit var state: LauncherState
    private var drawerOpen by mutableStateOf(false)
    private var settingsOpen by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        state = LauncherState(applicationContext)
        state.reload()
        // Tombol Home ditekan saat sudah di launcher: tutup drawer dan dialog.
        addOnNewIntentListener {
            drawerOpen = false
            settingsOpen = false
        }
        setContent {
            MaterialTheme {
                LauncherRoot(
                    state = state,
                    drawerOpen = drawerOpen,
                    setDrawer = { drawerOpen = it },
                    settingsOpen = settingsOpen,
                    setSettings = { settingsOpen = it }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        state.reload()
    }

    override fun onStop() {
        super.onStop()
        drawerOpen = false
        settingsOpen = false
    }
}

@Composable
fun LauncherRoot(
    state: LauncherState,
    drawerOpen: Boolean,
    setDrawer: (Boolean) -> Unit,
    settingsOpen: Boolean,
    setSettings: (Boolean) -> Unit
) {
    // Back di launcher tidak menutup aplikasi; hanya menutup drawer bila terbuka.
    BackHandler(enabled = true) {
        if (drawerOpen) setDrawer(false)
    }
    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            state = state,
            onOpenDrawer = { setDrawer(true) },
            onOpenSettings = { setSettings(true) }
        )
        Drawer(state = state, visible = drawerOpen) { setDrawer(false) }
        if (settingsOpen) {
            SettingsDialog(state) { setSettings(false) }
        }
    }
}
