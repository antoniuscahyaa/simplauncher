package simp.launcher.app

import android.Manifest
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged

class MainActivity : ComponentActivity() {

    private lateinit var state: LauncherState
    private var drawerOpen by mutableStateOf(false)
    private var settingsOpen by mutableStateOf(false)
    private var pendingWidgetId = -1

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            state.loadWallpaper(true)
        }

    private val bindLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val id = pendingWidgetId
            if (id != -1) {
                if (res.resultCode == RESULT_OK) {
                    afterBind(id)
                } else {
                    state.widgetHost.deleteAppWidgetId(id)
                    pendingWidgetId = -1
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        state = LauncherState(applicationContext)
        state.reload()
        state.loadWallpaper()
        // Minta izin baca wallpaper sekali saja (dipakai untuk blur dan teks otomatis).
        val prefs = getSharedPreferences("simp_launcher_ui", MODE_PRIVATE)
        if (!state.hasWallpaperPermission && !prefs.getBoolean("askedWallpaper", false)) {
            prefs.edit().putBoolean("askedWallpaper", true).apply()
            askWallpaperPermission()
        }
        // Tombol Home ditekan saat sudah di launcher: tutup drawer dan dialog.
        addOnNewIntentListener {
            drawerOpen = false
            settingsOpen = false
        }
        val actions = Actions(
            askWallpaperPermission = { askWallpaperPermission() },
            pickWidget = { pickWidget(it) }
        )
        setContent {
            MaterialTheme {
                LauncherRoot(
                    state = state,
                    actions = actions,
                    drawerOpen = drawerOpen,
                    setDrawer = { drawerOpen = it },
                    settingsOpen = settingsOpen,
                    setSettings = { settingsOpen = it }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            state.widgetHost.startListening()
        } catch (t: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        state.reload()
        state.loadWallpaper()
    }

    override fun onStop() {
        super.onStop()
        drawerOpen = false
        settingsOpen = false
        try {
            state.widgetHost.stopListening()
        } catch (t: Exception) {
        }
    }

    private fun askWallpaperPermission() {
        permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    // ---- Widget: alokasi id, bind (minta izin bila perlu), konfigurasi, simpan ----

    private fun pickWidget(p: AppWidgetProviderInfo) {
        val awm = AppWidgetManager.getInstance(this)
        val id = state.widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            bindLauncher.launch(i)
        }
    }

    private fun afterBind(id: Int) {
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        if (info?.configure != null) {
            try {
                state.widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (t: Exception) {
                commitWidget(id)
            }
        } else {
            commitWidget(id)
        }
    }

    private fun commitWidget(id: Int) {
        state.setWidget(id)
        pendingWidgetId = -1
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CONFIG) {
            val id = pendingWidgetId
            if (id != -1) {
                if (resultCode == RESULT_OK) {
                    commitWidget(id)
                } else {
                    state.widgetHost.deleteAppWidgetId(id)
                    pendingWidgetId = -1
                }
            }
        }
    }

    companion object {
        private const val REQ_CONFIG = 4242
    }
}

@Composable
fun LauncherRoot(
    state: LauncherState,
    actions: Actions,
    drawerOpen: Boolean,
    setDrawer: (Boolean) -> Unit,
    settingsOpen: Boolean,
    setSettings: (Boolean) -> Unit
) {
    var pickerOpen by remember { mutableStateOf(false) }
    // Back di launcher tidak menutup aplikasi; hanya menutup drawer bila terbuka.
    BackHandler(enabled = true) {
        if (drawerOpen) setDrawer(false)
    }
    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { state.screen = it }
    ) {
        HomeScreen(
            state = state,
            onOpenDrawer = { setDrawer(true) },
            onOpenSettings = { setSettings(true) }
        )
        BlurOverlay(state, drawerOpen)
        Drawer(state = state, visible = drawerOpen) { setDrawer(false) }
        if (settingsOpen) {
            SettingsDialog(
                state = state,
                actions = actions,
                onPickWidget = { pickerOpen = true },
                onClose = { setSettings(false) }
            )
        }
        if (pickerOpen) {
            WidgetPickerDialog(
                state = state,
                onPick = {
                    pickerOpen = false
                    actions.pickWidget(it)
                },
                onClose = { pickerOpen = false }
            )
        }
    }
}
