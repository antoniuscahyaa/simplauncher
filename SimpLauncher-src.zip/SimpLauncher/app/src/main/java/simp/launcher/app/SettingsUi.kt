@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package simp.launcher.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Ink = Color(0xFF14243A)
private val Sub = Color(0xFF5B6B7F)
private val Bg = Color(0xFFF3F5F8)
private val Line = Color(0xFFE2E7EE)

// ---------------------------------------------------------------------------
// Baris-baris dasar
// ---------------------------------------------------------------------------

@Composable
private fun Group(title: String? = null, content: @Composable () -> Unit) {
    if (title != null) {
        Text(
            title,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp)
        )
    }
    Column(
        Modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
    ) { content() }
}

@Composable
private fun Divider() {
    Box(
        Modifier
            .padding(start = 16.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(Line)
    )
}

@Composable
private fun RowBase(
    title: String,
    sub: String?,
    onClick: (() -> Unit)?,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable { onClick() } else it }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
        trailing()
    }
}

@Composable
private fun SwitchRow(title: String, sub: String? = null, pref: BoolPref) {
    RowBase(title, sub, { pref.value = !pref.value }) {
        Switch(checked = pref.value, onCheckedChange = { pref.value = it })
    }
}

@Composable
private fun NavRow(title: String, sub: String? = null, onClick: () -> Unit) {
    RowBase(title, sub, onClick) { Text("›", color = Sub, fontSize = 22.sp) }
}

@Composable
private fun ValueRow(title: String, value: String, onClick: () -> Unit) {
    RowBase(title, null, onClick) { Text(value, color = Sub, fontSize = 13.sp) }
}

@Composable
private fun ActionRow(title: String, sub: String? = null, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Column {
            Text(
                title,
                color = if (danger) Color(0xFFB3261E) else MaterialTheme.colorScheme.primary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            if (sub != null) Text(sub, color = Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun SliderRow(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    label: String,
    onChange: (Float) -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(label, color = Sub, fontSize = 13.sp)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun IntSliderRow(title: String, pref: IntPref, lo: Int, hi: Int, unit: String = "") {
    SliderRow(
        title = title,
        value = pref.value.toFloat(),
        range = lo.toFloat()..hi.toFloat(),
        steps = (hi - lo - 1).coerceAtLeast(0),
        label = "${pref.value}$unit"
    ) { pref.value = it.roundToInt() }
}

@Composable
private fun ChoiceRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        FlowRow(
            Modifier.padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEachIndexed { i, o ->
                FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(o) })
            }
        }
    }
}

@Composable
private fun Page(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .systemBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Kembali", fontSize = 15.sp) }
        }
        Text(
            title,
            color = Ink,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
        ) {
            content()
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ---------------------------------------------------------------------------
// Layar pengaturan
// ---------------------------------------------------------------------------

@Composable
fun SettingsScreen(state: LauncherState, actions: Actions, onClose: () -> Unit) {
    var page by remember { mutableStateOf("main") }
    BackHandler(enabled = true) {
        if (page == "main") onClose() else page = "main"
    }
    val back = { page = "main" }
    Box(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { }
    ) {
        when (page) {
            "home" -> HomePage(state, actions, back)
            "look" -> LookPage(state, actions, back)
            "icons" -> IconsPage(state, back)
            "drawer" -> DrawerPage(state, back)
            "menu" -> MenuPage(state, back)
            "gesture" -> GesturePage(state, back)
            "system" -> SystemPage(state, actions, back)
            "about" -> AboutPage(back)
            else -> MainPage(state, onClose) { page = it }
        }
    }
}

@Composable
private fun MainPage(state: LauncherState, onClose: () -> Unit, go: (String) -> Unit) {
    Page("Pengaturan", onClose) {
        Group {
            NavRow("Layar utama", "Grid, kartu, widget, tanggal") { go("home") }
            Divider()
            NavRow("Tampilan", "Gaya kartu, blur, warna, teks otomatis") { go("look") }
            Divider()
            NavRow("Ikon", "Bentuk, ukuran, icon pack") { go("icons") }
            Divider()
            NavRow("Drawer aplikasi", "Kolom, terakhir dipakai, tinggi sheet") { go("drawer") }
            Divider()
            NavRow("Menu tekan lama", "Pilih item menu yang tampil") { go("menu") }
            Divider()
            NavRow("Gesture", "Geser, ketuk dua kali, tekan lama") { go("gesture") }
            Divider()
            NavRow("Sistem", "Status bar, cadangan, reset") { go("system") }
            Divider()
            NavRow("Tentang", "SimpLauncher " + BuildConfigVersion) { go("about") }
        }
    }
}

private const val BuildConfigVersion = "0.3.0"

@Composable
private fun HomePage(state: LauncherState, actions: Actions, back: () -> Unit) {
    var picker by remember { mutableStateOf(false) }
    Page("Layar utama", back) {
        Group("Grid") {
            ChoiceRow("Kolom", listOf("3 kolom", "4 kolom"), state.columns.value - 3) { state.columns.value = it + 3 }
            Divider()
            IntSliderRow("Jumlah baris", state.rows, 2, 8)
            Divider()
            ChoiceRow("Posisi grid", listOf("Bawah", "Atas"), state.gridAlign.value) { state.gridAlign.value = it }
        }
        Group("Kartu") {
            IntSliderRow("Tinggi kartu", state.cardHeight, 40, 72, " dp")
            Divider()
            IntSliderRow("Jarak antar kartu", state.cardGap, 4, 16, " dp")
            Divider()
            IntSliderRow("Lengkung sudut", state.cardRadius, 6, 26, " dp")
            Divider()
            IntSliderRow("Ukuran teks", state.labelScale, 80, 130, "%")
            Divider()
            ChoiceRow("Rata teks", listOf("Tengah", "Kiri"), state.textAlign.value) { state.textAlign.value = it }
        }
        Group("Slot atas") {
            RowBase(
                "Widget",
                if (state.widgetId == -1) "Belum ada widget" else "Widget terpasang",
                { picker = true }
            ) { Text("Pilih", color = MaterialTheme.colorScheme.primary, fontSize = 14.sp) }
            if (state.widgetId != -1) {
                Divider()
                ActionRow("Hapus widget", danger = true) { state.removeWidget() }
            }
            Divider()
            SwitchRow("Tampilkan tanggal", "Dipakai saat tidak ada widget", state.showDate)
        }
        Group("Layout") {
            SwitchRow("Kunci layout", "Cegah ubah lebar dan hapus kartu", state.lockLayout)
        }
    }
    if (picker) {
        WidgetPickerDialog(
            state = state,
            onPick = {
                picker = false
                actions.pickWidget(it)
            },
            onClose = { picker = false }
        )
    }
}

@Composable
private fun LookPage(state: LauncherState, actions: Actions, back: () -> Unit) {
    Page("Tampilan", back) {
        Group("Kartu") {
            ChoiceRow("Gaya kartu", listOf("Terang", "Gelap"), state.cardStyle.value) { state.cardStyle.value = it }
            Divider()
            SliderRow(
                "Kepekatan kartu",
                state.cardAlpha.value,
                0.2f..0.95f,
                0,
                "${(state.cardAlpha.value * 100).roundToInt()}%"
            ) { state.cardAlpha.value = it }
            Divider()
            ChoiceRow("Tingkat blur kartu", listOf("Mati", "Rendah", "Sedang", "Tinggi"), state.blurLevel.value) {
                state.blurLevel.value = it
            }
            Divider()
            SwitchRow("Teks otomatis", "Gelap atau putih mengikuti wallpaper", state.autoText)
        }
        Group("Latar drawer") {
            SwitchRow("Blur wallpaper saat drawer", "Latar di belakang sheet diburamkan", state.blurDrawerBg)
        }
        Group("Warna aksen") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                state.accentColors.forEachIndexed { i, c ->
                    val sel = i == state.accent.value
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(if (sel) 3.dp else 0.dp, if (sel) Color.White else Color.Transparent, CircleShape)
                            .border(if (sel) 1.dp else 0.dp, if (sel) c else Color.Transparent, CircleShape)
                            .clickable { state.accent.value = i }
                    )
                }
            }
        }
        Group("Wallpaper") {
            if (state.hasWallpaperPermission) {
                RowBase("Akses wallpaper", "Diizinkan. Blur dan teks otomatis aktif", null) { }
            } else {
                ActionRow("Izinkan akses wallpaper", "Dibutuhkan untuk blur dan teks otomatis") {
                    actions.askWallpaperPermission()
                }
            }
        }
    }
}

@Composable
private fun IconsPage(state: LauncherState, back: () -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    Page("Ikon", back) {
        Group("Drawer") {
            ChoiceRow(
                "Bentuk ikon",
                listOf("Rounded", "Lingkaran", "Persegi", "Asli"),
                state.iconShape.value
            ) { state.iconShape.value = it }
            Divider()
            IntSliderRow("Ukuran ikon", state.iconSize, 28, 44, " dp")
        }
        Group("Icon pack") {
            ValueRow("Icon pack", state.iconPackLabel()) { dialog = true }
        }
    }
    if (dialog) IconPackDialog(state) { dialog = false }
}

@Composable
private fun IconPackDialog(state: LauncherState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val packs = remember { IconPacks.list(ctx) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Tutup") } },
        title = { Text("Pilih icon pack") },
        text = {
            LazyColumn {
                item {
                    PickRow("Bawaan sistem", state.iconPack.isEmpty()) {
                        state.chooseIconPack("")
                        onClose()
                    }
                }
                items(packs) { p ->
                    PickRow(p.label, state.iconPack == p.pkg) {
                        state.chooseIconPack(p.pkg)
                        onClose()
                    }
                }
                if (packs.isEmpty()) {
                    item {
                        Text(
                            "Tidak ada icon pack ADW/Nova/Apex yang terpasang.",
                            color = Sub,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    )
}

@Composable
private fun PickRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Ink,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f)
        )
        if (selected) Text("✓", color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
    }
}

@Composable
private fun DrawerPage(state: LauncherState, back: () -> Unit) {
    var hiddenDialog by remember { mutableStateOf(false) }
    Page("Drawer aplikasi", back) {
        Group("Tata letak") {
            ChoiceRow(
                "Kolom",
                listOf("2", "3", "4"),
                state.drawerColumns.value - 2
            ) { state.drawerColumns.value = it + 2 }
            Divider()
            IntSliderRow("Tinggi sheet", state.sheetHeight, 55, 95, "%")
            Divider()
            SwitchRow("Indikator scroll", "Pill tipis di sisi kanan", state.drawerScrollBar)
        }
        Group("Pencarian dan terakhir dipakai") {
            ChoiceRow(
                "Jumlah terakhir dipakai",
                listOf("Mati", "1", "2", "3"),
                state.recentCount.value
            ) { state.recentCount.value = it }
            Divider()
            SwitchRow("Keyboard otomatis", "Langsung fokus ke kolom cari", state.autoKeyboard)
        }
        Group("Aplikasi") {
            ValueRow("Sembunyikan aplikasi", "${state.hidden.size} disembunyikan") { hiddenDialog = true }
        }
    }
    if (hiddenDialog) HiddenAppsDialog(state) { hiddenDialog = false }
}

@Composable
private fun HiddenAppsDialog(state: LauncherState, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Selesai") } },
        title = { Text("Sembunyikan dari drawer") },
        text = {
            LazyColumn(Modifier.height(380.dp)) {
                items(state.apps, key = { it.key }) { e ->
                    val hidden = e.key in state.hidden
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { state.setHidden(e, !hidden) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = hidden, onCheckedChange = { state.setHidden(e, it) })
                        Text(e.label, color = Ink, fontSize = 15.sp)
                    }
                }
            }
        }
    )
}

@Composable
private fun MenuPage(state: LauncherState, back: () -> Unit) {
    Page("Menu tekan lama", back) {
        Group("Di layar utama") {
            SwitchRow("Info aplikasi", pref = state.menuHomeInfo)
            Divider()
            SwitchRow("Ubah lebar", pref = state.menuHomeResize)
            Divider()
            SwitchRow("Hapus dari layar", pref = state.menuHomeRemove)
            Divider()
            SwitchRow("Copot pemasangan", pref = state.menuHomeUninstall)
        }
        Group("Di drawer") {
            SwitchRow("Tambah ke layar utama", pref = state.menuDrawerPin)
            Divider()
            SwitchRow("Info aplikasi", pref = state.menuDrawerInfo)
            Divider()
            SwitchRow("Copot pemasangan", pref = state.menuDrawerUninstall)
        }
    }
}

@Composable
private fun GesturePage(state: LauncherState, back: () -> Unit) {
    Page("Gesture", back) {
        Group {
            ChoiceRow("Geser ke atas", listOf("Tidak ada", "Buka drawer"), state.gSwipeUp.value) {
                state.gSwipeUp.value = it
            }
            Divider()
            ChoiceRow("Geser ke bawah", listOf("Tidak ada", "Panel notifikasi"), state.gSwipeDown.value) {
                state.gSwipeDown.value = it
            }
            Divider()
            ChoiceRow(
                "Ketuk dua kali",
                listOf("Tidak ada", "Pengaturan", "Drawer"),
                state.gDoubleTap.value
            ) { state.gDoubleTap.value = it }
            Divider()
            ChoiceRow("Tekan lama di layar", listOf("Tidak ada", "Pengaturan"), state.gLongPress.value) {
                state.gLongPress.value = it
            }
        }
    }
}

@Composable
private fun SystemPage(state: LauncherState, actions: Actions, back: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Page("Sistem", back) {
        Group("Tampilan sistem") {
            SwitchRow("Sembunyikan status bar", "Layar lebih bersih, geser dari atas untuk menampilkan", state.hideStatusBar)
        }
        Group("Cadangan") {
            ActionRow("Ekspor pengaturan", "Simpan ke file JSON") { actions.exportBackup() }
            Divider()
            ActionRow("Impor pengaturan", "Pulihkan dari file JSON") { actions.importBackup() }
        }
        Group("Reset") {
            ActionRow("Reset semua pengaturan", "Kembali ke bawaan, kartu di layar ikut direset", danger = true) {
                confirm = true
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Reset semua pengaturan?") },
            text = { Text("Semua pengaturan dan susunan kartu akan kembali ke bawaan.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    actions.resetAll()
                }) { Text("Reset", color = Color(0xFFB3261E)) }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } }
        )
    }
}

@Composable
private fun AboutPage(back: () -> Unit) {
    Page("Tentang", back) {
        Group {
            RowBase("SimpLauncher", "Versi $BuildConfigVersion", null) { }
            Divider()
            RowBase(
                "Terinspirasi Lawnchair",
                "Susunan pengaturan terinspirasi Lawnchair. Tidak memakai kode Lawnchair.",
                null
            ) { }
            Divider()
            RowBase("Recents dan gesture sistem", "Menyusul di versi berikutnya", null) { }
        }
    }
}

// ---------------------------------------------------------------------------
// Pemilih widget
// ---------------------------------------------------------------------------

@Composable
fun WidgetPickerDialog(
    state: LauncherState,
    onPick: (android.appwidget.AppWidgetProviderInfo) -> Unit,
    onClose: () -> Unit
) {
    val options = remember { state.widgetOptions() }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Batal") } },
        title = { Text("Pilih widget") },
        text = {
            LazyColumn(Modifier.height(380.dp)) {
                items(options) { o ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(o.info) }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(o.label, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(o.appLabel, color = Sub, fontSize = 12.sp)
                    }
                }
            }
        }
    )
}
