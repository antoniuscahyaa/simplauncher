# Shady Launcher — Simp-style Home Screen + App Drawer

This source bundle extends the existing RecentsMod build pipeline with a separate Home/App Drawer overlay. The original `ShadyQuickStep.apk` remains the base APK. The existing RecentsMod implementation remains in place.

## What changed

New files:

- `src/simp/home/SimpHomeOverlay.java` — native Android 10-compatible View implementation for the Home Screen and App Drawer.
- `tools/home_ui_patch.py` — adds one call to `SimpHomeOverlay.install(Activity)` after `Launcher.setContentView(View)` in the decoded Shady launcher activity.
- `CHANGELOG-SIMP-HOME-APPDRAWER.md` — scope and current limitations.

Build pipeline change:

- `build.sh` runs `home_ui_patch.py` after the original RecentsMod patch. The existing Java compile step automatically includes `src/simp/home/*.java` in the same extra DEX.

## Home Screen and App Drawer layout

- Wallpaper-derived blurred background; the code falls back without crashing if wallpaper access fails.
- Date header.
- 3-column x 4-row translucent app-card layout (up to 12 pinned apps).
- Swipe up opens a bottom App Drawer sheet; swipe down requests the notification shade.
- Drawer includes a rounded handle, app search, last-used row, and a 3-column all-app grid.
- Tap launches an app. Long-press offers app info, uninstall, pin, or unpin actions.
- Pinned app order and recent apps are stored in SharedPreferences under `simp_home_overlay`.

## Important limits in this initial port

This is a native visual/interaction port of the Home Screen and App Drawer layout, not a complete port of every SimpLauncher feature. In particular, the first pass does not yet implement SimpLauncher's full settings UI, home-card drag reordering/resizing, icon-pack mapping, or its optional widget slot. Existing launcher Workspace and app data remain in the Shady APK underneath the overlay. Quickstep/Recents remains the existing Shady implementation plus the unchanged RecentsMod patches.

## Build

Run the existing `build.sh` in an Android SDK environment with the same prerequisites as the original RecentsMod project. The script still requires Android build-tools/platforms, `apktool`, and a signing certificate whose SHA-256 fingerprint matches the base APK. The new hook fails closed if it cannot find exactly one `com/android/launcher3/Launcher.smali` and a `setContentView(View)` call in `Launcher.onCreate(Bundle)`.

## Verification performed for this bundle

- `bash -n build.sh` passes.
- `python3 -m py_compile tools/home_ui_patch.py` passes.
- The smali hook was tested against a synthetic `Launcher.smali` and is idempotent.
- Recents source/resource/patch files were compared against the original `RecentsMod-src.zip` and remain byte-identical.
- Full APK build and device runtime test were not run in this environment because no Android SDK/build-tools or apktool executable/JAR is available here.
