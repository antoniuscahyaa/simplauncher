package simp.home;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Simp-style Home Screen and App Drawer overlay for the Shady Launcher APK.
 *
 * This class deliberately does not reference or modify Quickstep / Recents classes.
 * It is installed as the final child of Launcher3's DragLayer, after Launcher.onCreate
 * has called setContentView(). The native launcher remains underneath as the owner of
 * Quickstep, widgets, and Android's HOME activity lifecycle.
 */
public final class SimpHomeOverlay extends FrameLayout {
    private static final String TAG = "simp.home.overlay";
    private static final String PREFS = "simp_home_overlay";
    private static final String KEY_PINS = "pinned";
    private static final String KEY_RECENTS = "recents";
    private static final int HOME_COLUMNS = 3;
    private static final int HOME_ROWS = 4;
    private static final int DRAWER_COLUMNS = 3;
    private static final int MAX_RECENTS = 3;

    private final Activity activity;
    private final SharedPreferences prefs;
    private final PackageManager pm;
    private final ArrayList<AppEntry> apps = new ArrayList<>();
    private final ArrayList<String> pinnedKeys = new ArrayList<>();
    private final ArrayList<String> recentKeys = new ArrayList<>();
    private final Map<String, AppEntry> byKey = new HashMap<>();
    private final Paint wallpaperPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private Bitmap wallpaper;
    private int wallpaperTextColor = 0xFF14243A;
    private FrameLayout homeScreen;
    private FrameLayout drawerLayer;
    private LinearLayout drawerSheet;
    private EditText searchBox;
    private GridLayout drawerGrid;
    private LinearLayout recentRow;
    private TextView recentTitle;
    private TextView allAppsTitle;
    private boolean drawerOpen;

    private SimpHomeOverlay(Activity activity) {
        super(activity);
        this.activity = activity;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.pm = activity.getPackageManager();
        setTag(TAG);
        setClipChildren(false);
        setClipToPadding(false);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setWillNotDraw(false);
        setBackgroundColor(Color.TRANSPARENT);
        loadWallpaper();
        loadApps();
        buildHome();
        buildDrawer();
    }

    /** Called by a tiny smali hook after Launcher.setContentView(). */
    public static void install(Activity activity) {
        if (activity == null) return;
        try {
            View host = findLauncherView(activity, "drag_layer");
            if (!(host instanceof ViewGroup)) return; // Fail closed: never cover Quickstep/Recents.
            ViewGroup group = (ViewGroup) host;
            for (int i = 0; i < group.getChildCount(); i++) {
                View child = group.getChildAt(i);
                if (TAG.equals(child.getTag())) return;
            }
            SimpHomeOverlay overlay = new SimpHomeOverlay(activity);
            ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

            // LauncherRecentsView is the overview_panel sibling. Insert immediately before it,
            // so the native Recents view always stays above this Home/App Drawer layer.
            View overview = findLauncherView(activity, "overview_panel");
            if (overview == null || overview.getParent() != group) return;
            int index = group.indexOfChild(overview);
            if (index < 0) return;
            group.addView(overlay, index, lp);

            // Simp's Home screen has no workspace page dots. This is a Home-only element;
            // do not hide or alter overview_panel, RecentsView, TaskView, or Clear All.
            View pageIndicator = findLauncherView(activity, "page_indicator");
            if (pageIndicator != null) pageIndicator.setVisibility(View.GONE);
        } catch (Throwable ignored) {
            // A UI overlay failure must never crash the launcher or Quickstep.
        }
    }

    private static View findLauncherView(Activity activity, String name) {
        int id = activity.getResources().getIdentifier(name, "id", activity.getPackageName());
        if (id == 0) id = activity.getResources().getIdentifier(name, "id", "com.android.launcher3");
        return id == 0 ? null : activity.findViewById(id);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (hasWindowFocus && homeScreen != null) {
            // Refresh the app list after returning from another app or an uninstall dialog.
            try {
                loadApps();
                buildHome();
                if (searchBox != null) refreshDrawerGrid(String.valueOf(searchBox.getText()));
            } catch (Throwable ignored) { }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (wallpaper == null || wallpaper.isRecycled()) return;
        int vw = getWidth();
        int vh = getHeight();
        if (vw <= 0 || vh <= 0) return;
        float scale = Math.max(vw / (float) wallpaper.getWidth(), vh / (float) wallpaper.getHeight());
        int dw = Math.round(wallpaper.getWidth() * scale);
        int dh = Math.round(wallpaper.getHeight() * scale);
        int left = (vw - dw) / 2;
        int top = (vh - dh) / 2;
        Rect dst = new Rect(left, top, left + dw, top + dh);
        canvas.drawBitmap(wallpaper, null, dst, wallpaperPaint);
        canvas.drawColor(0x140B1724);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (drawerOpen && event.getKeyCode() == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_UP) {
            closeDrawer();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void loadWallpaper() {
        try {
            Drawable d = WallpaperManager.getInstance(activity).getDrawable();
            int iw = d == null ? 0 : d.getIntrinsicWidth();
            int ih = d == null ? 0 : d.getIntrinsicHeight();
            if (iw <= 0 || ih <= 0) return;
            int width = Math.min(360, Math.max(160, activity.getResources().getDisplayMetrics().widthPixels / 3));
            int height = Math.max(160, Math.round(width * (float) ih / iw));
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            float scale = Math.max(width / (float) iw, height / (float) ih);
            int dw = Math.round(iw * scale);
            int dh = Math.round(ih * scale);
            d.setBounds((width - dw) / 2, (height - dh) / 2,
                    (width + dw) / 2, (height + dh) / 2);
            d.draw(c);
            blurBitmap(bmp, Math.max(2, Math.min(7, width / 70)));
            wallpaper = bmp;
            wallpaperTextColor = averageLuma(bmp) > 0.55f ? 0xFF14243A : Color.WHITE;
        } catch (Throwable ignored) {
            wallpaper = null;
            wallpaperTextColor = 0xFF14243A;
        }
    }

    private static float averageLuma(Bitmap b) {
        if (b == null) return 0.5f;
        long sum = 0;
        int count = 0;
        int sx = Math.max(1, b.getWidth() / 16);
        int sy = Math.max(1, b.getHeight() / 16);
        for (int y = 0; y < b.getHeight(); y += sy) {
            for (int x = 0; x < b.getWidth(); x += sx) {
                int c = b.getPixel(x, y);
                double r = ((c >> 16) & 255) / 255.0;
                double g = ((c >> 8) & 255) / 255.0;
                double bl = (c & 255) / 255.0;
                sum += (long) (255 * (0.299 * r + 0.587 * g + 0.114 * bl));
                count++;
            }
        }
        return count == 0 ? 0.5f : sum / (255f * count);
    }

    private static void blurBitmap(Bitmap bitmap, int radius) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int[] pixels = new int[w * h];
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h);
        int[] temp = new int[pixels.length];
        int r = Math.max(1, radius);
        for (int pass = 0; pass < 2; pass++) {
            blurPass(pixels, temp, w, h, r, true);
            blurPass(temp, pixels, w, h, r, false);
        }
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    }

    private static void blurPass(int[] src, int[] dst, int w, int h, int r, boolean horizontal) {
        int lines = horizontal ? h : w;
        int length = horizontal ? w : h;
        int stride = horizontal ? 1 : w;
        int window = r * 2 + 1;
        for (int line = 0; line < lines; line++) {
            int base = horizontal ? line * w : line;
            long a = 0, red = 0, green = 0, blue = 0;
            for (int k = -r; k <= r; k++) {
                int idx = base + clamp(k, length) * stride;
                int c = src[idx];
                a += c >>> 24;
                red += (c >>> 16) & 255;
                green += (c >>> 8) & 255;
                blue += c & 255;
            }
            for (int i = 0; i < length; i++) {
                int idx = base + i * stride;
                dst[idx] = ((int) (a / window) << 24) | ((int) (red / window) << 16)
                        | ((int) (green / window) << 8) | (int) (blue / window);
                int out = src[base + clamp(i - r, length) * stride];
                int in = src[base + clamp(i + r + 1, length) * stride];
                a += (in >>> 24) - (out >>> 24);
                red += ((in >>> 16) & 255) - ((out >>> 16) & 255);
                green += ((in >>> 8) & 255) - ((out >>> 8) & 255);
                blue += (in & 255) - (out & 255);
            }
        }
    }

    private static int clamp(int value, int length) {
        return value < 0 ? 0 : Math.min(length - 1, value);
    }

    private void loadApps() {
        apps.clear();
        byKey.clear();
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolved;
        try {
            resolved = pm.queryIntentActivities(query, 0);
        } catch (Throwable t) {
            resolved = Collections.emptyList();
        }
        for (ResolveInfo ri : resolved) {
            if (ri.activityInfo == null || ri.activityInfo.packageName.equals(activity.getPackageName())) continue;
            ComponentName component = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            AppEntry entry = new AppEntry(component, String.valueOf(ri.loadLabel(pm)), ri.loadIcon(pm));
            if (!byKey.containsKey(entry.key)) {
                apps.add(entry);
                byKey.put(entry.key, entry);
            }
        }
        Collections.sort(apps, new Comparator<AppEntry>() {
            @Override public int compare(AppEntry a, AppEntry b) {
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        readKeys(KEY_PINS, pinnedKeys);
        if (pinnedKeys.isEmpty() && !apps.isEmpty()) {
            for (int i = 0; i < Math.min(12, apps.size()); i++) pinnedKeys.add(apps.get(i).key);
            writeKeys(KEY_PINS, pinnedKeys);
        }
        pinnedKeys.retainAll(byKey.keySet());
        readKeys(KEY_RECENTS, recentKeys);
        recentKeys.retainAll(byKey.keySet());
    }

    private void readKeys(String key, ArrayList<String> out) {
        out.clear();
        String raw = prefs.getString(key, "");
        if (raw == null || raw.length() == 0) return;
        for (String value : raw.split("\\|")) if (value.length() > 0 && !out.contains(value)) out.add(value);
    }

    private void writeKeys(String key, List<String> values) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append('|');
            out.append(value);
        }
        prefs.edit().putString(key, out.toString()).apply();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable glassBackground(int alpha, int radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(alpha, 255, 255, 255));
        bg.setCornerRadius(dp(radiusDp));
        bg.setStroke(dp(1), 0x44FFFFFF);
        return bg;
    }

    private TextView label(String text, float size, boolean bold) {
        TextView v = new TextView(activity);
        v.setText(text);
        v.setTextColor(wallpaperTextColor);
        v.setTextSize(size);
        v.setIncludeFontPadding(false);
        if (bold) v.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        return v;
    }

    private void buildHome() {
        FrameLayout home = homeScreen;
        if (home == null) {
            home = new FrameLayout(activity);
            homeScreen = home;
            home.setBackgroundColor(Color.TRANSPARENT);
            addView(home, 0, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        } else {
            home.removeAllViews();
        }

        String date = new SimpleDateFormat("EEEE, d MMMM", new Locale("id", "ID")).format(new Date());
        TextView dateView = label(date, 18f, true);
        FrameLayout.LayoutParams dateLp = new FrameLayout.LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        dateLp.leftMargin = dp(20);
        dateLp.topMargin = dp(18);
        home.addView(dateView, dateLp);

        GridLayout grid = new GridLayout(activity);
        grid.setColumnCount(HOME_COLUMNS);
        grid.setRowCount(HOME_ROWS);
        grid.setUseDefaultMargins(false);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        buildPinnedGrid(grid);
        FrameLayout.LayoutParams gridLp = new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        gridLp.leftMargin = dp(12);
        gridLp.rightMargin = dp(12);
        gridLp.bottomMargin = navigationBottomPadding() + dp(24);
        home.addView(grid, gridLp);

        home.setOnTouchListener(new OnTouchListener() {
            private float startY;
            private float startX;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startY = event.getY();
                    startX = event.getX();
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    float dy = event.getY() - startY;
                    float dx = Math.abs(event.getX() - startX);
                    if (dx < dp(90) && dy < -dp(70)) {
                        openDrawer();
                        return true;
                    }
                    if (dx < dp(90) && dy > dp(90)) {
                        expandNotifications();
                        return true;
                    }
                    return true;
                }
                return true;
            }
        });
    }

    private int navigationBottomPadding() {
        try {
            int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
            return id == 0 ? dp(24) : getResources().getDimensionPixelSize(id);
        } catch (Throwable ignored) {
            return dp(24);
        }
    }

    private void buildPinnedGrid(GridLayout grid) {
        grid.removeAllViews();
        ArrayList<AppEntry> pinned = new ArrayList<>();
        for (String key : pinnedKeys) {
            AppEntry entry = byKey.get(key);
            if (entry != null) pinned.add(entry);
        }
        int max = HOME_COLUMNS * HOME_ROWS;
        int itemCount = Math.min(max, pinned.size());
        int width = getResources().getDisplayMetrics().widthPixels - dp(24);
        for (int i = 0; i < itemCount; i++) {
            final AppEntry entry = pinned.get(i);
            TextView card = label(entry.label, 13.5f, true);
            card.setGravity(Gravity.CENTER);
            card.setMaxLines(1);
            card.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.setPadding(dp(8), dp(4), dp(8), dp(4));
            card.setBackground(glassBackground(166, 16));
            card.setClickable(true);
            card.setFocusable(true);
            card.setOnClickListener(v -> launch(entry));
            card.setOnLongClickListener(v -> {
                showHomeMenu(v, entry);
                return true;
            });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(i / HOME_COLUMNS), GridLayout.spec(i % HOME_COLUMNS, 1f));
            lp.width = 0;
            lp.height = dp(52);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(card, lp);
        }
        if (pinned.isEmpty()) {
            TextView empty = label("Belum ada aplikasi di layar utama", 13f, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(0), GridLayout.spec(0, HOME_COLUMNS, 1f));
            lp.width = width;
            lp.height = dp(52);
            grid.addView(empty, lp);
        }
    }

    private void buildDrawer() {
        drawerLayer = new FrameLayout(activity);
        drawerLayer.setVisibility(View.GONE);
        addView(drawerLayer, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        View dim = new View(activity);
        dim.setBackgroundColor(0x330B1724);
        dim.setOnClickListener(v -> closeDrawer());
        drawerLayer.addView(dim, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        drawerSheet = new LinearLayout(activity);
        drawerSheet.setOrientation(LinearLayout.VERTICAL);
        drawerSheet.setPadding(dp(16), dp(10), dp(16), navigationBottomPadding() + dp(8));
        GradientDrawable sheetBg = new GradientDrawable();
        sheetBg.setColor(wallpaper == null ? 0xEBFFFFFF : 0x80FFFFFF);
        sheetBg.setCornerRadii(new float[] {dp(28), dp(28), dp(28), dp(28), 0, 0, 0, 0});
        sheetBg.setStroke(dp(1), 0x55FFFFFF);
        drawerSheet.setBackground(sheetBg);
        FrameLayout.LayoutParams sheetLp = new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, Math.round(getResources().getDisplayMetrics().heightPixels * 0.78f), Gravity.BOTTOM);
        drawerLayer.addView(drawerSheet, sheetLp);

        View handle = new View(activity);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setColor(0x665B6B7F);
        handleBg.setCornerRadius(dp(8));
        handle.setBackground(handleBg);
        LinearLayout.LayoutParams handleLp = new LinearLayout.LayoutParams(dp(36), dp(4));
        handleLp.gravity = Gravity.CENTER_HORIZONTAL;
        handleLp.bottomMargin = dp(14);
        drawerSheet.addView(handle, handleLp);

        searchBox = new EditText(activity);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(14f);
        searchBox.setTextColor(0xFF14243A);
        searchBox.setHintTextColor(0x995B6B7F);
        searchBox.setHint("Cari aplikasi");
        searchBox.setPadding(dp(16), 0, dp(16), 0);
        searchBox.setBackground(glassBackground(184, 23));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, dp(44));
        searchLp.bottomMargin = dp(14);
        drawerSheet.addView(searchBox, searchLp);

        recentTitle = label("Terakhir dipakai", 12f, true);
        recentTitle.setTextColor(0xFF5B6B7F);
        LinearLayout.LayoutParams recentTitleLp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        recentTitleLp.bottomMargin = dp(7);
        drawerSheet.addView(recentTitle, recentTitleLp);

        recentRow = new LinearLayout(activity);
        recentRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams recentLp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, dp(48));
        recentLp.bottomMargin = dp(14);
        drawerSheet.addView(recentRow, recentLp);

        allAppsTitle = label("Semua aplikasi", 12f, true);
        allAppsTitle.setTextColor(0xFF5B6B7F);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = dp(7);
        drawerSheet.addView(allAppsTitle, titleLp);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        drawerGrid = new GridLayout(activity);
        drawerGrid.setColumnCount(DRAWER_COLUMNS);
        drawerGrid.setUseDefaultMargins(false);
        scroll.addView(drawerGrid, new ScrollView.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        drawerSheet.addView(scroll, new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, 0, 1f));

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshDrawerGrid(String.valueOf(s));
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        handle.setOnTouchListener(new OnTouchListener() {
            private float y;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    y = event.getY();
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getY() - y > dp(35)) closeDrawer();
                    return true;
                }
                return true;
            }
        });
        refreshRecentRow();
        refreshDrawerGrid("");
    }

    private void refreshRecentRow() {
        if (recentRow == null) return;
        recentRow.removeAllViews();
        int count = 0;
        for (String key : recentKeys) {
            AppEntry entry = byKey.get(key);
            if (entry == null || count >= MAX_RECENTS) continue;
            View card = createDrawerCard(entry, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1f);
            if (count > 0) lp.leftMargin = dp(8);
            recentRow.addView(card, lp);
            count++;
        }
        boolean show = count > 0 && (searchBox == null || searchBox.getText().length() == 0);
        recentTitle.setVisibility(show ? View.VISIBLE : View.GONE);
        recentRow.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void refreshDrawerGrid(String query) {
        if (drawerGrid == null) return;
        drawerGrid.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int row = 0;
        int col = 0;
        for (AppEntry entry : apps) {
            if (!q.isEmpty() && !entry.label.toLowerCase(Locale.ROOT).contains(q)) continue;
            View card = createDrawerCard(entry, true);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(row), GridLayout.spec(col, 1f));
            lp.width = 0;
            lp.height = dp(48);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            drawerGrid.addView(card, lp);
            col++;
            if (col >= DRAWER_COLUMNS) {
                col = 0;
                row++;
            }
        }
        if (q.isEmpty()) refreshRecentRow();
        else {
            recentTitle.setVisibility(View.GONE);
            recentRow.setVisibility(View.GONE);
        }
    }

    private View createDrawerCard(AppEntry entry, boolean contextMenu) {
        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(7), 0, dp(6), 0);
        card.setBackground(glassBackground(158, 14));
        card.setClickable(true);
        ImageView icon = new ImageView(activity);
        icon.setImageDrawable(entry.icon);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(30), dp(30));
        iconLp.rightMargin = dp(6);
        card.addView(icon, iconLp);
        TextView name = label(entry.label, 11.5f, true);
        name.setTextColor(0xFF14243A);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(name, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        card.setOnClickListener(v -> launch(entry));
        if (contextMenu) {
            card.setOnLongClickListener(v -> {
                showDrawerMenu(v, entry);
                return true;
            });
        }
        return card;
    }

    private void openDrawer() {
        if (drawerOpen || drawerLayer == null) return;
        drawerOpen = true;
        drawerLayer.setVisibility(View.VISIBLE);
        drawerLayer.setAlpha(0f);
        drawerLayer.setTranslationY(dp(35));
        drawerLayer.animate().alpha(1f).translationY(0f).setDuration(220).start();
        if (searchBox != null) searchBox.setText("");
    }

    private void closeDrawer() {
        if (!drawerOpen || drawerLayer == null) return;
        drawerOpen = false;
        try {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        } catch (Throwable ignored) { }
        drawerLayer.animate().alpha(0f).translationY(dp(35)).setDuration(180)
                .withEndAction(() -> {
                    drawerLayer.setVisibility(View.GONE);
                    drawerLayer.setTranslationY(0f);
                    drawerLayer.setAlpha(1f);
                }).start();
    }

    private void launch(AppEntry entry) {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(entry.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            if (drawerOpen) closeDrawer();
            activity.startActivity(intent);
            recentKeys.remove(entry.key);
            recentKeys.add(0, entry.key);
            while (recentKeys.size() > MAX_RECENTS) recentKeys.remove(recentKeys.size() - 1);
            writeKeys(KEY_RECENTS, recentKeys);
            refreshRecentRow();
        } catch (Throwable ignored) { }
    }

    private void pin(AppEntry entry) {
        if (!pinnedKeys.contains(entry.key)) {
            if (pinnedKeys.size() >= HOME_COLUMNS * HOME_ROWS) {
                android.widget.Toast.makeText(activity, "Layar utama sudah penuh", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            pinnedKeys.add(entry.key);
            writeKeys(KEY_PINS, pinnedKeys);
            buildHome();
            invalidate();
        }
    }

    private void unpin(AppEntry entry) {
        pinnedKeys.remove(entry.key);
        writeKeys(KEY_PINS, pinnedKeys);
        buildHome();
        invalidate();
    }

    private void showHomeMenu(View anchor, AppEntry entry) {
        PopupMenu menu = new PopupMenu(activity, anchor);
        menu.getMenu().add("Info aplikasi").setOnMenuItemClickListener(item -> { openInfo(entry); return true; });
        menu.getMenu().add("Hapus dari layar utama").setOnMenuItemClickListener(item -> { unpin(entry); return true; });
        menu.getMenu().add("Copot pemasangan").setOnMenuItemClickListener(item -> { uninstall(entry); return true; });
        menu.show();
    }

    private void showDrawerMenu(View anchor, AppEntry entry) {
        PopupMenu menu = new PopupMenu(activity, anchor);
        menu.getMenu().add("Tambah ke layar utama").setOnMenuItemClickListener(item -> { pin(entry); return true; });
        menu.getMenu().add("Info aplikasi").setOnMenuItemClickListener(item -> { openInfo(entry); return true; });
        menu.getMenu().add("Copot pemasangan").setOnMenuItemClickListener(item -> { uninstall(entry); return true; });
        menu.show();
    }

    private void openInfo(AppEntry entry) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", entry.component.getPackageName(), null));
            activity.startActivity(intent);
        } catch (Throwable ignored) { }
    }

    private void uninstall(AppEntry entry) {
        try {
            Intent intent = new Intent(Intent.ACTION_DELETE,
                    Uri.fromParts("package", entry.component.getPackageName(), null));
            activity.startActivity(intent);
        } catch (Throwable ignored) { }
    }

    private void expandNotifications() {
        try {
            Object statusBar = activity.getSystemService("statusbar");
            if (statusBar != null) statusBar.getClass().getMethod("expandNotificationsPanel").invoke(statusBar);
        } catch (Throwable ignored) { }
    }

    private static final class AppEntry {
        final ComponentName component;
        final String label;
        final Drawable icon;
        final String key;

        AppEntry(ComponentName component, String label, Drawable icon) {
            this.component = component;
            this.label = label == null ? component.getPackageName() : label;
            this.icon = icon;
            this.key = component.flattenToShortString();
        }
    }
}
