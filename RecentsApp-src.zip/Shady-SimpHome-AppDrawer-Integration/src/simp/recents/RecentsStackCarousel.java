package simp.recents;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Presentation-only Recents carousel controller. The original TaskView and PagedView
 * continue to own task data, gestures, snapping, and lifecycle; this class only applies
 * card transforms and pins Clear All to the Recents viewport.
 */
public final class RecentsStackCarousel {
    private static final float STACK_SPACING = 0.22f;
    private static final float FIRST_BACK_SCALE = 0.88f;
    private static final float SECOND_BACK_SCALE = 0.78f;
    private static final int CLEAR_ALL_MARGIN_DP = 14;
    private static final int CLEAR_ALL_ELEVATION_DP = 32;

    private static final Map<View, Integer> ORIGINAL_VISIBILITY = new WeakHashMap<>();
    private static final Map<View, Float> ORIGINAL_ALPHA = new WeakHashMap<>();

    private RecentsStackCarousel() { }

    /** Called after Launcher has applied its normal TaskView curve transforms. */
    public static void update(ViewGroup recents) {
        if (!isRecentsView(recents) || recents.getWidth() <= 0) return;

        List<View> tasks = taskViews(recents);
        if (!tasks.isEmpty()) applyStack(recents, tasks);
        View clearAll = findClearAllButton(recents);
        if (clearAll != null) positionClearAll(clearAll);
    }

    private static void applyStack(ViewGroup recents, List<View> tasks) {
        int width = tasks.get(0).getWidth();
        if (width <= 0) return;

        float center = recents.getPaddingLeft()
                + (recents.getWidth() - recents.getPaddingLeft() - recents.getPaddingRight()) / 2f;
        float scroll = recents.getScrollX();
        float step = width;
        if (tasks.size() > 1) {
            int measuredStep = Math.abs(tasks.get(1).getLeft() - tasks.get(0).getLeft());
            if (measuredStep > 0) step = measuredStep;
        }
        if (step <= 0) step = width;

        boolean rtl = recents.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        float direction = rtl ? -1f : 1f;
        float[] offsets = new float[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            View task = tasks.get(i);
            float dx = task.getLeft() + task.getWidth() / 2f - scroll - center;
            // In RTL, the next logical PagedView page lies to the left instead.
            float offset = dx / step * direction;
            offsets[i] = offset;
        }

        // Keep every TaskView supplied by RecentsView in the carousel. Compress pages
        // toward the viewport center on BOTH sides so cards remain visible while swiping
        // in either direction; do not impose an artificial three-card visibility limit.
        for (int i = 0; i < tasks.size(); i++) {
            View task = tasks.get(i);
            int original = originalVisibility(task);
            if (original != View.VISIBLE) continue;
            task.setVisibility(View.VISIBLE);

            float distance = Math.abs(offsets[i]);
            float dx = task.getLeft() + task.getWidth() / 2f - scroll - center;
            task.setTranslationX(dx * (STACK_SPACING - 1f));

            float scale;
            float dim;
            if (distance < 0.5f) {
                scale = 1f;
                dim = 1f;
            } else if (distance < 1.5f) {
                scale = FIRST_BACK_SCALE;
                dim = 0.90f;
            } else if (distance < 2.5f) {
                scale = SECOND_BACK_SCALE;
                dim = 0.80f;
            } else {
                // Continue showing distant tasks as progressively smaller, dimmer cards.
                scale = Math.max(0.66f, SECOND_BACK_SCALE - (distance - 2f) * 0.035f);
                dim = Math.max(0.52f, 0.80f - (distance - 2f) * 0.055f);
            }
            task.setScaleX(scale);
            task.setScaleY(scale);
            task.setAlpha(originalAlpha(task) * dim);
            task.setTranslationZ(dp(task, Math.max(1f, 22f - distance * 5f)));
        }
    }

    private static View findClearAllButton(ViewGroup recents) {
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "ClearAllButton".equals(child.getClass().getSimpleName())) return child;
        }
        return null;
    }

    /** Preserve the alpha supplied by Launcher before applying stack dimming. */
    private static float originalAlpha(View view) {
        synchronized (ORIGINAL_ALPHA) {
            Float value = ORIGINAL_ALPHA.get(view);
            if (value == null) {
                value = view.getAlpha();
                ORIGINAL_ALPHA.put(view, value);
            }
            return value;
        }
    }

    private static int originalVisibility(View view) {
        synchronized (ORIGINAL_VISIBILITY) {
            Integer value = ORIGINAL_VISIBILITY.get(view);
            if (value == null) {
                value = view.getVisibility();
                ORIGINAL_VISIBILITY.put(view, value);
            }
            return value;
        }
    }

    private static List<View> taskViews(ViewGroup recents) {
        ArrayList<View> result = new ArrayList<>();
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "TaskView".equals(child.getClass().getSimpleName())) {
                result.add(child);
            }
        }
        return result;
    }

    /** Keep ClearAllButton as its native PagedView child. Reposition only its visual bounds;
     * do not replace its click listener or remove it from the page model. */
    public static void positionClearAll(View clearAll) {
        if (clearAll == null) return;
        ViewParent parent = clearAll.getParent();
        if (!(parent instanceof ViewGroup)) return;
        ViewGroup recents = (ViewGroup) parent;
        if (!isRecentsView(recents) || recents.getWidth() <= 0) return;

        int width = clearAll.getMeasuredWidth();
        int height = clearAll.getMeasuredHeight();
        if (width <= 0 || height <= 0) return;
        int margin = Math.round(CLEAR_ALL_MARGIN_DP
                * recents.getResources().getDisplayMetrics().density);
        int left = recents.getWidth() - recents.getPaddingRight() - margin - width;
        int top = recents.getPaddingTop() + margin;
        if (clearAll.getLeft() != left || clearAll.getTop() != top
                || clearAll.getRight() != left + width || clearAll.getBottom() != top + height) {
            clearAll.layout(left, top, left + width, top + height);
        }
        clearAll.setTranslationX(recents.getScrollX());
        clearAll.setTranslationY(0f);
        clearAll.setTranslationZ(Math.round(CLEAR_ALL_ELEVATION_DP
                * recents.getResources().getDisplayMetrics().density));
    }

    private static boolean isRecentsView(View view) {
        if (view == null) return false;
        Class<?> type = view.getClass();
        while (type != null) {
            if ("com.android.quickstep.views.RecentsView".equals(type.getName())) return true;
            type = type.getSuperclass();
        }
        return false;
    }

    private static float dp(View view, float value) {
        return value * view.getResources().getDisplayMetrics().density;
    }
}
