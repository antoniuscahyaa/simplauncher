#!/usr/bin/env python3
"""Tambahkan hook Home/App Drawer setelah Launcher.setContentView() pada hasil apktool.

Patch ini hanya menambah pemanggilan simp.home.SimpHomeOverlay.install(Activity).
Tidak membuka atau mengubah RecentsView, TaskView, PagedView, Quickstep, atau resource Recents.

Pemakaian: home_ui_patch.py <folder_apktool_decode>
"""
import glob
import os
import re
import sys

ROOT = sys.argv[1]
MARKER = "Lsimp/home/SimpHomeOverlay;->install(Landroid/app/Activity;)V"


def die(message):
    print("GAGAL Home/App Drawer:", message)
    raise SystemExit(1)


matches = []
for folder in glob.glob(os.path.join(ROOT, "smali*")):
    candidate = os.path.join(folder, "com/android/launcher3/Launcher.smali")
    if os.path.isfile(candidate):
        matches.append(candidate)

if len(matches) != 1:
    die("kelas com/android/launcher3/Launcher.smali harus ditemukan tepat satu; ditemukan %d" % len(matches))

path = matches[0]
with open(path, encoding="utf-8") as f:
    source = f.read()

if MARKER in source:
    print("Hook Home/App Drawer sudah ada; tidak ditambahkan ulang.")
    raise SystemExit(0)

method_pattern = re.compile(
    r"(?ms)^\.method[^\n]*\bonCreate\(Landroid/os/Bundle;\)V[^\n]*\n.*?^\.end method"
)
method_match = method_pattern.search(source)
if not method_match:
    die("Launcher.onCreate(Bundle) tidak ditemukan")

method = method_match.group(0)
lines = method.splitlines()
indexes = [i for i, line in enumerate(lines)
           if "->setContentView(Landroid/view/View;)V" in line]
if not indexes:
    die("pemanggilan setContentView(View) tidak ditemukan dalam Launcher.onCreate")

# Call occurs after the launcher root has been attached, so drag_layer can be resolved.
index = indexes[-1]
indent = lines[index][:len(lines[index]) - len(lines[index].lstrip())]
lines.insert(index + 1, indent + "invoke-static {p0}, " + MARKER)
new_method = "\n".join(lines)
new_source = source[:method_match.start()] + new_method + source[method_match.end():]

with open(path, "w", encoding="utf-8") as f:
    f.write(new_source)

print("Hook Home/App Drawer ditambahkan setelah Launcher.setContentView():", os.path.relpath(path, ROOT))
