# Simp-style Home Screen + App Drawer integration

## Scope

This integration adds a native Android View overlay for the Shady Launcher's Home Screen and App Drawer. It is separate from the existing RecentsMod patch and is injected into the existing `ShadyQuickStep.apk` after `Launcher.setContentView()`.

## UI included

- Wallpaper-derived blurred background, with a fallback if wallpaper access is unavailable.
- Date header and a 3-column x 4-row Home Screen card grid.
- Home cards with translucent rounded surfaces and centered app labels.
- Swipe up to open the App Drawer and swipe down to expand notifications.
- Bottom App Drawer sheet with rounded top corners, handle, search field, recent apps row, and all-app grid.
- Tap to launch; long-press menus for app info, uninstall, pin, and unpin.
- Home pins and recent-app history stored in `simp_home_overlay` SharedPreferences.

## Strict Recents boundary

No files under `src/simp/recents/` are changed. No files under `patch/` are changed. `tools/patch.py` is not changed. The new `tools/home_ui_patch.py` only inserts one call in `com.android.launcher3.Launcher.onCreate(Bundle)` after `setContentView(View)`. It does not patch Quickstep, RecentsView, TaskView, PagedView, task layouts, or Clear All.

## Current limitations

- This is a visual Home/App Drawer port, not a full port of SimpLauncher's entire settings surface.
- The custom Home grid currently supports up to 12 pinned apps; native Workspace widgets and folders are not presented on the overlay.
- Home grid drag-reordering, icon-pack mapping, and the full SimpLauncher settings screens are not included in this initial port.
- The build has not been run in this environment because Android SDK/build-tools and apktool are unavailable. The post-decode hook fails closed if it cannot locate the exact Launcher class and `setContentView(View)` call.
- The overlay is inserted immediately before the `overview_panel` child in `DragLayer`; the native Quickstep Recents view remains above it. Only the Home page-indicator view is hidden. Installation fails closed if it cannot find the expected `DragLayer` and `overview_panel`.
- Device verification is still required for Shady's QuickStep transitions on Android 10.
