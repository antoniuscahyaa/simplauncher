package simp.recents;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewParent;

/**
 * Latar Recents: wallpaper yang di-blur (tanpa API blur window, jadi jalan di Android 10)
 * ditambah lapisan scrim gelap. Intensitas diambil dari RecentsPrefs.
 */
public class BlurScrimDrawable extends Drawable {

    private static final int BLUR_W = 160;
    private static final int SHARP_W = 540;
    private static final int FALLBACK = 0xFF1B2733;

    private static Bitmap sBitmap;
    private static int sBlur = -1;
    private static int sWallpaperId = -1;
    private static int sWidth;

    private final Context mContext;
    private final Paint mPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect mSrc = new Rect();
    private int mScrimAlpha;

    public BlurScrimDrawable(Context context) {
        mContext = context.getApplicationContext();
        reload();
    }

    /** Pasang sebagai background RecentsView (atau root window bila tidak ketemu). */
    public static void install(View from) {
        View target = null;
        ViewParent p = from.getParent();
        while (p instanceof View) {
            View v = (View) p;
            if (v.getClass().getSimpleName().contains("RecentsView")) {
                target = v;
                break;
            }
            target = v;
            p = v.getParent();
        }
        if (target == null) {
            return;
        }
        Drawable bg = target.getBackground();
        if (bg instanceof BlurScrimDrawable) {
            ((BlurScrimDrawable) bg).reload();
        } else {
            target.setBackground(new BlurScrimDrawable(from.getContext()));
        }
    }

    /** Baca ulang pengaturan dan bangun ulang bitmap blur bila perlu. */
    public void reload() {
        try {
            int blur = RecentsPrefs.blur(mContext);
            int scrim = RecentsPrefs.scrim(mContext);
            mScrimAlpha = scrim * 255 / 100;
            WallpaperManager wm = WallpaperManager.getInstance(mContext);
            int id = -1;
            try {
                id = wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM);
            } catch (Throwable ignored) {
            }
            if (sBitmap == null || blur != sBlur || id != sWallpaperId) {
                sBitmap = build(wm, blur);
                sBlur = blur;
                sWallpaperId = id;
            }
        } catch (Throwable t) {
            sBitmap = null;
        }
        invalidateSelf();
    }

    private Bitmap build(WallpaperManager wm, int blur) {
        DisplayMetrics dm = mContext.getResources().getDisplayMetrics();
        int w = blur == 0 ? SHARP_W : BLUR_W;
        int h = Math.max(1, Math.round(w * (float) Math.max(dm.heightPixels, dm.widthPixels)
                / Math.min(dm.heightPixels, dm.widthPixels)));
        Drawable wp = null;
        try {
            wp = wm.getDrawable();
        } catch (Throwable ignored) {
        }
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        int iw = wp == null ? 0 : wp.getIntrinsicWidth();
        int ih = wp == null ? 0 : wp.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) {
            c.drawColor(FALLBACK);
            return bmp;
        }
        float s = Math.max((float) w / iw, (float) h / ih);
        int dw = Math.round(iw * s);
        int dh = Math.round(ih * s);
        int l = (w - dw) / 2;
        int t = (h - dh) / 2;
        wp.setBounds(l, t, l + dw, t + dh);
        wp.draw(c);
        if (blur > 0) {
            int[] px = new int[w * h];
            bmp.getPixels(px, 0, w, 0, 0, w, h);
            BoxBlur.blur(px, w, h, Math.max(1, Math.round(blur * 0.16f)));
            bmp.setPixels(px, 0, w, 0, 0, w, h);
        }
        return bmp;
    }

    @Override
    public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.isEmpty()) {
            return;
        }
        Bitmap bmp = sBitmap;
        if (bmp == null) {
            canvas.drawColor(FALLBACK);
        } else {
            float br = (float) b.width() / b.height();
            float sr = (float) bmp.getWidth() / bmp.getHeight();
            if (sr > br) {
                int sw = Math.round(bmp.getHeight() * br);
                int x = (bmp.getWidth() - sw) / 2;
                mSrc.set(x, 0, x + sw, bmp.getHeight());
            } else {
                int sh = Math.round(bmp.getWidth() / br);
                int y = (bmp.getHeight() - sh) / 2;
                mSrc.set(0, y, bmp.getWidth(), y + sh);
            }
            canvas.drawBitmap(bmp, mSrc, b, mPaint);
        }
        if (mScrimAlpha > 0) {
            canvas.drawColor(Color.argb(mScrimAlpha, 0, 0, 0));
        }
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.OPAQUE;
    }
}
