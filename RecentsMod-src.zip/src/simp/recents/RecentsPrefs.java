package simp.recents;

import android.content.Context;
import android.content.SharedPreferences;

/** Penyimpanan pengaturan blur dan scrim (0..100). */
public final class RecentsPrefs {
    public static final String FILE = "recents_mod";
    public static final String KEY_BLUR = "blur";
    public static final String KEY_SCRIM = "scrim";
    public static final int DEF_BLUR = 60;
    public static final int DEF_SCRIM = 25;

    private RecentsPrefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int blur(Context c) {
        return clamp(sp(c).getInt(KEY_BLUR, DEF_BLUR));
    }

    public static int scrim(Context c) {
        return clamp(sp(c).getInt(KEY_SCRIM, DEF_SCRIM));
    }

    public static void save(Context c, int blur, int scrim) {
        sp(c).edit().putInt(KEY_BLUR, clamp(blur)).putInt(KEY_SCRIM, clamp(scrim)).commit();
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 100 ? 100 : v);
    }
}
