package simp.recents;

import android.content.Context;
import android.content.SharedPreferences;

/** Penyimpanan pengaturan blur dan scrim (0..100). */
public final class RecentsPrefs {
    public static final String FILE = "recents_mod";
    public static final String KEY_BLUR = "blur";
    public static final String KEY_SCRIM = "scrim";
    public static final int DEF_BLUR = 60;
    public static final int DEF_SCRIM = 25;
    /** Tinggi sheet app drawer dalam persen tinggi layar (40..100). */
    public static final String KEY_SHEET = "drawer_sheet_pct";
    public static final int DEF_SHEET = 75;
    public static final int MIN_SHEET = 40;

    /** Ukuran font umum (sp) kartu homescreen / drawer; 0 = bawaan. Font manual per kartu (CardFont) diutamakan. */
    public static final String KEY_FONT_HOME = "font_home";
    public static final String KEY_FONT_DRAWER = "font_drawer";

    /** Opsi: tampilkan ikon aplikasi di kiri label kartu homescreen (bawaan: mati). */
    public static final String KEY_HOME_ICON = "home_show_icon";

    private RecentsPrefs() {}

    public static boolean homeIcon(Context c) {
        return sp(c).getBoolean(KEY_HOME_ICON, false);
    }

    public static void saveHomeIcon(Context c, boolean on) {
        sp(c).edit().putBoolean(KEY_HOME_ICON, on).commit();
    }

    /** @param display 0 = homescreen, 1 = drawer */
    public static float fontSp(Context c, int display) {
        return sp(c).getFloat(display == 0 ? KEY_FONT_HOME : KEY_FONT_DRAWER, 0f);
    }

    public static void saveFontSp(Context c, int display, float v) {
        sp(c).edit().putFloat(display == 0 ? KEY_FONT_HOME : KEY_FONT_DRAWER, v < 0f ? 0f : v).commit();
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int blur(Context c) {
        return clamp(sp(c).getInt(KEY_BLUR, DEF_BLUR));
    }

    public static int scrim(Context c) {
        return clamp(sp(c).getInt(KEY_SCRIM, DEF_SCRIM));
    }

    public static int sheetPct(Context c) {
        int v = sp(c).getInt(KEY_SHEET, DEF_SHEET);
        return v < MIN_SHEET ? MIN_SHEET : (v > 100 ? 100 : v);
    }

    public static void saveSheet(Context c, int pct) {
        sp(c).edit().putInt(KEY_SHEET, pct < MIN_SHEET ? MIN_SHEET : (pct > 100 ? 100 : pct)).commit();
    }

    public static void save(Context c, int blur, int scrim) {
        sp(c).edit().putInt(KEY_BLUR, clamp(blur)).putInt(KEY_SCRIM, clamp(scrim)).commit();
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : (v > 100 ? 100 : v);
    }
}
