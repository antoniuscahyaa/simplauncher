package simp.recents;

/** Blur kotak 3 putaran (hampir sama dengan gaussian). Java murni, tanpa API Android. */
public final class BoxBlur {
    private BoxBlur() {}

    public static void blur(int[] pix, int w, int h, int radius) {
        if (radius < 1 || w < 2 || h < 2) return;
        int[] tmp = new int[pix.length];
        for (int i = 0; i < 3; i++) {
            pass(pix, tmp, w, h, radius, true);
            pass(tmp, pix, w, h, radius, false);
        }
    }

    private static void pass(int[] src, int[] dst, int w, int h, int r, boolean horiz) {
        int lines = horiz ? h : w;
        int len = horiz ? w : h;
        int stride = horiz ? 1 : w;
        int win = 2 * r + 1;
        for (int l = 0; l < lines; l++) {
            int base = horiz ? l * w : l;
            long sa = 0, sr = 0, sg = 0, sb = 0;
            for (int k = -r; k <= r; k++) {
                int c = src[base + clamp(k, len) * stride];
                sa += c >>> 24; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255;
            }
            for (int i = 0; i < len; i++) {
                dst[base + i * stride] = (int) (sa / win) << 24 | (int) (sr / win) << 16
                        | (int) (sg / win) << 8 | (int) (sb / win);
                int out = src[base + clamp(i - r, len) * stride];
                int in = src[base + clamp(i + r + 1, len) * stride];
                sa += (in >>> 24) - (out >>> 24);
                sr += ((in >> 16) & 255) - ((out >> 16) & 255);
                sg += ((in >> 8) & 255) - ((out >> 8) & 255);
                sb += (in & 255) - (out & 255);
            }
        }
    }

    private static int clamp(int v, int len) {
        return v < 0 ? 0 : (v >= len ? len - 1 : v);
    }
}
