package simp.recents;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Log diagnostik ke logcat (tag RecentsMod) sekaligus ke berkas recentsmod.log di folder
 * file eksternal aplikasi launcher (Android/data/&lt;paket launcher&gt;/files/), supaya bisa
 * dikirim tanpa adb. Ukuran dibatasi 256 KB.
 */
final class RecentsLog {
    private static final String TAG = "RecentsMod";
    private static final String FILE_NAME = "recentsmod.log";
    private static final long MAX_BYTES = 256L * 1024L;

    private static final StringBuilder BUFFER = new StringBuilder();
    private static final SimpleDateFormat TIME =
            new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private static File sFile;
    private static boolean sResolved;

    private RecentsLog() { }

    static synchronized void init(Context context) {
        if (sResolved || context == null) return;
        sResolved = true;
        try {
            File dir = context.getExternalFilesDir(null);
            if (dir == null) dir = context.getFilesDir();
            sFile = new File(dir, FILE_NAME);
            if (sFile.exists() && sFile.length() > MAX_BYTES) sFile.delete();
            BUFFER.append("---- sesi baru uptime=").append(SystemClock.uptimeMillis())
                    .append(" berkas=").append(sFile.getAbsolutePath()).append('\n');
            Log.d(TAG, "log berkas: " + sFile.getAbsolutePath());
        } catch (Throwable error) {
            Log.w(TAG, "log berkas tidak tersedia", error);
        }
    }

    static synchronized void line(String message) {
        Log.d(TAG, message);
        BUFFER.append(TIME.format(new Date())).append(' ').append(message).append('\n');
        if (BUFFER.length() > 8192) flush();
    }

    static synchronized void flush() {
        if (sFile == null || BUFFER.length() == 0) return;
        try {
            if (sFile.exists() && sFile.length() > MAX_BYTES) {
                sFile.delete();
            }
            FileWriter writer = new FileWriter(sFile, true);
            try {
                writer.write(BUFFER.toString());
            } finally {
                writer.close();
            }
        } catch (Throwable error) {
            Log.w(TAG, "gagal menulis log", error);
        } finally {
            BUFFER.setLength(0);
        }
    }
}
