package simp.recents;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Layar pengaturan: slider intensitas blur dan kegelapan scrim, dengan pratinjau langsung. */
public class RecentsSettingsActivity extends Activity {

    private BlurScrimDrawable mPreview;
    private SeekBar mBlurBar;
    private SeekBar mScrimBar;
    private TextView mBlurVal;
    private TextView mScrimVal;
    private SeekBar mSheetBar;
    private TextView mSheetVal;
    private SeekBar mFontHomeBar;
    private SeekBar mFontDrawerBar;
    private TextView mFontHomeVal;
    private TextView mFontDrawerVal;
    private TextView mPermText;
    private Switch mHomeIcon;
    private Button mPermBtn;
    private static final String PERM = "android.permission.READ_EXTERNAL_STORAGE";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        mPreview = new BlurScrimDrawable(this);
        getWindow().setBackgroundDrawable(mPreview);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = text("Blur dan scrim Recents", 20, true);
        root.addView(title);

        mBlurVal = text("", 14, false);
        root.addView(spacer(d, 24));
        root.addView(text("Intensitas blur", 15, true));
        root.addView(mBlurVal);
        mBlurBar = bar(RecentsPrefs.blur(this));
        root.addView(mBlurBar);

        mScrimVal = text("", 14, false);
        root.addView(spacer(d, 16));
        root.addView(text("Kegelapan scrim (hitam transparan)", 15, true));
        root.addView(mScrimVal);
        mScrimBar = bar(RecentsPrefs.scrim(this));
        root.addView(mScrimBar);
        root.addView(text("0% tanpa gelap · 25% ringan (default) · 50% sedang · 100% hitam penuh", 11, false));

        mSheetVal = text("", 14, false);
        root.addView(spacer(d, 16));
        root.addView(text("Tinggi app drawer (sheet)", 15, true));
        root.addView(mSheetVal);
        mSheetBar = new SeekBar(this);
        mSheetBar.setMax(100 - RecentsPrefs.MIN_SHEET);
        mSheetBar.setProgress(RecentsPrefs.sheetPct(this) - RecentsPrefs.MIN_SHEET);
        mSheetBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                mSheetVal.setText((p + RecentsPrefs.MIN_SHEET) + "% tinggi layar");
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                RecentsPrefs.saveSheet(RecentsSettingsActivity.this, sb.getProgress() + RecentsPrefs.MIN_SHEET);
            }
        });
        root.addView(mSheetBar);
        root.addView(text("50% setengah layar · 75% tiga perempat (default) · 100% penuh. Berlaku setelah drawer ditutup lalu dibuka lagi.", 11, false));

        // Font umum kartu. Font manual per kartu (tekan lama kartu -> Ubah kartu -> Ukuran font) tetap diutamakan.
        root.addView(spacer(d, 16));
        root.addView(text("Ukuran font kartu homescreen (semua)", 15, true));
        mFontHomeVal = text("", 14, false);
        root.addView(mFontHomeVal);
        mFontHomeBar = fontBar(0, mFontHomeVal);
        root.addView(mFontHomeBar);

        root.addView(spacer(d, 16));
        root.addView(spacer(d, 16));
        mHomeIcon = new Switch(this);
        mHomeIcon.setText("Tampilkan ikon di kartu homescreen");
        mHomeIcon.setTextSize(15);
        mHomeIcon.setChecked(RecentsPrefs.homeIcon(this));
        mHomeIcon.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                simp.home.HomeCards.setShowIcon(RecentsSettingsActivity.this, on);
            }
        });
        root.addView(mHomeIcon);
        root.addView(text("Mati (bawaan): kartu hanya berisi nama aplikasi. Hidup: ikon aplikasi tampil di kiri nama. Hanya homescreen; berlaku seketika.", 11, false));

        root.addView(text("Ukuran font kartu app drawer (semua)", 15, true));
        mFontDrawerVal = text("", 14, false);
        root.addView(mFontDrawerVal);
        mFontDrawerBar = fontBar(1, mFontDrawerVal);
        root.addView(mFontDrawerBar);
        root.addView(text("Geser ke paling kiri = ukuran bawaan. Kartu yang font-nya diatur manual (tekan lama kartu → Ubah kartu → Ukuran font) tidak ikut berubah.", 11, false));

        Button reset = new Button(this);
        reset.setText("Kembalikan default");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBlurBar.setProgress(RecentsPrefs.DEF_BLUR);
                mScrimBar.setProgress(RecentsPrefs.DEF_SCRIM);
                mSheetBar.setProgress(RecentsPrefs.DEF_SHEET - RecentsPrefs.MIN_SHEET);
                mFontHomeBar.setProgress(0);
                mFontDrawerBar.setProgress(0);
                mHomeIcon.setChecked(false);
            }
        });
        root.addView(spacer(d, 24));
        root.addView(reset);

        // Blur (Recents dan kartu homescreen) membaca wallpaper; tanpa izin ini Android 10 menolak dan blur jatuh ke warna datar.
        root.addView(spacer(d, 24));
        root.addView(text("Akses wallpaper (untuk blur)", 15, true));
        mPermText = text("", 12, false);
        root.addView(mPermText);
        mPermBtn = new Button(this);
        mPermBtn.setText("Beri izin");
        mPermBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[] {PERM}, 1);
            }
        });
        root.addView(mPermBtn);

        TextView hint = text("Perubahan tersimpan otomatis dan berlaku saat Recents dibuka lagi.", 12, false);
        root.addView(spacer(d, 12));
        root.addView(hint);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
        updateLabels();
        mSheetVal.setText(RecentsPrefs.sheetPct(this) + "% tinggi layar");
    }

    /** Progress 0 = bawaan; selain itu MIN_SP + (p - 1) * 0.5 sp. Disimpan saat slider dilepas. */
    private SeekBar fontBar(final int display, final TextView label) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(1 + Math.round((simp.home.CardFont.MAX_SP - simp.home.CardFont.MIN_SP) / 0.5f));
        float cur = RecentsPrefs.fontSp(this, display);
        sb.setProgress(cur <= 0f ? 0 : 1 + Math.round((cur - simp.home.CardFont.MIN_SP) / 0.5f));
        label.setText(fontLabel(sb.getProgress()));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int p, boolean fromUser) {
                label.setText(fontLabel(p));
                if (!fromUser) simp.home.CardFont.setGlobal(RecentsSettingsActivity.this, display, fontValue(p));
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                simp.home.CardFont.setGlobal(RecentsSettingsActivity.this, display, fontValue(bar.getProgress()));
            }
        });
        return sb;
    }

    private static float fontValue(int progress) {
        return progress <= 0 ? 0f : simp.home.CardFont.MIN_SP + (progress - 1) * 0.5f;
    }

    private static String fontLabel(int progress) {
        if (progress <= 0) return "Bawaan";
        float v = fontValue(progress);
        return (v == (int) v ? String.valueOf((int) v) : String.valueOf(v).replace('.', ',')) + " sp";
    }

    private void updatePerm() {
        boolean ok = checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
        mPermText.setText(ok ? "Sudah diizinkan: blur memakai wallpaper Anda."
                : "Belum diizinkan: blur tidak bisa membaca wallpaper, kartu homescreen memakai warna datar dan latar Recents gelap polos.");
        mPermBtn.setVisibility(ok ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePerm();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        updatePerm();
        mPreview.reload();
    }

    private SeekBar bar(int value) {
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                updateLabels();
                // Scrim preview is rendered immediately while the user moves the slider.
                if (sb == mScrimBar && mPreview != null) {
                    mPreview.setScrimPercent(p);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                save();
            }
        });
        return s;
    }

    private void updateLabels() {
        mBlurVal.setText(mBlurBar.getProgress() + "%");
        mScrimVal.setText(mScrimBar.getProgress() + "%");
        mPreview.setScrimPercent(mScrimBar.getProgress());
    }

    private void save() {
        RecentsPrefs.saveSheet(this, mSheetBar.getProgress() + RecentsPrefs.MIN_SHEET);
        RecentsPrefs.save(this, mBlurBar.getProgress(), mScrimBar.getProgress());
        mPreview.reload();
    }

    @Override
    protected void onPause() {
        save();
        super.onPause();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        }
        return t;
    }

    private View spacer(float d, int dp) {
        View v = new View(this);
        v.setLayoutParams(new ViewGroup.LayoutParams(1, (int) (dp * d)));
        return v;
    }
}
