package simp.recents;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Layar pengaturan: slider intensitas blur dan kegelapan scrim, dengan pratinjau langsung. */
public class RecentsSettingsActivity extends Activity {

    private BlurScrimDrawable mPreview;
    private SeekBar mBlurBar;
    private SeekBar mScrimBar;
    private TextView mBlurVal;
    private TextView mScrimVal;
    private SeekBar mSheetBar;
    private TextView mSheetVal;
    private TextView mPermText;
    private Button mPermBtn;
    private static final String PERM = "android.permission.READ_EXTERNAL_STORAGE";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        mPreview = new BlurScrimDrawable(this);
        getWindow().setBackgroundDrawable(mPreview);

        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = text("Blur dan scrim Recents", 20, true);
        root.addView(title);

        mBlurVal = text("", 14, false);
        root.addView(spacer(d, 24));
        root.addView(text("Intensitas blur", 15, true));
        root.addView(mBlurVal);
        mBlurBar = bar(RecentsPrefs.blur(this));
        root.addView(mBlurBar);

        mScrimVal = text("", 14, false);
        root.addView(spacer(d, 16));
        root.addView(text("Kegelapan scrim (hitam transparan)", 15, true));
        root.addView(mScrimVal);
        mScrimBar = bar(RecentsPrefs.scrim(this));
        root.addView(mScrimBar);
        root.addView(text("0% tanpa gelap · 25% ringan (default) · 50% sedang · 100% hitam penuh", 11, false));

        mSheetVal = text("", 14, false);
        root.addView(spacer(d, 16));
        root.addView(text("Tinggi app drawer (sheet)", 15, true));
        root.addView(mSheetVal);
        mSheetBar = new SeekBar(this);
        mSheetBar.setMax(100 - RecentsPrefs.MIN_SHEET);
        mSheetBar.setProgress(RecentsPrefs.sheetPct(this) - RecentsPrefs.MIN_SHEET);
        mSheetBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                mSheetVal.setText((p + RecentsPrefs.MIN_SHEET) + "% tinggi layar");
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                RecentsPrefs.saveSheet(RecentsSettingsActivity.this, sb.getProgress() + RecentsPrefs.MIN_SHEET);
            }
        });
        root.addView(mSheetBar);
        root.addView(text("50% setengah layar · 75% tiga perempat (default) · 100% penuh. Berlaku setelah drawer ditutup lalu dibuka lagi.", 11, false));

        Button reset = new Button(this);
        reset.setText("Kembalikan default");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mBlurBar.setProgress(RecentsPrefs.DEF_BLUR);
                mScrimBar.setProgress(RecentsPrefs.DEF_SCRIM);
                mSheetBar.setProgress(RecentsPrefs.DEF_SHEET - RecentsPrefs.MIN_SHEET);
            }
        });
        root.addView(spacer(d, 24));
        root.addView(reset);

        // Blur (Recents dan kartu homescreen) membaca wallpaper; tanpa izin ini Android 10 menolak dan blur jatuh ke warna datar.
        root.addView(spacer(d, 24));
        root.addView(text("Akses wallpaper (untuk blur)", 15, true));
        mPermText = text("", 12, false);
        root.addView(mPermText);
        mPermBtn = new Button(this);
        mPermBtn.setText("Beri izin");
        mPermBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[] {PERM}, 1);
            }
        });
        root.addView(mPermBtn);

        TextView hint = text("Perubahan tersimpan otomatis dan berlaku saat Recents dibuka lagi.", 12, false);
        root.addView(spacer(d, 12));
        root.addView(hint);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
        updateLabels();
        mSheetVal.setText(RecentsPrefs.sheetPct(this) + "% tinggi layar");
    }

    private void updatePerm() {
        boolean ok = checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
        mPermText.setText(ok ? "Sudah diizinkan: blur memakai wallpaper Anda."
                : "Belum diizinkan: blur tidak bisa membaca wallpaper, kartu homescreen memakai warna datar dan latar Recents gelap polos.");
        mPermBtn.setVisibility(ok ? View.GONE : View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePerm();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        updatePerm();
        mPreview.reload();
    }

    private SeekBar bar(int value) {
        SeekBar s = new SeekBar(this);
        s.setMax(100);
        s.setProgress(value);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                updateLabels();
                // Scrim preview is rendered immediately while the user moves the slider.
                if (sb == mScrimBar && mPreview != null) {
                    mPreview.setScrimPercent(p);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                save();
            }
        });
        return s;
    }

    private void updateLabels() {
        mBlurVal.setText(mBlurBar.getProgress() + "%");
        mScrimVal.setText(mScrimBar.getProgress() + "%");
        mPreview.setScrimPercent(mScrimBar.getProgress());
    }

    private void save() {
        RecentsPrefs.saveSheet(this, mSheetBar.getProgress() + RecentsPrefs.MIN_SHEET);
        RecentsPrefs.save(this, mBlurBar.getProgress(), mScrimBar.getProgress());
        mPreview.reload();
    }

    @Override
    protected void onPause() {
        save();
        super.onPause();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        }
        return t;
    }

    private View spacer(float d, int dp) {
        View v = new View(this);
        v.setLayoutParams(new ViewGroup.LayoutParams(1, (int) (dp * d)));
        return v;
    }
}
