package simp.recents;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Presentation-only Recents carousel controller. The original TaskView and PagedView
 * continue to own task data, gestures, snapping, and lifecycle; this class only applies
 * card transforms and pins Clear All to the Recents viewport.
 */
public final class RecentsStackCarousel {
    private static final float STACK_SPACING = 0.22f;
    private static final float FIRST_BACK_SCALE = 0.88f;
    private static final float SECOND_BACK_SCALE = 0.78f;
    private static final String TAG = "RecentsMod";
    private static final int CLEAR_ALL_MARGIN_DP = 12;
    private static final int CLEAR_ALL_GAP_DP = 10;
    private static final int CLEAR_ALL_ELEVATION_DP = 32;
    /** Awal animasi masuk: kartu sedikit lebih kecil, tombol Hapus semua naik separuh jarak. */
    private static final float ENTRY_SCALE_FROM = 0.94f;
    private static final float CLEAR_ALL_TRAVEL = 0.5f;

    private static final Map<View, Integer> ORIGINAL_VISIBILITY = new WeakHashMap<>();
    private static final Map<View, Float> ORIGINAL_ALPHA = new WeakHashMap<>();
    // Offset vertikal animasi masuk: translationY terakhir yang kita tulis dan bagian dy-nya,
    // supaya nilai translationY milik Launcher (animasi dismiss dsb.) tidak ikut tertimpa.
    private static final Map<View, Float> TY_ABS = new WeakHashMap<>();
    private static final Map<View, Float> TY_DY = new WeakHashMap<>();
    private static final Map<View, Float> CLEAR_ALL_ALPHA = new WeakHashMap<>();
    private static Method sSetVisibilityAlpha;
    private static boolean sVisibilityAlphaResolved;
    private static int sLoggedTop = Integer.MIN_VALUE;
    private static int sLoggedLeft = Integer.MIN_VALUE;

    private RecentsStackCarousel() { }

    /** Called after Launcher has applied its normal TaskView curve transforms. */
    public static void update(ViewGroup recents) {
        if (!isRecentsView(recents) || recents.getWidth() <= 0) return;

        List<View> tasks = taskViews(recents);
        if (!tasks.isEmpty()) applyStack(recents, tasks);
        View clearAll = findClearAllButton(recents);
        if (clearAll != null) positionClearAll(clearAll);
    }

    private static void applyStack(ViewGroup recents, List<View> tasks) {
        int width = tasks.get(0).getWidth();
        if (width <= 0) return;
        float travel = RecentsMotion.travelPx(recents);

        float center = recents.getPaddingLeft()
                + (recents.getWidth() - recents.getPaddingLeft() - recents.getPaddingRight()) / 2f;
        float scroll = recents.getScrollX();
        float step = width;
        if (tasks.size() > 1) {
            int measuredStep = Math.abs(tasks.get(1).getLeft() - tasks.get(0).getLeft());
            if (measuredStep > 0) step = measuredStep;
        }
        if (step <= 0) step = width;

        boolean rtl = recents.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        float direction = rtl ? -1f : 1f;
        float[] offsets = new float[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            View task = tasks.get(i);
            float dx = task.getLeft() + task.getWidth() / 2f - scroll - center;
            // In RTL, the next logical PagedView page lies to the left instead.
            float offset = dx / step * direction;
            offsets[i] = offset;
        }

        // Keep every TaskView supplied by RecentsView in the carousel. Compress pages
        // toward the viewport center on BOTH sides so cards remain visible while swiping
        // in either direction; do not impose an artificial three-card visibility limit.
        for (int i = 0; i < tasks.size(); i++) {
            View task = tasks.get(i);
            int original = originalVisibility(task);
            if (original != View.VISIBLE) continue;
            task.setVisibility(View.VISIBLE);

            float distance = Math.abs(offsets[i]);
            float dx = task.getLeft() + task.getWidth() / 2f - scroll - center;
            task.setTranslationX(dx * (STACK_SPACING - 1f));

            // Skala dan redup berubah kontinu terhadap jarak dari tengah (tanpa lompatan
            // di ambang 0,5 / 1,5 / 2,5 seperti sebelumnya), jadi geser antar kartu halus.
            float scale = scaleFor(distance);
            float dim = dimFor(distance);

            // Animasi buka/tutup Recents (vertikal). p = 1 saat tidak ada animasi.
            float p = RecentsMotion.cardFactor(recents, distance);
            scale *= ENTRY_SCALE_FROM + (1f - ENTRY_SCALE_FROM) * p;
            task.setScaleX(scale);
            task.setScaleY(scale);
            task.setAlpha(originalAlpha(task) * dim * p);
            applyEntryOffset(task, (1f - p) * travel);

            // Kartu paling dekat dengan tengah harus menang pada hit-testing kartu yang
            // bertumpuk: Z menurun monoton terhadap jarak, jadi swipe-up membuang kartu yang
            // sama dengan yang tampak di tengah.
            float z = distance < 1f
                    ? 120f - 96f * distance
                    : Math.max(1f, 24f - (distance - 1f) * 3f);
            task.setTranslationZ(dp(task, z));
        }
    }

    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    private static float scaleFor(float d) {
        if (d < 1f) return lerp(1f, FIRST_BACK_SCALE, d);
        if (d < 2f) return lerp(FIRST_BACK_SCALE, SECOND_BACK_SCALE, d - 1f);
        return Math.max(0.66f, SECOND_BACK_SCALE - (d - 2f) * 0.035f);
    }

    private static float dimFor(float d) {
        if (d < 1f) return lerp(1f, 0.90f, d);
        if (d < 2f) return lerp(0.90f, 0.80f, d - 1f);
        return Math.max(0.52f, 0.80f - (d - 2f) * 0.055f);
    }

    /** Tambahkan dy ke translationY Launcher tanpa menimpa nilai aslinya. */
    private static void applyEntryOffset(View view, float dy) {
        float cur = view.getTranslationY();
        Float abs = TY_ABS.get(view);
        Float last = TY_DY.get(view);
        float base = (abs != null && last != null && Math.abs(cur - abs) < 0.01f)
                ? cur - last : cur;
        float next = base + dy;
        if (Math.abs(next - cur) > 0.001f) view.setTranslationY(next);
        TY_ABS.put(view, next);
        TY_DY.put(view, dy);
    }

    private static View findClearAllButton(ViewGroup recents) {
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "ClearAllButton".equals(child.getClass().getSimpleName())) return child;
        }
        return null;
    }

    /** Preserve the alpha supplied by Launcher before applying stack dimming. */
    private static float originalAlpha(View view) {
        synchronized (ORIGINAL_ALPHA) {
            Float value = ORIGINAL_ALPHA.get(view);
            if (value == null) {
                value = view.getAlpha();
                ORIGINAL_ALPHA.put(view, value);
            }
            return value;
        }
    }

    private static int originalVisibility(View view) {
        synchronized (ORIGINAL_VISIBILITY) {
            Integer value = ORIGINAL_VISIBILITY.get(view);
            if (value == null) {
                value = view.getVisibility();
                ORIGINAL_VISIBILITY.put(view, value);
            }
            return value;
        }
    }

    private static List<View> taskViews(ViewGroup recents) {
        ArrayList<View> result = new ArrayList<>();
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "TaskView".equals(child.getClass().getSimpleName())) {
                result.add(child);
            }
        }
        return result;
    }

    /**
     * Hapus semua: tetap child native PagedView (listener klik bawaan tidak disentuh), hanya
     * posisi visualnya yang dipindah ke ruang kosong di bawah kartu, di tengah horizontal.
     * Tombol selalu terlihat di semua kartu (patch_recents_motion.py membuat alpha-scroll
     * bawaan selalu 1, sehingga tidak lagi hanya muncul di kartu paling kiri).
     */
    public static void positionClearAll(View clearAll) {
        if (clearAll == null) return;
        ViewParent parent = clearAll.getParent();
        if (!(parent instanceof ViewGroup)) return;
        ViewGroup recents = (ViewGroup) parent;
        if (!isRecentsView(recents) || recents.getWidth() <= 0) return;

        int width = clearAll.getMeasuredWidth();
        int height = clearAll.getMeasuredHeight();
        if (width <= 0 || height <= 0) return;
        float density = recents.getResources().getDisplayMetrics().density;
        int margin = Math.round(CLEAR_ALL_MARGIN_DP * density);
        int gap = Math.round(CLEAR_ALL_GAP_DP * density);

        int innerWidth = recents.getWidth() - recents.getPaddingLeft() - recents.getPaddingRight();
        int left = recents.getPaddingLeft() + (innerWidth - width) / 2;

        // Padding bawah RecentsView adalah ruang di bawah kartu (area bekas handle panah).
        // Bila cukup tinggi, tombol diletakkan di tengah ruang itu; bila tidak, tepat di bawah
        // kartu dan dijepit supaya tidak keluar dari layar.
        int band = recents.getPaddingBottom();
        int bandTop = recents.getHeight() - band;
        int top;
        if (band >= height + 2 * margin) {
            top = bandTop + (band - height) / 2;
        } else {
            int cardBottom = 0;
            for (int i = 0; i < recents.getChildCount(); i++) {
                View child = recents.getChildAt(i);
                if (child != null && "TaskView".equals(child.getClass().getSimpleName())) {
                    cardBottom = Math.max(cardBottom, child.getBottom());
                }
            }
            top = cardBottom > 0 ? cardBottom + gap : bandTop;
            top = Math.min(top, recents.getHeight() - height - margin);
        }
        top = Math.max(top, recents.getPaddingTop() + margin);

        if (clearAll.getLeft() != left || clearAll.getTop() != top
                || clearAll.getRight() != left + width || clearAll.getBottom() != top + height) {
            clearAll.layout(left, top, left + width, top + height);
        }
        if (left != sLoggedLeft || top != sLoggedTop) {
            sLoggedLeft = left;
            sLoggedTop = top;
            Log.d(TAG, "ClearAll left=" + left + " top=" + top + " w=" + width + " h=" + height
                    + " recentsH=" + recents.getHeight() + " padB=" + band
                    + " padT=" + recents.getPaddingTop());
        }

        // Animasi masuk: tombol menyusul kartu (naik sebagian jarak sambil memudar masuk).
        float pc = RecentsMotion.clearAllFactor((ViewGroup) recents);
        float travel = RecentsMotion.travelPx((ViewGroup) recents);
        clearAll.setTranslationX(recents.getScrollX());
        clearAll.setTranslationY((1f - pc) * travel * CLEAR_ALL_TRAVEL);
        clearAll.setTranslationZ(Math.round(CLEAR_ALL_ELEVATION_DP * density));
        setClearAllAlpha(clearAll, pc);
        // Sabuk pengaman: setelah animasi masuk selesai tombol harus bisa diklik.
        if (pc >= 1f && !clearAll.isClickable() && clearAll.getAlpha() > 0.95f) {
            clearAll.setClickable(true);
        }
    }

    /**
     * ClearAllButton.setVisibilityAlpha(float): hanya dipakai jalur Fallback, aman untuk kita.
     * ClearAllButton hanya klikabel bila alpha total tepat 1, jadi nilai akhir harus persis 1.
     */
    private static void setClearAllAlpha(View clearAll, float alpha) {
        float target = alpha >= 0.999f ? 1f : alpha;
        Float last = CLEAR_ALL_ALPHA.get(clearAll);
        if (last == null && target == 1f) return;
        if (last != null && last == target) return;
        try {
            if (!sVisibilityAlphaResolved) {
                sVisibilityAlphaResolved = true;
                sSetVisibilityAlpha = clearAll.getClass()
                        .getMethod("setVisibilityAlpha", float.class);
            }
            if (sSetVisibilityAlpha != null) {
                sSetVisibilityAlpha.invoke(clearAll, target);
                CLEAR_ALL_ALPHA.put(clearAll, target);
            }
        } catch (Throwable error) {
            Log.w(TAG, "setVisibilityAlpha tidak tersedia", error);
            sSetVisibilityAlpha = null;
        }
    }

    private static boolean isRecentsView(View view) {
        if (view == null) return false;
        Class<?> type = view.getClass();
        while (type != null) {
            if ("com.android.quickstep.views.RecentsView".equals(type.getName())) return true;
            type = type.getSuperclass();
        }
        return false;
    }

    private static float dp(View view, float value) {
        return value * view.getResources().getDisplayMetrics().density;
    }
}
