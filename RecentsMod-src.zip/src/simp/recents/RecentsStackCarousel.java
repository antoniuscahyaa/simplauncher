package simp.recents;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Presentation-only Recents carousel controller. The original TaskView and PagedView
 * continue to own task data, gestures, snapping, and lifecycle; this class only applies
 * card transforms and pins Clear All to the Recents viewport.
 */
public final class RecentsStackCarousel {
    private static final float STACK_SPACING = 0.22f;
    private static final float FIRST_BACK_SCALE = 0.88f;
    private static final float SECOND_BACK_SCALE = 0.78f;
    private static final int CLEAR_ALL_MARGIN_DP = 14;
    private static final int CLEAR_ALL_ELEVATION_DP = 32;
    // One complete action-bar block (two 36dp rows + gap) per rear card.
    private static final float ACTION_BAR_LIFT_DP = 86f;

    private static final Map<View, Integer> ORIGINAL_VISIBILITY = new WeakHashMap<>();
    private static final Map<View, Float> ORIGINAL_ALPHA = new WeakHashMap<>();
    // Preserve live Launcher translations (including swipe-up dismissal animations).
    private static final Map<View, Float> LAST_X_OFFSET = new WeakHashMap<>();
    private static final Map<View, Float> LAST_Y_OFFSET = new WeakHashMap<>();

    private RecentsStackCarousel() { }

    /** Called after Launcher has applied its normal TaskView curve transforms. */
    public static void update(ViewGroup recents) {
        if (!isRecentsView(recents) || recents.getWidth() <= 0) return;

        try {
            List<View> tasks = taskViews(recents);
            if (!tasks.isEmpty()) applyStack(recents, tasks);
            View clearAll = findClearAllButton(recents);
            if (clearAll != null) {
                if (tasks.isEmpty()) clearAll.setVisibility(View.INVISIBLE);
                else positionClearAll(clearAll);
            }
        } catch (Throwable ignored) {
            // Presentation-only transforms must never crash Launcher during task dismissal.
        }
    }

    private static void applyStack(ViewGroup recents, List<View> tasks) {
        int width = tasks.get(0).getWidth();
        if (width <= 0) return;
        float center = recents.getPaddingLeft()
                + (recents.getWidth() - recents.getPaddingLeft() - recents.getPaddingRight()) / 2f;
        float scroll = recents.getScrollX();
        float step = width;
        if (tasks.size() > 1) {
            int measuredStep = Math.abs(tasks.get(1).getLeft() - tasks.get(0).getLeft());
            if (measuredStep > 0) step = measuredStep;
        }
        if (step <= 0) step = width;
        boolean rtl = recents.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
        float direction = rtl ? -1f : 1f;
        for (View task : tasks) {
            if (task == null || originalVisibility(task) != View.VISIBLE) continue;
            float dx = task.getLeft() + task.getWidth() / 2f - scroll - center;
            float relative = dx / step * direction;
            boolean inStack = relative > -0.55f && relative < 2.55f;
            task.setVisibility(inStack ? View.VISIBLE : View.INVISIBLE);
            if (!inStack) continue;
            float position = Math.max(0f, Math.min(2f, relative));
            float scale = position <= 1f
                    ? lerp(1f, FIRST_BACK_SCALE, position)
                    : lerp(FIRST_BACK_SCALE, SECOND_BACK_SCALE, position - 1f);
            float baseAlpha = originalAlpha(task);
            float alpha = position <= 1f
                    ? lerp(baseAlpha, baseAlpha * 0.90f, position)
                    : lerp(baseAlpha * 0.90f, baseAlpha * 0.80f, position - 1f);
            float desiredX = dx * (STACK_SPACING - 1f);
            float desiredY = -dp(task, ACTION_BAR_LIFT_DP) * position;
            float baseX = task.getTranslationX() - lastOffset(LAST_X_OFFSET, task);
            float baseY = task.getTranslationY() - lastOffset(LAST_Y_OFFSET, task);
            task.setTranslationX(baseX + desiredX);
            task.setTranslationY(baseY + desiredY);
            rememberOffset(LAST_X_OFFSET, task, desiredX);
            rememberOffset(LAST_Y_OFFSET, task, desiredY);
            task.setScaleX(scale);
            task.setScaleY(scale);
            task.setAlpha(alpha);
            task.setTranslationZ(dp(task, 22f - position * 9f));
        }
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * Math.max(0f, Math.min(1f, t));
    }

    private static float lastOffset(Map<View, Float> offsets, View view) {
        synchronized (offsets) {
            Float value = offsets.get(view);
            return value == null ? 0f : value;
        }
    }

    private static void rememberOffset(Map<View, Float> offsets, View view, float value) {
        synchronized (offsets) { offsets.put(view, value); }
    }

    private static View findClearAllButton(ViewGroup recents) {
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "ClearAllButton".equals(child.getClass().getSimpleName())) return child;
        }
        return null;
    }

    /** Preserve the alpha supplied by Launcher before applying stack dimming. */
    private static float originalAlpha(View view) {
        synchronized (ORIGINAL_ALPHA) {
            Float value = ORIGINAL_ALPHA.get(view);
            if (value == null) {
                value = view.getAlpha();
                ORIGINAL_ALPHA.put(view, value);
            }
            return value;
        }
    }

    private static int originalVisibility(View view) {
        synchronized (ORIGINAL_VISIBILITY) {
            Integer value = ORIGINAL_VISIBILITY.get(view);
            if (value == null) {
                value = view.getVisibility();
                ORIGINAL_VISIBILITY.put(view, value);
            }
            return value;
        }
    }

    private static List<View> taskViews(ViewGroup recents) {
        ArrayList<View> result = new ArrayList<>();
        for (int i = 0; i < recents.getChildCount(); i++) {
            View child = recents.getChildAt(i);
            if (child != null && "TaskView".equals(child.getClass().getSimpleName())) {
                result.add(child);
            }
        }
        return result;
    }

    /** ClearAllButton is not a page anymore; lay it out as a fixed viewport overlay. */
    public static void positionClearAll(View clearAll) {
        if (clearAll == null) return;
        ViewParent parent = clearAll.getParent();
        if (!(parent instanceof ViewGroup)) return;
        ViewGroup recents = (ViewGroup) parent;
        if (!isRecentsView(recents) || recents.getWidth() <= 0
                || clearAll.getMeasuredWidth() <= 0 || clearAll.getMeasuredHeight() <= 0) return;
        int margin = Math.round(CLEAR_ALL_MARGIN_DP
                * recents.getResources().getDisplayMetrics().density);
        int targetLeft = recents.getWidth() - recents.getPaddingRight() - margin
                - clearAll.getMeasuredWidth();
        int targetTop = recents.getPaddingTop() + margin;
        // Avoid calling View.layout() during RecentsView.onLayout; translate the native button.
        clearAll.setTranslationX(targetLeft - clearAll.getLeft() + recents.getScrollX());
        clearAll.setTranslationY(targetTop - clearAll.getTop());
        clearAll.setTranslationZ(Math.round(CLEAR_ALL_ELEVATION_DP
                * recents.getResources().getDisplayMetrics().density));
        clearAll.setVisibility(View.VISIBLE);
        clearAll.setAlpha(1f);
    }

    private static boolean isRecentsView(View view) {
        if (view == null) return false;
        Class<?> type = view.getClass();
        while (type != null) {
            if ("com.android.quickstep.views.RecentsView".equals(type.getName())) return true;
            type = type.getSuperclass();
        }
        return false;
    }

    private static float dp(View view, float value) {
        return value * view.getResources().getDisplayMetrics().density;
    }
}
