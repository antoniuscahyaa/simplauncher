package simp.recents;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.SystemClock;
import android.util.Log;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Animasi buka/tutup Recents: kartu naik dari bawah saat dibuka (swipe-up) dan turun saat
 * dibatalkan. Hanya animasi masuk/keluar; geser antar kartu tetap horizontal.
 *
 * Launcher bawaan menggeser RecentsView dari samping (getOffscreenTranslationX). Gerakan
 * itu dinetralkan oleh tools/patch_recents_motion.py, lalu kelas ini menambahkan offset
 * vertikal per kartu lewat RecentsStackCarousel (cardFactor / travelPx / clearAllFactor).
 */
public final class RecentsMotion {
    private static final String TAG = "RecentsMod";
    private static final long ENTER_MS = 460L;
    private static final long EXIT_MS = 300L;
    private static final long HOLD_TIMEOUT_MS = 1500L;

    private static final float MAX_STAGGER = 0.30f;
    private static final float STAGGER_PER_CARD = 0.12f;
    private static final float CLEAR_ALL_DELAY = 0.35f;

    private static final Interpolator ENTER_CURVE = new DecelerateInterpolator(2.2f);
    private static final Interpolator EXIT_CURVE = new AccelerateInterpolator(1.6f);

    private static final Map<ViewGroup, State> STATES = new WeakHashMap<>();

    private RecentsMotion() { }

    private static final class State {
        ValueAnimator anim;
        /** 1 = kartu di posisi akhir, 0 = tersembunyi di bawah. */
        float t = 1f;
        boolean shown;
        boolean exiting;
        /** Setelah animasi keluar selesai, kartu ditahan tersembunyi sampai Recents ditutup. */
        boolean hold;
        long exitAt;
        ViewTreeObserver.OnPreDrawListener pre;
    }

    private static State state(ViewGroup recents) {
        synchronized (STATES) {
            State s = STATES.get(recents);
            if (s == null) {
                s = new State();
                STATES.put(recents, s);
            }
            return s;
        }
    }

    // ---- dipanggil dari smali (lihat patch_recents_motion.py) -----------------------

    /** LauncherActivityControllerHelper$2.setRecentsAttachedToAppWindow(attached, animate). */
    public static void onAttach(ViewGroup recents, boolean attached, boolean animate) {
        try {
            State s = state(recents);
            if (attached) {
                if (!animate) {
                    cancelAnim(s);
                    s.t = 1f;
                    s.hold = false;
                    s.exiting = false;
                    s.shown = true;
                    refresh(recents, s);
                } else {
                    startEnter(recents, s);
                }
            } else {
                if (!animate) {
                    cancelAnim(s);
                    s.shown = false;
                    s.exiting = true;
                    s.t = 0f;
                    s.hold = true;
                    s.exitAt = SystemClock.uptimeMillis();
                    ensurePre(recents, s);
                    safeUpdate(recents);
                } else {
                    startExit(recents, s);
                }
            }
        } catch (Throwable error) {
            Log.e(TAG, "RecentsMotion.onAttach gagal", error);
        }
    }

    /** LauncherRecentsView.onStateTransitionStart(state): overview = state.overviewUi. */
    public static void onStateStart(ViewGroup recents, boolean overview) {
        try {
            State s = state(recents);
            if (overview) {
                // Jalur gesture sudah memutar animasi lewat onAttach; jangan dua kali.
                if (!s.shown) startEnter(recents, s);
            } else if (!s.hold) {
                cancelAnim(s);
                s.shown = false;
                s.exiting = false;
                s.t = 1f;
                removePre(recents, s);
            }
        } catch (Throwable error) {
            Log.e(TAG, "RecentsMotion.onStateStart gagal", error);
        }
    }

    // ---- dipakai RecentsStackCarousel --------------------------------------------

    /** Kemajuan animasi untuk satu kartu (0..1) sesuai jaraknya dari tengah. */
    static float cardFactor(ViewGroup recents, float distance) {
        State s = peek(recents);
        if (s == null) return 1f;
        float delay = Math.min(MAX_STAGGER, STAGGER_PER_CARD * distance);
        return curve(s, delay);
    }

    static float clearAllFactor(ViewGroup recents) {
        State s = peek(recents);
        if (s == null) return 1f;
        return curve(s, CLEAR_ALL_DELAY);
    }

    /** Jarak naik dari bawah, dalam piksel. */
    static float travelPx(ViewGroup recents) {
        float density = recents.getResources().getDisplayMetrics().density;
        float travel = recents.getHeight() * 0.30f;
        return Math.max(96f * density, Math.min(240f * density, travel));
    }

    private static State peek(ViewGroup recents) {
        synchronized (STATES) {
            State s = STATES.get(recents);
            if (s == null || (s.t >= 1f && !s.hold && s.anim == null)) return null;
            return s;
        }
    }

    private static float curve(State s, float delay) {
        float x = (s.t - delay) / (1f - delay);
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return (s.exiting || s.hold) ? EXIT_CURVE.getInterpolation(x)
                : ENTER_CURVE.getInterpolation(x);
    }

    // ---- mesin animasi -------------------------------------------------------------

    private static void startEnter(ViewGroup recents, State s) {
        if (s.shown && !s.exiting && s.t >= 1f && s.anim == null) return;
        s.shown = true;
        s.exiting = false;
        s.hold = false;
        if (s.t >= 1f) s.t = 0f;
        safeUpdate(recents);
        animateTo(recents, s, 1f, ENTER_MS, false);
    }

    private static void startExit(ViewGroup recents, State s) {
        if (!s.shown && !s.hold && s.anim == null) return;
        s.shown = false;
        s.exiting = true;
        s.hold = false;
        animateTo(recents, s, 0f, EXIT_MS, true);
    }

    private static void animateTo(final ViewGroup recents, final State s, final float to,
            long fullMs, final boolean exit) {
        cancelAnim(s);
        float from = s.t;
        long duration = Math.max(1L, Math.round(fullMs * Math.abs(to - from)));
        final ValueAnimator animator = ValueAnimator.ofFloat(from, to);
        animator.setDuration(duration);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            s.t = (Float) a.getAnimatedValue();
            recents.invalidate();
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override public void onAnimationCancel(Animator a) { cancelled = true; }

            @Override public void onAnimationEnd(Animator a) {
                if (cancelled) return;
                s.anim = null;
                s.t = to;
                if (exit) {
                    s.hold = true;
                    s.exitAt = SystemClock.uptimeMillis();
                } else {
                    s.exiting = false;
                }
                safeUpdate(recents);
                if (!s.hold) removePre(recents, s);
            }
        });
        s.anim = animator;
        ensurePre(recents, s);
        animator.start();
    }

    private static void cancelAnim(State s) {
        if (s.anim != null) {
            ValueAnimator a = s.anim;
            s.anim = null;
            a.cancel();
        }
    }

    private static void refresh(ViewGroup recents, State s) {
        safeUpdate(recents);
        if (s.anim == null && !s.hold) removePre(recents, s);
    }

    /**
     * Transformasi diterapkan ulang tepat sebelum menggambar, setelah semua animator frame ini
     * berjalan. Ini mencegah Launcher (alpha/translasi konten) menimpa hasil kita di tengah frame.
     */
    private static void ensurePre(final ViewGroup recents, final State s) {
        if (s.pre != null) return;
        s.pre = new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                if (s.hold && (!recents.isShown()
                        || SystemClock.uptimeMillis() - s.exitAt > HOLD_TIMEOUT_MS)) {
                    s.hold = false;
                    s.exiting = false;
                    s.t = 1f;
                }
                safeUpdate(recents);
                if (s.anim == null && !s.hold) removePre(recents, s);
                return true;
            }
        };
        recents.getViewTreeObserver().addOnPreDrawListener(s.pre);
    }

    private static void removePre(ViewGroup recents, State s) {
        if (s.pre == null) return;
        ViewTreeObserver.OnPreDrawListener listener = s.pre;
        s.pre = null;
        recents.getViewTreeObserver().removeOnPreDrawListener(listener);
    }

    private static void safeUpdate(ViewGroup recents) {
        try {
            RecentsStackCarousel.update(recents);
        } catch (Throwable error) {
            Log.e(TAG, "Gagal memperbarui carousel", error);
        }
    }
}
