package simp.recents;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Animasi buka/tutup Recents: kartu naik dari bawah saat dibuka (swipe-up) dan turun saat
 * dibatalkan. Hanya animasi masuk/keluar; geser antar kartu tetap horizontal.
 *
 * Launcher bawaan menggeser RecentsView dari samping (getOffscreenTranslationX). Gerakan
 * itu dinetralkan oleh tools/patch_recents_motion.py, lalu kelas ini menambahkan offset
 * vertikal per kartu lewat RecentsStackCarousel (cardFactor / travelPx / clearAllFactor).
 */
public final class RecentsMotion {
    private static final String TAG = "RecentsMod";
    private static final long ENTER_MS = 460L;
    private static final long EXIT_MS = 300L;
    private static final long HOLD_TIMEOUT_MS = 1500L;

    private static final float MAX_STAGGER = 0.30f;
    private static final float STAGGER_PER_CARD = 0.12f;
    private static final float CLEAR_ALL_DELAY = 0.35f;

    private static final Interpolator ENTER_CURVE = new DecelerateInterpolator(2.2f);
    private static final Interpolator EXIT_CURVE = new AccelerateInterpolator(1.6f);

    private static final Map<ViewGroup, State> STATES = new WeakHashMap<>();
    private static Field sOverviewUiField;
    private static boolean sOverviewUiResolved;
    private static int sFilterLogs;

    private RecentsMotion() { }

    private static final class State {
        ValueAnimator anim;
        /** 1 = kartu di posisi akhir, 0 = tersembunyi di bawah. */
        float t = 1f;
        boolean shown;
        boolean exiting;
        /** Setelah animasi keluar selesai, kartu ditahan tersembunyi sampai Recents ditutup. */
        boolean hold;
        long exitAt;
        /** True selama state Overview (bukan quick switch): RecentsView tidak boleh digeser horizontal. */
        boolean filterX;
        /** Pengali jarak naik: gesture dari aplikasi 1; buka dari Home 0,3 (state sudah menaikkan Recents). */
        float travelScale = 1f;
        /** Selama waktu ini (uptime ms) setiap frame dicatat ke log untuk diagnosis. */
        long sampleUntil;
        long lastSample;
        ViewTreeObserver.OnPreDrawListener pre;
    }

    private static State state(ViewGroup recents) {
        synchronized (STATES) {
            State s = STATES.get(recents);
            if (s == null) {
                s = new State();
                STATES.put(recents, s);
            }
            return s;
        }
    }

    // ---- dipanggil dari smali (lihat patch_recents_motion.py) -----------------------

    /** LauncherActivityControllerHelper$2.setRecentsAttachedToAppWindow(attached, animate). */
    public static void onAttach(ViewGroup recents, boolean attached, boolean animate) {
        try {
            State s = state(recents);
            RecentsLog.init(recents.getContext());
            markEvent(recents, s, "onAttach attached=" + attached + " animate=" + animate);
            if (attached) {
                if (!animate) {
                    cancelAnim(s);
                    s.t = 1f;
                    s.hold = false;
                    s.exiting = false;
                    s.shown = true;
                    refresh(recents, s);
                } else {
                    startEnter(recents, s, 1f);
                }
            } else {
                if (!animate) {
                    cancelAnim(s);
                    s.shown = false;
                    s.exiting = true;
                    s.t = 0f;
                    s.hold = true;
                    s.exitAt = SystemClock.uptimeMillis();
                    ensurePre(recents, s);
                    safeUpdate(recents);
                } else {
                    startExit(recents, s);
                }
            }
        } catch (Throwable error) {
            Log.e(TAG, "RecentsMotion.onAttach gagal", error);
        }
    }

    /** LauncherRecentsView.onStateTransitionStart(state). */
    public static void onStateStart(ViewGroup recents, Object launcherState) {
        try {
            State s = state(recents);
            String name = launcherState == null ? "" : launcherState.getClass().getSimpleName();
            boolean overview = readOverviewUi(launcherState);
            boolean quickSwitch = name.contains("QuickSwitch");
            // BackgroundApp/QuickSwitch = fase gesture dari aplikasi; animasi masuknya dipicu
            // oleh onAttach, bukan di sini.
            boolean gestureState = quickSwitch || name.contains("BackgroundApp");
            RecentsLog.init(recents.getContext());
            markEvent(recents, s, "onStateStart state=" + name + " overview=" + overview
                    + " shown=" + s.shown);

            s.filterX = overview && !quickSwitch;
            if (s.filterX) recents.setTranslationX(0f); // lewat override -> tetap 0

            if (overview) {
                if (!s.shown && !gestureState) startEnter(recents, s, 0.3f);
            } else if (!s.hold) {
                cancelAnim(s);
                s.shown = false;
                s.exiting = false;
                s.t = 1f;
                removePre(recents, s);
            }
        } catch (Throwable error) {
            Log.e(TAG, "RecentsMotion.onStateStart gagal", error);
        }
    }

    /**
     * LauncherRecentsView.setTranslationX(x) (override hasil patch). Launcher menggeser seluruh
     * RecentsView dari samping saat masuk ke Overview; itu sumber animasi horizontal. Selama
     * Overview, geseran itu dibuang. Saat keluar ke Home nilai asli dipakai lagi supaya Recents
     * tetap tersembunyi di luar layar seperti semula.
     */
    public static float filterTranslationX(View view, float x) {
        try {
            if (x == 0f) return x;
            State s;
            synchronized (STATES) { s = STATES.get(view); }
            if (s == null || !s.filterX) return x;
            if (sFilterLogs < 12) {
                sFilterLogs++;
                StackTraceElement[] st = new Throwable().getStackTrace();
                StringBuilder where = new StringBuilder();
                for (int i = 1; i < Math.min(st.length, 8); i++) {
                    where.append("\n    at ").append(st[i]);
                }
                RecentsLog.line("translationX " + x + " diabaikan" + where);
            }
            return 0f;
        } catch (Throwable error) {
            return x;
        }
    }

    private static boolean readOverviewUi(Object launcherState) {
        if (launcherState == null) return false;
        try {
            if (!sOverviewUiResolved) {
                sOverviewUiResolved = true;
                sOverviewUiField = launcherState.getClass().getField("overviewUi");
            }
            return sOverviewUiField != null && sOverviewUiField.getBoolean(launcherState);
        } catch (Throwable error) {
            Log.w(TAG, "overviewUi tidak terbaca", error);
            return false;
        }
    }

    // ---- dipakai RecentsStackCarousel --------------------------------------------

    /** Kemajuan animasi untuk satu kartu (0..1) sesuai jaraknya dari tengah. */
    static float cardFactor(ViewGroup recents, float distance) {
        State s = peek(recents);
        if (s == null) return 1f;
        float delay = Math.min(MAX_STAGGER, STAGGER_PER_CARD * distance);
        return curve(s, delay);
    }

    static float clearAllFactor(ViewGroup recents) {
        State s = peek(recents);
        if (s == null) return 1f;
        return curve(s, CLEAR_ALL_DELAY);
    }

    /** Jarak naik dari bawah, dalam piksel. */
    static float travelPx(ViewGroup recents) {
        float density = recents.getResources().getDisplayMetrics().density;
        float travel = recents.getHeight() * 0.30f;
        float scale = 1f;
        synchronized (STATES) {
            State s = STATES.get(recents);
            if (s != null) scale = s.travelScale;
        }
        return scale * Math.max(96f * density, Math.min(240f * density, travel));
    }

    private static State peek(ViewGroup recents) {
        synchronized (STATES) {
            State s = STATES.get(recents);
            if (s == null || (s.t >= 1f && !s.hold && s.anim == null)) return null;
            return s;
        }
    }

    private static float curve(State s, float delay) {
        float x = (s.t - delay) / (1f - delay);
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return (s.exiting || s.hold) ? EXIT_CURVE.getInterpolation(x)
                : ENTER_CURVE.getInterpolation(x);
    }

    // ---- mesin animasi -------------------------------------------------------------

    private static void startEnter(ViewGroup recents, State s, float travelScale) {
        if (s.shown && !s.exiting && s.t >= 1f && s.anim == null) return;
        s.travelScale = travelScale;
        s.shown = true;
        s.exiting = false;
        s.hold = false;
        if (s.t >= 1f) s.t = 0f;
        safeUpdate(recents);
        animateTo(recents, s, 1f, ENTER_MS, false);
    }

    private static void startExit(ViewGroup recents, State s) {
        if (!s.shown && !s.hold && s.anim == null) return;
        s.shown = false;
        s.exiting = true;
        s.hold = false;
        animateTo(recents, s, 0f, EXIT_MS, true);
    }

    private static void animateTo(final ViewGroup recents, final State s, final float to,
            long fullMs, final boolean exit) {
        cancelAnim(s);
        float from = s.t;
        long duration = Math.max(1L, Math.round(fullMs * Math.abs(to - from)));
        final ValueAnimator animator = ValueAnimator.ofFloat(from, to);
        animator.setDuration(duration);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            s.t = (Float) a.getAnimatedValue();
            recents.invalidate();
        });
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override public void onAnimationCancel(Animator a) { cancelled = true; }

            @Override public void onAnimationEnd(Animator a) {
                if (cancelled) return;
                s.anim = null;
                s.t = to;
                if (exit) {
                    s.hold = true;
                    s.exitAt = SystemClock.uptimeMillis();
                } else {
                    s.exiting = false;
                }
                safeUpdate(recents);
                if (!s.hold) removePre(recents, s);
            }
        });
        s.anim = animator;
        ensurePre(recents, s);
        animator.start();
    }

    private static void cancelAnim(State s) {
        if (s.anim != null) {
            ValueAnimator a = s.anim;
            s.anim = null;
            a.cancel();
        }
    }

    private static void refresh(ViewGroup recents, State s) {
        safeUpdate(recents);
        if (s.anim == null && !s.hold) removePre(recents, s);
    }

    /**
     * Transformasi diterapkan ulang tepat sebelum menggambar, setelah semua animator frame ini
     * berjalan. Ini mencegah Launcher (alpha/translasi konten) menimpa hasil kita di tengah frame.
     */
    private static void ensurePre(final ViewGroup recents, final State s) {
        if (s.pre != null) return;
        s.pre = new ViewTreeObserver.OnPreDrawListener() {
            @Override public boolean onPreDraw() {
                if (s.hold && (!recents.isShown()
                        || SystemClock.uptimeMillis() - s.exitAt > HOLD_TIMEOUT_MS)) {
                    s.hold = false;
                    s.exiting = false;
                    s.t = 1f;
                }
                long now = SystemClock.uptimeMillis();
                // Sabuk pengaman: geseran horizontal yang lolos dari override setTranslationX
                // (mis. lewat jalur animator lain) dikembalikan ke 0 selama Overview/animasi.
                if ((s.filterX || s.anim != null) && recents.getTranslationX() != 0f) {
                    RecentsLog.line("translationX sisa " + recents.getTranslationX() + " di-reset");
                    recents.setTranslationX(0f);
                }
                safeUpdate(recents);
                if (now < s.sampleUntil) {
                    if (now - s.lastSample >= 16L) {
                        s.lastSample = now;
                        RecentsLog.line("frame t=" + s.t + " hold=" + s.hold + " | "
                                + describe(recents));
                    }
                } else if (s.sampleUntil != 0L) {
                    s.sampleUntil = 0L;
                    RecentsLog.flush();
                }
                if (s.anim == null && !s.hold && now >= s.sampleUntil) removePre(recents, s);
                return true;
            }
        };
        recents.getViewTreeObserver().addOnPreDrawListener(s.pre);
    }

    private static void removePre(ViewGroup recents, State s) {
        if (s.pre == null) return;
        ViewTreeObserver.OnPreDrawListener listener = s.pre;
        s.pre = null;
        recents.getViewTreeObserver().removeOnPreDrawListener(listener);
    }

    /** Catat peristiwa dan rekam setiap frame selama 1,8 detik berikutnya. */
    private static void markEvent(ViewGroup recents, State s, String what) {
        RecentsLog.line(what + " | " + describe(recents));
        s.sampleUntil = SystemClock.uptimeMillis() + 1800L;
        ensurePre(recents, s);
    }

    private static String describe(ViewGroup r) {
        StringBuilder b = new StringBuilder();
        b.append("rv[tx=").append(r.getTranslationX()).append(" ty=").append(r.getTranslationY())
                .append(" sx=").append(r.getScrollX()).append(" x=").append(r.getX())
                .append(" sc=").append(r.getScaleX()).append(" a=").append(r.getAlpha())
                .append(" vis=").append(r.getVisibility()).append(" w=").append(r.getWidth())
                .append("]");
        ViewParent p = r.getParent();
        for (int i = 0; i < 4 && p instanceof View; i++) {
            View v = (View) p;
            b.append(" ^").append(v.getClass().getSimpleName()).append("[tx=")
                    .append(v.getTranslationX()).append(" x=").append(v.getX())
                    .append(" a=").append(v.getAlpha()).append("]");
            p = v.getParent();
        }
        for (int i = 0; i < r.getChildCount(); i++) {
            View c = r.getChildAt(i);
            if (c != null && "TaskView".equals(c.getClass().getSimpleName())) {
                b.append(" task").append(i).append("[l=").append(c.getLeft())
                        .append(" tx=").append(c.getTranslationX())
                        .append(" ty=").append(c.getTranslationY())
                        .append(" sc=").append(c.getScaleX())
                        .append(" a=").append(c.getAlpha()).append("]");
                if (i >= 3) break;
            }
        }
        return b.toString();
    }

    private static void safeUpdate(ViewGroup recents) {
        try {
            RecentsStackCarousel.update(recents);
        } catch (Throwable error) {
            Log.e(TAG, "Gagal memperbarui carousel", error);
        }
    }
}
