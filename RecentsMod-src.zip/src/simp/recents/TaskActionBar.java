package simp.recents;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;

/**
 * Bar aksi di dasar kartu Recents: baris atas berisi shortcut bawaan launcher (App info,
 * Split screen, ...) berdampingan, baris bawah satu tombol panjang "Tutup".
 * Isi dibangun ulang saat kartu dipakai task lain. Semua lewat refleksi dan semua
 * kegagalan ditelan supaya Recents tidak pernah crash karena view ini.
 */
public class TaskActionBar extends LinearLayout {

    private static final long TICK_MS = 500L;
    private static final int BTN_H = 36;   // dp
    private static final int GAP = 6;      // dp

    private final float mDp;
    private Object mBoundTask;
    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            try {
                Object t = currentTask();
                if (t != mBoundTask) {
                    mBoundTask = t;
                    rebuild();
                }
            } catch (Throwable ignored) {
            }
            if (isAttachedToWindow()) {
                postDelayed(this, TICK_MS);
            }
        }
    };

    public TaskActionBar(Context context) {
        this(context, null);
    }

    public TaskActionBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TaskActionBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mDp = context.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
    }

    private int dp(float v) {
        return Math.round(v * mDp);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mBoundTask = null;
        removeCallbacks(mTick);
        post(mTick);
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    private void rebuild() {
        removeAllViews();
        if (mBoundTask == null) {
            return;
        }
        LinearLayout row = null;
        try {
            row = buildShortcutRow();
        } catch (Throwable ignored) {
        }
        if (row != null && row.getChildCount() > 0) {
            addView(row, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H)));
        }
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H));
        lp.topMargin = getChildCount() > 0 ? dp(GAP) : 0;
        addView(buildCloseButton(), lp);
    }

    /** Baris atas: shortcut launcher berdampingan, lebar sama. */
    private LinearLayout buildShortcutRow() throws Exception {
        ViewParent vp = getParent();
        if (!(vp instanceof FrameLayout)) {
            return null;
        }
        FrameLayout taskView = (FrameLayout) vp;
        ClassLoader cl = taskView.getClass().getClassLoader();
        Context ctx = getContext();

        Class<?> factoryCls = Class.forName("com.android.quickstep.TaskOverlayFactory", true, cl);
        Class<?> holderCls = Class.forName("com.android.launcher3.util.MainThreadInitializedObject", true, cl);
        Object holder = factoryCls.getField("INSTANCE").get(null);
        Object factory = find(holderCls, "get", 1).invoke(holder, ctx);
        List<?> shortcuts = (List<?>) find(factoryCls, "getEnabledShortcuts", 1).invoke(factory, taskView);

        Class<?> scCls = Class.forName("com.android.quickstep.TaskSystemShortcut", true, cl);
        Method getListener = find(scCls, "getOnClickListener", 2);
        Method setIconLabel = find(scCls, "setIconAndLabelFor", 2);
        Object activity = findActivity(cl, ctx);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(HORIZONTAL);

        for (Object sc : shortcuts) {
            final View.OnClickListener l =
                    (View.OnClickListener) getListener.invoke(sc, activity, taskView);
            if (l == null) {
                continue;
            }
            LinearLayout btn = newButton(ctx);
            View icon = new View(ctx);
            TextView label = newLabel(ctx);
            setIconLabel.invoke(sc, icon, label);
            icon.setBackgroundTintList(ColorStateList.valueOf(0xFF14243A));
            label.setTextColor(0xFF14243A);
            btn.addView(icon, new LayoutParams(dp(16), dp(16)));
            LayoutParams tlp = new LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.setMarginStart(dp(6));
            btn.addView(label, tlp);
            btn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        l.onClick(v);
                    } catch (Throwable ignored) {
                    }
                }
            });
            LayoutParams blp = new LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
            if (row.getChildCount() > 0) {
                blp.setMarginStart(dp(GAP));
            }
            row.addView(btn, blp);
        }
        return row;
    }

    /** Baris bawah: satu tombol panjang untuk menutup kartu. */
    private LinearLayout buildCloseButton() {
        Context ctx = getContext();
        LinearLayout btn = newButton(ctx);
        btn.addView(new CrossView(ctx), new LayoutParams(dp(16), dp(16)));
        TextView label = newLabel(ctx);
        label.setTextColor(0xFF14243A);
        label.setText("id".equals(Locale.getDefault().getLanguage()) ? "Tutup" : "Close");
        LayoutParams tlp = new LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.setMarginStart(dp(6));
        btn.addView(label, tlp);
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        return btn;
    }

    private LinearLayout newButton(Context ctx) {
        LinearLayout b = new LinearLayout(ctx);
        b.setOrientation(HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xB3FFFFFF);
        bg.setCornerRadius(dp(12));
        bg.setStroke(Math.max(1, dp(1)), 0xB3FFFFFF);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(12));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), bg, mask));
        b.setClickable(true);
        return b;
    }

    private TextView newLabel(Context ctx) {
        TextView t = new TextView(ctx);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        try {
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        } catch (Throwable ignored) {
        }
        return t;
    }

    /** Menutup kartu lewat RecentsView.dismissTask(taskView, animate, removeTask). */
    private void dismiss() {
        try {
            ViewParent taskView = getParent();
            if (taskView == null) {
                return;
            }
            ViewParent rv = taskView.getParent();
            while (rv != null) {
                for (Method m : rv.getClass().getMethods()) {
                    if (!m.getName().equals("dismissTask")) {
                        continue;
                    }
                    Class<?>[] pt = m.getParameterTypes();
                    if (pt.length == 0 || !pt[0].isInstance(taskView)) {
                        continue;
                    }
                    Object[] args = new Object[pt.length];
                    args[0] = taskView;
                    boolean ok = true;
                    for (int i = 1; i < pt.length; i++) {
                        if (pt[i] == boolean.class) {
                            args[i] = Boolean.TRUE;
                        } else {
                            ok = false;
                        }
                    }
                    if (ok) {
                        m.invoke(rv, args);
                        return;
                    }
                }
                rv = rv.getParent();
            }
        } catch (Throwable ignored) {
        }
    }

    private Object currentTask() {
        try {
            ViewParent p = getParent();
            return p == null ? null : p.getClass().getMethod("getTask").invoke(p);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Method find(Class<?> c, String name, int params) throws NoSuchMethodException {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == params) {
                return m;
            }
        }
        throw new NoSuchMethodException(c.getName() + "." + name);
    }

    private Object findActivity(ClassLoader cl, Context ctx) {
        try {
            Class<?> ba = Class.forName("com.android.launcher3.BaseActivity", true, cl);
            return find(ba, "fromContext", 1).invoke(null, ctx);
        } catch (Throwable t) {
            Context c = ctx;
            while (c instanceof ContextWrapper) {
                if (c instanceof android.app.Activity) {
                    return c;
                }
                c = ((ContextWrapper) c).getBaseContext();
            }
            return null;
        }
    }

    /** Ikon silang sederhana (tanpa resource tambahan). */
    private static final class CrossView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        CrossView(Context c) {
            super(c);
            p.setColor(0xFF14243A);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(1.75f * c.getResources().getDisplayMetrics().density);
        }

        @Override
        protected void onDraw(Canvas c) {
            float m = getWidth() * 0.22f;
            c.drawLine(m, m, getWidth() - m, getHeight() - m, p);
            c.drawLine(getWidth() - m, m, m, getHeight() - m, p);
        }
    }
}
