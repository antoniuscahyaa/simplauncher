package simp.recents;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;

/** Two half-width native shortcuts and a full-width, genuine Force Stop action. */
public class TaskActionBar extends LinearLayout {
    private static final String TAG = "RecentsMod";
    private static final String FORCE_STOP_PERMISSION = "android.permission.FORCE_STOP_PACKAGES";
    private static final long TICK_MS = 500L;
    private static final int BTN_H = 36;
    private static final int GAP = 6;

    private final float mDp;
    private Object mBoundTask;

    private final Runnable mTick = new Runnable() {
        @Override public void run() {
            try {
                Object task = currentTask();
                if (task != mBoundTask) {
                    mBoundTask = task;
                    rebuild();
                }
            } catch (Throwable error) {
                Log.e(TAG, "Gagal memperbarui action bar", error);
            } finally {
                if (isAttachedToWindow()) postDelayed(this, TICK_MS);
            }
        }
    };

    public TaskActionBar(Context context) { this(context, null); }
    public TaskActionBar(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public TaskActionBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mDp = context.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setClipChildren(false);
        setClipToPadding(false);
    }

    private int dp(float value) { return Math.round(value * mDp); }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mBoundTask = null;
        removeCallbacks(mTick);
        post(mTick);
    }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    private void rebuild() {
        removeAllViews();
        if (mBoundTask == null) return;

        View shortcutRow;
        try {
            shortcutRow = buildShortcutRow();
        } catch (Throwable error) {
            Log.e(TAG, "Gagal membuat shortcut App Info/Split Screen", error);
            shortcutRow = buildFallbackShortcutRow();
        }
        addView(shortcutRow, new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H)));

        LayoutParams forceStopLp = new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H));
        forceStopLp.topMargin = dp(GAP);
        addView(buildForceStopButton(), forceStopLp);
    }

    /** Only keep Split Screen and App Info; do not expose the old Kill shortcut. */
    private View buildShortcutRow() throws Exception {
        ViewParent parent = getParent();
        if (!(parent instanceof View)) return buildFallbackShortcutRow();
        final View taskView = (View) parent;
        ClassLoader loader = taskView.getClass().getClassLoader();
        Context context = taskView.getContext();

        Class<?> factoryClass = Class.forName(
                "com.android.quickstep.TaskOverlayFactory", true, loader);
        Class<?> holderClass = Class.forName(
                "com.android.launcher3.util.MainThreadInitializedObject", true, loader);
        Object holder = factoryClass.getField("INSTANCE").get(null);
        Object factory = holderClass.getMethod("get", Context.class).invoke(holder, context);
        Class<?> taskViewClass = Class.forName(
                "com.android.quickstep.views.TaskView", true, loader);
        List<?> shortcuts = (List<?>) factoryClass
                .getMethod("getEnabledShortcuts", taskViewClass).invoke(factory, taskView);

        Class<?> shortcutClass = Class.forName(
                "com.android.quickstep.TaskSystemShortcut", true, loader);
        Class<?> activityClass = Class.forName(
                "com.android.launcher3.BaseDraggingActivity", true, loader);
        Method getListener = shortcutClass.getMethod(
                "getOnClickListener", activityClass, taskViewClass);
        Method setIconAndLabel = shortcutClass.getMethod(
                "setIconAndLabelFor", View.class, TextView.class);
        Object activity = getTaskActivity(taskView, activityClass);
        if (activity == null) throw new IllegalStateException("BaseDraggingActivity tidak ditemukan");

        Object split = findShortcut(shortcuts, "SplitScreen");
        Object appInfo = findShortcut(shortcuts, "AppInfo");
        View.OnClickListener splitListener = split == null ? null :
                (View.OnClickListener) getListener.invoke(split, activity, taskView);
        View.OnClickListener infoListener = appInfo == null ? null :
                (View.OnClickListener) getListener.invoke(appInfo, activity, taskView);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClipChildren(false);
        row.setClipToPadding(false);
        row.addView(createShortcutButton(context, split, splitListener,
                        "Split Screen", setIconAndLabel), halfButtonParams(true));
        row.addView(createShortcutButton(context, appInfo, infoListener,
                        "App Info", setIconAndLabel), halfButtonParams(false));
        return row;
    }

    private LayoutParams halfButtonParams(boolean first) {
        LayoutParams lp = new LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        if (first) lp.setMarginEnd(dp(GAP / 2f));
        else lp.setMarginStart(dp(GAP / 2f));
        return lp;
    }

    private LinearLayout createShortcutButton(Context context, Object shortcut,
            View.OnClickListener listener, String fallbackLabel, Method setIconAndLabel) {
        LinearLayout button = newButton(context);
        button.setPadding(dp(6), 0, dp(6), 0);
        View icon = new View(context);
        TextView label = newLabel(context);
        label.setText(fallbackLabel);
        if (shortcut != null) {
            try {
                setIconAndLabel.invoke(shortcut, icon, label);
            } catch (Throwable error) {
                Log.w(TAG, "Ikon shortcut tidak tersedia: " + fallbackLabel, unwrap(error));
            }
        }
        icon.setBackgroundTintList(ColorStateList.valueOf(0xFF14243A));
        label.setTextColor(0xFF14243A);
        button.addView(icon, new LayoutParams(dp(16), dp(16)));
        LayoutParams labelLp = new LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        labelLp.setMarginStart(dp(5));
        button.addView(label, labelLp);
        button.setContentDescription(label.getText());
        if (listener == null) {
            button.setEnabled(false);
            button.setAlpha(0.55f);
        } else {
            button.setOnClickListener(v -> {
                try { listener.onClick(v); }
                catch (Throwable error) { Log.e(TAG, "Shortcut gagal dijalankan", error); }
            });
        }
        return button;
    }

    private LinearLayout buildFallbackShortcutRow() {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        row.addView(placeholderButton("Split Screen"), halfButtonParams(true));
        row.addView(placeholderButton("App Info"), halfButtonParams(false));
        return row;
    }

    private LinearLayout placeholderButton(String labelText) {
        LinearLayout button = newButton(getContext());
        TextView label = newLabel(getContext());
        label.setText(labelText);
        label.setTextColor(0xFF14243A);
        button.addView(label);
        button.setEnabled(false);
        button.setAlpha(0.55f);
        return button;
    }

    private Object findShortcut(List<?> shortcuts, String simpleName) {
        if (shortcuts == null) return null;
        for (Object shortcut : shortcuts) {
            if (shortcut != null && simpleName.equals(shortcut.getClass().getSimpleName())) {
                return shortcut;
            }
        }
        return null;
    }

    private Object getTaskActivity(View taskView, Class<?> expectedClass) throws Exception {
        Class<?> type = taskView.getClass();
        while (type != null) {
            try {
                Field field = type.getDeclaredField("mActivity");
                field.setAccessible(true);
                Object activity = field.get(taskView);
                if (expectedClass.isInstance(activity)) return activity;
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass();
                continue;
            }
            break;
        }
        Class<?> baseActivity = Class.forName(
                "com.android.launcher3.BaseActivity", true, taskView.getClass().getClassLoader());
        Object activity = baseActivity.getMethod("fromContext", Context.class)
                .invoke(null, taskView.getContext());
        return expectedClass.isInstance(activity) ? activity : null;
    }

    private LinearLayout buildForceStopButton() {
        LinearLayout button = newButton(getContext());
        button.addView(new CrossView(getContext()), new LayoutParams(dp(16), dp(16)));
        TextView label = newLabel(getContext());
        label.setTextColor(0xFF14243A);
        label.setText("id".equals(Locale.getDefault().getLanguage())
                ? "Paksa berhenti" : "Force Stop");
        LayoutParams labelLp = new LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelLp.setMarginStart(dp(6));
        button.addView(label, labelLp);
        button.setOnClickListener(v -> forceStopCurrentApp());
        button.setContentDescription(label.getText());
        return button;
    }

    private void forceStopCurrentApp() {
        String packageName = resolvePackageName();
        if (packageName == null || packageName.length() == 0) {
            showForceStopError("Paket aplikasi tidak ditemukan");
            return;
        }
        if (getContext().checkSelfPermission(FORCE_STOP_PERMISSION)
                != PackageManager.PERMISSION_GRANTED) {
            showForceStopError("Izin sistem Force Stop tidak diberikan pada Launcher");
            return;
        }

        try {
            forceStopPackage(packageName, resolveTaskUserId());
            Toast.makeText(getContext(), "Aplikasi dihentikan paksa", Toast.LENGTH_SHORT).show();
            dismissTaskCard();
        } catch (Throwable error) {
            Throwable cause = unwrap(error);
            Log.e(TAG, "Force Stop tidak berhasil untuk " + packageName, cause);
            showForceStopError("Force Stop gagal: " + errorMessage(cause));
        }
    }

    /** Android 10 Binder API, scoped to the user profile that owns this task. */
    private void forceStopPackage(String packageName, int userId) throws Exception {
        Throwable binderError = null;
        try {
            Method getService = ActivityManager.class.getDeclaredMethod("getService");
            getService.setAccessible(true);
            Object service = getService.invoke(null);
            Method forceStop = service.getClass().getMethod(
                    "forceStopPackage", String.class, int.class);
            forceStop.invoke(service, packageName, userId);
            return;
        } catch (Throwable error) {
            binderError = unwrap(error);
        }

        // ActivityManager's one-argument wrapper targets the current Android user only.
        // Do not fall back to it for a task from a different profile.
        int currentUser = android.os.Process.myUid() / 100000;
        if (userId != currentUser) {
            if (binderError instanceof Exception) throw (Exception) binderError;
            throw new IllegalStateException(binderError);
        }
        try {
            ActivityManager manager = (ActivityManager)
                    getContext().getSystemService(Context.ACTIVITY_SERVICE);
            Method forceStop = ActivityManager.class.getDeclaredMethod(
                    "forceStopPackage", String.class);
            forceStop.setAccessible(true);
            forceStop.invoke(manager, packageName);
        } catch (Throwable fallbackError) {
            Throwable cause = unwrap(fallbackError);
            if (binderError != null) cause.addSuppressed(binderError);
            if (cause instanceof Exception) throw (Exception) cause;
            throw new IllegalStateException(cause);
        }
    }

    private String resolvePackageName() {
        try {
            Object task = currentTask();
            if (task == null) return null;
            Field keyField = task.getClass().getField("key");
            Object key = keyField.get(task);
            if (key == null) return null;

            Field intentField = key.getClass().getField("baseIntent");
            Intent intent = (Intent) intentField.get(key);
            if (intent != null) {
                ComponentName component = intent.getComponent();
                if (component != null) return component.getPackageName();
                String packageName = intent.getPackage();
                if (packageName != null && packageName.length() > 0) return packageName;
            }

            Field sourceField = key.getClass().getField("sourceComponent");
            ComponentName source = (ComponentName) sourceField.get(key);
            return source == null ? null : source.getPackageName();
        } catch (Throwable error) {
            Log.e(TAG, "Tidak dapat membaca package task", error);
            return null;
        }
    }

    private int resolveTaskUserId() {
        try {
            Object task = currentTask();
            Object key = task.getClass().getField("key").get(task);
            Object value = key.getClass().getField("userId").get(key);
            if (value instanceof Number) return ((Number) value).intValue();
        } catch (Throwable error) {
            Log.w(TAG, "User ID task tidak terbaca; memakai user Launcher", error);
        }
        return android.os.Process.myUid() / 100000;
    }

    private void dismissTaskCard() {
        try {
            ViewParent taskView = getParent();
            if (taskView == null) return;
            ViewParent parent = taskView.getParent();
            while (parent != null) {
                for (Method method : parent.getClass().getMethods()) {
                    if (!"dismissTask".equals(method.getName())) continue;
                    Class<?>[] types = method.getParameterTypes();
                    if (types.length == 0 || !types[0].isInstance(taskView)) continue;
                    Object[] args = new Object[types.length];
                    args[0] = taskView;
                    boolean supported = true;
                    for (int i = 1; i < types.length; i++) {
                        if (types[i] == boolean.class) args[i] = Boolean.TRUE;
                        else supported = false;
                    }
                    if (supported) {
                        method.invoke(parent, args);
                        return;
                    }
                }
                parent = parent.getParent();
            }
        } catch (Throwable error) {
            Log.e(TAG, "Force Stop berhasil tetapi kartu Recents gagal dihapus", error);
        }
    }

    private void showForceStopError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }

    private String errorMessage(Throwable error) {
        String message = error == null ? null : error.getMessage();
        if (message == null || message.length() == 0) return "periksa izin sistem";
        return message;
    }

    private static Throwable unwrap(Throwable error) {
        if (error instanceof InvocationTargetException
                && ((InvocationTargetException) error).getCause() != null) {
            return ((InvocationTargetException) error).getCause();
        }
        return error;
    }

    private LinearLayout newButton(Context context) {
        LinearLayout button = new LinearLayout(context);
        button.setOrientation(HORIZONTAL);
        button.setGravity(Gravity.CENTER);
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xB3FFFFFF);
        background.setCornerRadius(dp(12));
        background.setStroke(Math.max(1, dp(1)), 0xB3FFFFFF);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(12));
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x22000000), background, mask));
        button.setClickable(true);
        return button;
    }

    private TextView newLabel(Context context) {
        TextView text = new TextView(context);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        text.setSingleLine(true);
        text.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return text;
    }

    private Object currentTask() {
        try {
            ViewParent parent = getParent();
            return parent == null ? null : parent.getClass().getMethod("getTask").invoke(parent);
        } catch (Throwable error) {
            return null;
        }
    }

    private static final class CrossView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        CrossView(Context context) {
            super(context);
            paint.setColor(0xFF14243A);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(1.75f * context.getResources().getDisplayMetrics().density);
        }
        @Override protected void onDraw(Canvas canvas) {
            float margin = getWidth() * 0.22f;
            canvas.drawLine(margin, margin, getWidth() - margin, getHeight() - margin, paint);
            canvas.drawLine(getWidth() - margin, margin, margin, getHeight() - margin, paint);
        }
    }
}
