package simp.recents;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;

/**
 * Recents action bar. It renders every enabled TaskSystemShortcut supplied by
 * ShadyQuickStep, then a dedicated Force Stop action.
 */
public class TaskActionBar extends LinearLayout {
    private static final String TAG = "RecentsMod";
    private static final long TICK_MS = 500L;
    private static final int BTN_H = 36;
    private static final int GAP = 6;

    private final float mDp;
    private Object mBoundTask;
    private final Runnable mTick = new Runnable() {
        @Override public void run() {
            Object task = currentTask();
            if (task != mBoundTask) {
                mBoundTask = task;
                rebuild();
            }
            if (isAttachedToWindow()) postDelayed(this, TICK_MS);
        }
    };

    public TaskActionBar(Context context) { this(context, null); }
    public TaskActionBar(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public TaskActionBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mDp = context.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
    }

    private int dp(float value) { return Math.round(value * mDp); }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        mBoundTask = null;
        removeCallbacks(mTick);
        post(mTick);
    }

    @Override protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    private void rebuild() {
        removeAllViews();
        if (mBoundTask == null) return;
        try {
            View shortcutRow = buildShortcutRow();
            if (shortcutRow != null) {
                addView(shortcutRow, new LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H)));
            }
        } catch (Throwable error) {
            Log.e(TAG, "Gagal membuat shortcut Recents", error);
        }
        LayoutParams closeLp = new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(BTN_H));
        closeLp.topMargin = getChildCount() > 0 ? dp(GAP) : 0;
        addView(buildForceStopButton(), closeLp);
    }

    /** Use the exact shortcut list and listener path used by TaskView itself. */
    private View buildShortcutRow() throws Exception {
        ViewParent parent = getParent();
        if (!(parent instanceof View)) return null;
        final View taskView = (View) parent;
        ClassLoader loader = taskView.getClass().getClassLoader();
        Context context = taskView.getContext();

        Class<?> factoryClass = Class.forName(
                "com.android.quickstep.TaskOverlayFactory", true, loader);
        Class<?> holderClass = Class.forName(
                "com.android.launcher3.util.MainThreadInitializedObject", true, loader);
        Object holder = factoryClass.getField("INSTANCE").get(null);
        Object factory = holderClass.getMethod("get", Context.class).invoke(holder, context);
        Class<?> taskViewClass = Class.forName(
                "com.android.quickstep.views.TaskView", true, loader);
        List<?> shortcuts = (List<?>) factoryClass
                .getMethod("getEnabledShortcuts", taskViewClass).invoke(factory, taskView);
        if (shortcuts == null || shortcuts.isEmpty()) return null;

        Class<?> shortcutClass = Class.forName(
                "com.android.quickstep.TaskSystemShortcut", true, loader);
        Class<?> activityClass = Class.forName(
                "com.android.launcher3.BaseDraggingActivity", true, loader);
        Method getListener = shortcutClass.getMethod(
                "getOnClickListener", activityClass, taskViewClass);
        Method setIconAndLabel = shortcutClass.getMethod(
                "setIconAndLabelFor", View.class, TextView.class);
        Object activity = getTaskActivity(taskView, activityClass);
        if (activity == null) throw new IllegalStateException("TaskView.mActivity tidak tersedia");

        HorizontalScrollView scroller = new HorizontalScrollView(context);
        scroller.setFillViewport(true);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.setClipToPadding(false);
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        int count = 0;
        for (final Object shortcut : shortcuts) {
            final View.OnClickListener listener = (View.OnClickListener)
                    getListener.invoke(shortcut, activity, taskView);
            if (listener == null) continue;

            LinearLayout button = newButton(context);
            button.setPadding(dp(10), 0, dp(10), 0);
            button.setMinimumWidth(dp(72));
            View icon = new View(context);
            TextView label = newLabel(context);
            setIconAndLabel.invoke(shortcut, icon, label);
            icon.setBackgroundTintList(ColorStateList.valueOf(0xFF14243A));
            label.setTextColor(0xFF14243A);
            button.addView(icon, new LayoutParams(dp(16), dp(16)));
            LayoutParams labelLp = new LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            labelLp.setMarginStart(dp(6));
            button.addView(label, labelLp);
            button.setContentDescription(label.getText());
            button.setOnClickListener(v -> {
                try { listener.onClick(v); }
                catch (Throwable error) { Log.e(TAG, "Shortcut gagal dijalankan", error); }
            });

            LayoutParams buttonLp = new LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (count > 0) buttonLp.setMarginStart(dp(GAP));
            row.addView(button, buttonLp);
            count++;
        }
        if (count == 0) return null;
        scroller.addView(row, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return scroller;
    }

    private Object getTaskActivity(View taskView, Class<?> expectedClass) throws Exception {
        Class<?> type = taskView.getClass();
        while (type != null) {
            try {
                Field field = type.getDeclaredField("mActivity");
                field.setAccessible(true);
                Object activity = field.get(taskView);
                if (activity != null && expectedClass.isInstance(activity)) return activity;
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass();
                continue;
            }
            break;
        }
        // Fallback follows Launcher’s own BaseActivity.fromContext path.
        Class<?> baseActivity = Class.forName(
                "com.android.launcher3.BaseActivity", true, taskView.getClass().getClassLoader());
        Object activity = baseActivity.getMethod("fromContext", Context.class)
                .invoke(null, taskView.getContext());
        if (expectedClass.isInstance(activity)) return activity;
        return null;
    }

    private LinearLayout buildForceStopButton() {
        Context context = getContext();
        LinearLayout button = newButton(context);
        button.addView(new CrossView(context), new LayoutParams(dp(16), dp(16)));
        TextView label = newLabel(context);
        label.setTextColor(0xFF14243A);
        label.setText("id".equals(Locale.getDefault().getLanguage()) ? "Paksa berhenti" : "Force Stop");
        LayoutParams labelLp = new LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        labelLp.setMarginStart(dp(6));
        button.addView(label, labelLp);
        button.setOnClickListener(v -> forceStopCurrentApp());
        return button;
    }

    private void forceStopCurrentApp() {
        String packageName = resolvePackageName();
        if (packageName == null || packageName.length() == 0) {
            showForceStopError("Paket aplikasi tidak ditemukan");
            return;
        }
        try {
            // Hidden system API; works only when the system grants FORCE_STOP_PACKAGES.
            Method forceStop = ActivityManager.class.getDeclaredMethod(
                    "forceStopPackage", String.class);
            forceStop.setAccessible(true);
            forceStop.invoke((ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE),
                    packageName);
            dismissTaskCard();
        } catch (NoSuchMethodException missing) {
            // Android 10 fallback: call IActivityManager.forceStopPackage(pkg, userId).
            try {
                Class<?> activityManagerNative = Class.forName("android.app.ActivityManager",
                        false, getContext().getClassLoader());
                Method getService = activityManagerNative.getDeclaredMethod("getService");
                getService.setAccessible(true);
                Object service = getService.invoke(null);
                Method forceStop = service.getClass().getMethod(
                        "forceStopPackage", String.class, int.class);
                forceStop.invoke(service, packageName, android.os.Process.myUid() / 100000);
                dismissTaskCard();
            } catch (Throwable error) {
                Log.e(TAG, "Force Stop tidak berhasil untuk " + packageName, unwrap(error));
                showForceStopError("Force Stop gagal. Periksa izin FORCE_STOP_PACKAGES");
            }
        } catch (Throwable error) {
            Log.e(TAG, "Force Stop tidak berhasil untuk " + packageName, unwrap(error));
            showForceStopError("Force Stop gagal. Periksa izin FORCE_STOP_PACKAGES");
        }
    }

    private String resolvePackageName() {
        try {
            Object task = currentTask();
            if (task == null) return null;
            Field keyField = task.getClass().getField("key");
            Object key = keyField.get(task);
            if (key == null) return null;
            Field intentField = key.getClass().getField("baseIntent");
            Intent intent = (Intent) intentField.get(key);
            if (intent == null) return null;
            ComponentName component = intent.getComponent();
            if (component != null) return component.getPackageName();
            return intent.getPackage();
        } catch (Throwable error) {
            Log.e(TAG, "Tidak dapat membaca package task", error);
            return null;
        }
    }

    private void showForceStopError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }

    private static Throwable unwrap(Throwable error) {
        if (error instanceof InvocationTargetException
                && ((InvocationTargetException) error).getCause() != null) {
            return ((InvocationTargetException) error).getCause();
        }
        return error;
    }

    private LinearLayout newButton(Context context) {
        LinearLayout button = new LinearLayout(context);
        button.setOrientation(HORIZONTAL);
        button.setGravity(Gravity.CENTER);
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xB3FFFFFF);
        background.setCornerRadius(dp(12));
        background.setStroke(Math.max(1, dp(1)), 0xB3FFFFFF);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(12));
        button.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x22000000), background, mask));
        button.setClickable(true);
        return button;
    }

    private TextView newLabel(Context context) {
        TextView text = new TextView(context);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        text.setSingleLine(true);
        text.setEllipsize(android.text.TextUtils.TruncateAt.END);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return text;
    }

    private Object currentTask() {
        try {
            ViewParent parent = getParent();
            return parent == null ? null : parent.getClass().getMethod("getTask").invoke(parent);
        } catch (Throwable error) {
            return null;
        }
    }

    /** Remove only the selected card after force-stop succeeds. */
    private void dismissTaskCard() {
        try {
            ViewParent taskView = getParent();
            if (taskView == null) return;
            ViewParent parent = taskView.getParent();
            while (parent != null) {
                for (Method method : parent.getClass().getMethods()) {
                    if (!"dismissTask".equals(method.getName())) continue;
                    Class<?>[] types = method.getParameterTypes();
                    if (types.length == 0 || !types[0].isInstance(taskView)) continue;
                    Object[] args = new Object[types.length];
                    args[0] = taskView;
                    boolean supported = true;
                    for (int i = 1; i < types.length; i++) {
                        if (types[i] == boolean.class) args[i] = Boolean.TRUE;
                        else supported = false;
                    }
                    if (supported) { method.invoke(parent, args); return; }
                }
                parent = parent.getParent();
            }
        } catch (Throwable error) {
            Log.e(TAG, "Force Stop berhasil tetapi kartu Recents gagal dihapus", error);
        }
    }

    private static final class CrossView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        CrossView(Context context) {
            super(context);
            paint.setColor(0xFF14243A);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(1.75f * context.getResources().getDisplayMetrics().density);
        }
        @Override protected void onDraw(Canvas canvas) {
            float margin = getWidth() * 0.22f;
            canvas.drawLine(margin, margin, getWidth() - margin, getHeight() - margin, paint);
            canvas.drawLine(getWidth() - margin, margin, margin, getHeight() - margin, paint);
        }
    }
}
