package simp.drawer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Lebar kartu per aplikasi di app drawer: 1, 1,5, 2, atau 3 kolom (tinggi tidak diubah).
 * Disimpan dalam satuan span (1 kolom = DrawerGrid.UNITS_PER_COL = 2 satuan, jadi 1,5 kolom = 3 satuan).
 *
 * - spanFor(): dipanggil smali AllAppsGridAdapter$GridSpanSizer.getSpanSize (tools/patch_home_resize.py)
 *   untuk tiap item ikon; mengembalikan lebar tersimpan (default 1).
 * - show(): dialog pilihan lebar, dipanggil dari item menu "Ubah ukuran" (lewat simp.home.HomeResize).
 * Disimpan di SharedPreferences (drawer tidak punya tabel database), kunci = komponen + user.
 */
public final class DrawerResize {
    /** Satuan span (1 kolom = 2). File lama "shady_drawer_spans" menyimpan satuan kolom dan dimigrasi sekali. */
    private static final String PREFS = "shady_drawer_spans2";
    private static final String PREFS_OLD = "shady_drawer_spans";
    /** Pilihan lebar (satuan span) dan labelnya. */
    private static final int[] CHOICES = {2, 3, 4, 6};
    private static final String[] LABELS = {"1 kolom (normal)", "1,5 kolom", "2 kolom", "3 kolom (penuh)"};

    private static final Map<String, Integer> CACHE = new HashMap<String, Integer>();
    private static boolean loaded;
    private static Context appContext;
    private static Method getTargetComponent;

    private DrawerResize() {}

    // ---------------------------------------------------------------- dibaca saat layout

    /** @return lebar (satuan span) untuk AppInfo; DrawerGrid.DEFAULT_SPAN bila tidak diatur. Tidak pernah melempar exception. */
    public static synchronized int spanFor(Object appInfo) {
        try {
            if (appInfo == null) return DrawerGrid.DEFAULT_SPAN;
            ensureLoaded(null);
            if (CACHE.isEmpty()) return DrawerGrid.DEFAULT_SPAN;
            Integer v = CACHE.get(keyOf(appInfo));
            if (v == null) return DrawerGrid.DEFAULT_SPAN;
            return Math.max(DrawerGrid.DEFAULT_SPAN, Math.min(DrawerGrid.columns(), v));
        } catch (Throwable t) {
            return DrawerGrid.DEFAULT_SPAN;
        }
    }

    private static void ensureLoaded(Context ctx) {
        if (loaded) return;
        Context c = ctx != null ? ctx.getApplicationContext() : currentApplication();
        if (c == null) return; // belum siap: coba lagi pada panggilan berikutnya
        appContext = c;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        migrateOld(c, sp);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            if (e.getValue() instanceof Integer) CACHE.put(e.getKey(), (Integer) e.getValue());
        }
        loaded = true;
    }

    /** Pindahkan lebar lama (satuan kolom 1..3) ke format baru (x2), lalu kosongkan file lama. */
    private static void migrateOld(Context c, SharedPreferences dst) {
        try {
            SharedPreferences old = c.getSharedPreferences(PREFS_OLD, Context.MODE_PRIVATE);
            Map<String, ?> all = old.getAll();
            if (all.isEmpty()) return;
            SharedPreferences.Editor ed = dst.edit();
            for (Map.Entry<String, ?> e : all.entrySet()) {
                if (e.getValue() instanceof Integer && !dst.contains(e.getKey())) {
                    int v = (Integer) e.getValue() * DrawerGrid.UNITS_PER_COL;
                    if (v > DrawerGrid.DEFAULT_SPAN) ed.putInt(e.getKey(), Math.min(v, DrawerGrid.columns()));
                }
            }
            ed.commit();
            old.edit().clear().commit();
        } catch (Throwable ignored) {
            // migrasi gagal -> semua kartu kembali ke lebar normal
        }
    }

    private static Context currentApplication() {
        if (appContext != null) return appContext;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            return (Context) at.getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Kunci per aplikasi (komponen + user); dipakai juga oleh simp.home.CardFont. */
    public static String keyOf(Object appInfo) throws Exception {
        if (getTargetComponent == null) {
            getTargetComponent = appInfo.getClass().getMethod("getTargetComponent");
        }
        Object cn = getTargetComponent.invoke(appInfo);
        Object user = appInfo.getClass().getField("user").get(appInfo);
        return (cn == null ? "?" : ((android.content.ComponentName) cn).flattenToShortString()) + "|" + user;
    }

    // ---------------------------------------------------------------- dialog

    /** @param activity Launcher; @param info AppInfo yang ditekan lama. */
    public static void show(final Object activity, final Object info) {
        try {
            final Context ctx = (Context) activity;
            ensureLoaded(ctx);
            final int cur = spanFor(info);
            int checked = -1;
            for (int i = 0; i < CHOICES.length; i++) if (CHOICES[i] == cur) checked = i;
            new AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Lebar kartu di app drawer")
                    .setSingleChoiceItems(LABELS, checked, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            try {
                                save(ctx, info, CHOICES[which]);
                                refresh(activity);
                            } catch (Throwable t) {
                                toast(ctx, "Gagal mengubah lebar");
                            }
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable t) {
            toast(activity, "Gagal membuka ubah ukuran");
        }
    }

    private static synchronized void save(Context ctx, Object info, int span) throws Exception {
        ensureLoaded(ctx);
        String key = keyOf(info);
        SharedPreferences.Editor ed = ctx.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (span <= DrawerGrid.DEFAULT_SPAN) {
            CACHE.remove(key);
            ed.remove(key);
        } else {
            CACHE.put(key, span);
            ed.putInt(key, span);
        }
        ed.apply();
    }

    /** Buang cache span GridLayoutManager lalu bind ulang adapter drawer yang aktif. */
    public static void refresh(Object activity) throws Exception {
        Object appsView = activity.getClass().getMethod("getAppsView").invoke(activity);
        Object rv = appsView.getClass().getMethod("getActiveRecyclerView").invoke(appsView);
        Object lm = rv.getClass().getMethod("getLayoutManager").invoke(rv);
        Object lookup = lm.getClass().getMethod("getSpanSizeLookup").invoke(lm);
        lookup.getClass().getMethod("invalidateSpanIndexCache").invoke(lookup);
        Object adapter = rv.getClass().getMethod("getAdapter").invoke(rv);
        adapter.getClass().getMethod("notifyDataSetChanged").invoke(adapter);
        ((android.view.View) rv).requestLayout();
    }

    private static void toast(Object ctx, String msg) {
        try {
            Toast.makeText((Context) ctx, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
            // abaikan
        }
    }
}
