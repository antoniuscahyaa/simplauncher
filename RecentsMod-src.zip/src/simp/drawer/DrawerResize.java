package simp.drawer;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Lebar kartu per aplikasi di app drawer (1..DrawerGrid.COLUMNS kolom; tinggi tidak diubah).
 *
 * - spanFor(): dipanggil smali AllAppsGridAdapter$GridSpanSizer.getSpanSize (tools/patch_home_resize.py)
 *   untuk tiap item ikon; mengembalikan lebar tersimpan (default 1).
 * - show(): dialog pilihan lebar, dipanggil dari item menu "Ubah ukuran" (lewat simp.home.HomeResize).
 * Disimpan di SharedPreferences (drawer tidak punya tabel database), kunci = komponen + user.
 */
public final class DrawerResize {
    private static final String PREFS = "shady_drawer_spans";

    private static final Map<String, Integer> CACHE = new HashMap<String, Integer>();
    private static boolean loaded;
    private static Context appContext;
    private static Method getTargetComponent;

    private DrawerResize() {}

    // ---------------------------------------------------------------- dibaca saat layout

    /** @return lebar (jumlah kolom) untuk AppInfo; 1 bila tidak diatur. Tidak pernah melempar exception. */
    public static synchronized int spanFor(Object appInfo) {
        try {
            if (appInfo == null) return 1;
            ensureLoaded(null);
            if (CACHE.isEmpty()) return 1;
            Integer v = CACHE.get(keyOf(appInfo));
            if (v == null) return 1;
            return Math.max(1, Math.min(DrawerGrid.columns(), v));
        } catch (Throwable t) {
            return 1;
        }
    }

    private static void ensureLoaded(Context ctx) {
        if (loaded) return;
        Context c = ctx != null ? ctx.getApplicationContext() : currentApplication();
        if (c == null) return; // belum siap: coba lagi pada panggilan berikutnya
        appContext = c;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            if (e.getValue() instanceof Integer) CACHE.put(e.getKey(), (Integer) e.getValue());
        }
        loaded = true;
    }

    private static Context currentApplication() {
        if (appContext != null) return appContext;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            return (Context) at.getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String keyOf(Object appInfo) throws Exception {
        if (getTargetComponent == null) {
            getTargetComponent = appInfo.getClass().getMethod("getTargetComponent");
        }
        Object cn = getTargetComponent.invoke(appInfo);
        Object user = appInfo.getClass().getField("user").get(appInfo);
        return (cn == null ? "?" : ((android.content.ComponentName) cn).flattenToShortString()) + "|" + user;
    }

    // ---------------------------------------------------------------- dialog

    /** @param activity Launcher; @param info AppInfo yang ditekan lama. */
    public static void show(final Object activity, final Object info) {
        try {
            final Context ctx = (Context) activity;
            ensureLoaded(ctx);
            final int cols = DrawerGrid.columns();
            final int cur = spanFor(info);
            CharSequence[] labels = new CharSequence[cols];
            for (int i = 0; i < cols; i++) labels[i] = "Lebar " + (i + 1) + (i + 1 == 1 ? " kolom (normal)" : " kolom");
            new AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("Lebar kartu di app drawer")
                    .setSingleChoiceItems(labels, cur - 1, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            try {
                                save(ctx, info, which + 1);
                                refresh(activity);
                            } catch (Throwable t) {
                                toast(ctx, "Gagal mengubah lebar");
                            }
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable t) {
            toast(activity, "Gagal membuka ubah ukuran");
        }
    }

    private static synchronized void save(Context ctx, Object info, int span) throws Exception {
        ensureLoaded(ctx);
        String key = keyOf(info);
        SharedPreferences.Editor ed = ctx.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (span <= 1) {
            CACHE.remove(key);
            ed.remove(key);
        } else {
            CACHE.put(key, span);
            ed.putInt(key, span);
        }
        ed.apply();
    }

    /** Buang cache span GridLayoutManager lalu bind ulang adapter drawer yang aktif. */
    private static void refresh(Object activity) throws Exception {
        Object appsView = activity.getClass().getMethod("getAppsView").invoke(activity);
        Object rv = appsView.getClass().getMethod("getActiveRecyclerView").invoke(appsView);
        Object lm = rv.getClass().getMethod("getLayoutManager").invoke(rv);
        Object lookup = lm.getClass().getMethod("getSpanSizeLookup").invoke(lm);
        lookup.getClass().getMethod("invalidateSpanIndexCache").invoke(lookup);
        Object adapter = rv.getClass().getMethod("getAdapter").invoke(rv);
        adapter.getClass().getMethod("notifyDataSetChanged").invoke(adapter);
        ((android.view.View) rv).requestLayout();
    }

    private static void toast(Object ctx, String msg) {
        try {
            Toast.makeText((Context) ctx, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
            // abaikan
        }
    }
}
