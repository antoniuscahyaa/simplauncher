package simp.drawer;

import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;

import simp.recents.RecentsPrefs;

/**
 * Ukuran grid app drawer gaya Simp: 3 kolom nominal (6 satuan span), kartu lebar (ikon di kiri, label di kanan).
 * Dipanggil dari smali AllApps* / BubbleTextView lewat tools/patch_drawer.py.
 * Ubah konstanta di sini untuk menyetel kolom, tinggi sel, ukuran ikon, dan jarak ikon-label.
 */
public final class DrawerGrid {
    /**
     * Satuan grid: 1 kolom nominal = {@link #UNITS_PER_COL} satuan, supaya kartu bisa selebar 1,5 kolom
     * (3 satuan). Jumlah satuan per baris = NOMINAL_COLUMNS * UNITS_PER_COL; ini yang dipakai GridLayoutManager.
     */
    public static final int NOMINAL_COLUMNS = 3;
    public static final int UNITS_PER_COL = 2;
    public static final int COLUMNS = NOMINAL_COLUMNS * UNITS_PER_COL;
    /** Lebar bawaan kartu (satuan) = 1 kolom. */
    public static final int DEFAULT_SPAN = UNITS_PER_COL;
    private static final int CELL_HEIGHT_DP = 56; // kartu terlihat ~50dp (inset 3dp atas/bawah)
    private static final int ICON_DP = 36;
    private static final int GAP_DP = 10;

    private DrawerGrid() {}

    private static float density() {
        return Resources.getSystem().getDisplayMetrics().density;
    }

    private static int dp(int v) {
        return Math.round(v * density());
    }

    /** Padding atas negatif (rumus susunan vertikal pada kartu horizontal) dijadikan 0 supaya isi kartu tidak naik. */
    public static int fixTopPad(int pad) {
        return pad < 0 ? 0 : pad;
    }

    /** Jarak kiri/kanan pil search bar ke tepi layar; sejajar dengan tepi kartu pertama di grid. */
    private static final int SEARCH_INSET_DP = 13;

    /** Dipanggil dari smali AppsSearchContainerLayout.onMeasure (tools/patch_search.py). */
    public static int searchInsetPx() {
        return dp(SEARCH_INSET_DP);
    }

    /** Jumlah satuan span per baris (GridLayoutManager.spanCount). */
    public static int columns() {
        return COLUMNS;
    }

    /**
     * Jumlah kolom nominal (3) untuk perhitungan baris scrollbar/fast scroll, yang menganggap satu ikon = satu kolom.
     * Tetap 3 supaya perilakunya sama seperti sebelum ada kartu 1,5x.
     */
    public static int nominalColumns() {
        return NOMINAL_COLUMNS;
    }

    public static int cellHeightPx() {
        return dp(CELL_HEIGHT_DP);
    }

    public static int iconPx() {
        return dp(ICON_DP);
    }

    public static int gapPx() {
        return dp(GAP_DP);
    }

    /**
     * Sheet drawer: container diberi margin atas = (100 - persen) tinggi layar, sehingga hanya
     * persen bawah layar yang tertutup drawer. Dipanggil dari AllAppsContainerView.setInsets/reset.
     */
    public static void applyGap(View v) {
        if (v == null) return;
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        int pct = RecentsPrefs.sheetPct(v.getContext());
        int h = v.getResources().getDisplayMetrics().heightPixels;
        int gap = pct >= 100 ? 0 : Math.round(h * (100 - pct) / 100f);
        ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
        if (m.topMargin != gap) {
            m.topMargin = gap;
            v.setLayoutParams(m);
        }
    }
}
