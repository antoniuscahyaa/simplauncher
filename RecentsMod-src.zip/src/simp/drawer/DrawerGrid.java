package simp.drawer;

import android.content.res.Resources;

/**
 * Ukuran grid app drawer gaya Simp: 3 kolom, kartu lebar (ikon di kiri, label di kanan).
 * Dipanggil dari smali AllApps* / BubbleTextView lewat tools/patch_drawer.py.
 * Ubah konstanta di sini untuk menyetel kolom, tinggi sel, ukuran ikon, dan jarak ikon-label.
 */
public final class DrawerGrid {
    public static final int COLUMNS = 3;
    private static final int CELL_HEIGHT_DP = 56; // kartu terlihat ~50dp (inset 3dp atas/bawah)
    private static final int ICON_DP = 36;
    private static final int GAP_DP = 10;

    private DrawerGrid() {}

    private static float density() {
        return Resources.getSystem().getDisplayMetrics().density;
    }

    private static int dp(int v) {
        return Math.round(v * density());
    }

    public static int columns() {
        return COLUMNS;
    }

    public static int cellHeightPx() {
        return dp(CELL_HEIGHT_DP);
    }

    public static int iconPx() {
        return dp(ICON_DP);
    }

    public static int gapPx() {
        return dp(GAP_DP);
    }
}
