package simp.drawer;

import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;

import simp.recents.RecentsPrefs;

/**
 * Ukuran grid app drawer gaya Simp: 3 kolom, kartu lebar (ikon di kiri, label di kanan).
 * Dipanggil dari smali AllApps* / BubbleTextView lewat tools/patch_drawer.py.
 * Ubah konstanta di sini untuk menyetel kolom, tinggi sel, ukuran ikon, dan jarak ikon-label.
 */
public final class DrawerGrid {
    public static final int COLUMNS = 3;
    private static final int CELL_HEIGHT_DP = 56; // kartu terlihat ~50dp (inset 3dp atas/bawah)
    private static final int ICON_DP = 36;
    private static final int GAP_DP = 10;

    private DrawerGrid() {}

    private static float density() {
        return Resources.getSystem().getDisplayMetrics().density;
    }

    private static int dp(int v) {
        return Math.round(v * density());
    }

    public static int columns() {
        return COLUMNS;
    }

    public static int cellHeightPx() {
        return dp(CELL_HEIGHT_DP);
    }

    public static int iconPx() {
        return dp(ICON_DP);
    }

    public static int gapPx() {
        return dp(GAP_DP);
    }

    /**
     * Sheet drawer: container diberi margin atas = (100 - persen) tinggi layar, sehingga hanya
     * persen bawah layar yang tertutup drawer. Dipanggil dari AllAppsContainerView.setInsets/reset.
     */
    public static void applyGap(View v) {
        if (v == null) return;
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        if (!(lp instanceof ViewGroup.MarginLayoutParams)) return;
        int pct = RecentsPrefs.sheetPct(v.getContext());
        int h = v.getResources().getDisplayMetrics().heightPixels;
        int gap = pct >= 100 ? 0 : Math.round(h * (100 - pct) / 100f);
        ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
        if (m.topMargin != gap) {
            m.topMargin = gap;
            v.setLayoutParams(m);
        }
    }
}
