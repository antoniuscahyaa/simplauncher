package simp.home;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Icon;
import android.view.View;
import android.view.ViewParent;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Ubah ukuran kartu homescreen (kelipatan 0,5: lebar 0,5..jumlah kolom/2, tinggi 0,5..MAX_ROWS_SPAN) dan ukuran font kartu
 * (homescreen + drawer, lewat {@link CardFont}); keduanya dari satu item menu tekan-lama "Ubah kartu".
 *
 * Dipanggil dari smali (tools/patch_home_resize.py):
 *  - SystemShortcut$ShadyResize (item menu tekan-lama): icon() dan listener()
 *  - LoaderCursor.applyCommonProperties: span() membaca kolom spanX/spanY supaya ukuran tersimpan
 *    setelah launcher dimuat ulang (bawaan Launcher3 hanya membaca span untuk widget).
 *
 * Kelas Launcher3 tidak ada di classpath saat kompilasi, jadi semuanya lewat refleksi (nama kelas/method
 * diperiksa terhadap smali Launcher3 Android 10). Setiap kegagalan ditangkap dan hanya menampilkan Toast.
 */
public final class HomeResize {
    public static final int MAX_ROWS_SPAN = 2;

    private static final int CONTAINER_DESKTOP = -100;
    /** ItemInfo.NO_ID: item app drawer (AppInfo) tidak punya container. */
    private static final int CONTAINER_NONE = -1;
    private static final int ITEM_TYPE_APPLICATION = 0;
    private static final int ITEM_TYPE_SHORTCUT = 1;

    private HomeResize() {}

    // ---------------------------------------------------------------- hook smali

    /** Dipakai LoaderCursor: nilai span dari database, minimal 1. */
    public static int span(Cursor c, String column) {
        try {
            // Hanya item homescreen yang memakai span dari database (sudah dikali SCALE oleh GridScale).
            // Isi folder diabaikan: nilai lama 1 akan menjadi setengah kartu bila ia dipindah ke homescreen.
            int ci = c.getColumnIndex("container");
            if (ci >= 0 && c.getInt(ci) != CONTAINER_DESKTOP) return HomeCards.SCALE;
            int i = c.getColumnIndex(column);
            if (i < 0) return HomeCards.SCALE;
            return Math.max(1, c.getInt(i));
        } catch (Throwable t) {
            return 1;
        }
    }

    /** Ikon item menu: glyph panah diagonal ganda (hanya sebagai mask; warna diberikan tint popup). */
    public static Icon icon() {
        float d = android.content.res.Resources.getSystem().getDisplayMetrics().density;
        int s = Math.round(24 * d);
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(0xFF000000);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        float m = 4f * d, e = s - 4f * d, a = 6f * d;
        RectF r = new RectF(m + 2 * d, m + 2 * d, e - 2 * d, e - 2 * d);
        c.drawRoundRect(r, 3f * d, 3f * d, p);
        // panah sudut kanan-bawah
        c.drawLine(e - a - 2 * d, e - 2 * d, e - 2 * d, e - 2 * d, p);
        c.drawLine(e - 2 * d, e - a - 2 * d, e - 2 * d, e - 2 * d, p);
        return Icon.createWithBitmap(b);
    }

    /**
     * Dipanggil dari PopupContainerWithArrow.populateAndShow: tambahkan item "Ubah ukuran" ke daftar system shortcut
     * bila ikon yang ditekan adalah app/shortcut di homescreen. Tidak pernah melempar exception.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void addTo(java.util.List list, Object shortcut, Object activity, View icon) {
        try {
            if (list == null || shortcut == null || icon == null) return;
            Object info = icon.getTag();
            if (info == null || listener(activity, info) == null) return;
            for (Object o : list) {
                if (o != null && o.getClass() == shortcut.getClass()) return;
            }
            list.add(shortcut);
        } catch (Throwable ignored) {
            // daftar tidak bisa diubah (immutable) -> menu tidak tampil, tetapi popup tetap normal
        }
    }

    /**
     * @return listener bila item adalah app/shortcut di homescreen atau app di app drawer (menu tampil),
     *         null bila tidak (mis. folder, hotseat, prediksi).
     */
    public static View.OnClickListener listener(final Object activity, final Object info) {
        try {
            Class<?> launcher = Class.forName("com.android.launcher3.Launcher", false,
                    activity.getClass().getClassLoader());
            if (!launcher.isInstance(activity)) return null;
            int container = getInt(info, "container");
            int type = getInt(info, "itemType");
            boolean home = container == CONTAINER_DESKTOP
                    && (type == ITEM_TYPE_APPLICATION || type == ITEM_TYPE_SHORTCUT);
            boolean drawer = container == CONTAINER_NONE && type == ITEM_TYPE_APPLICATION;
            if (!home && !drawer) return null;
        } catch (Throwable t) {
            return null;
        }
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    closePopup(activity);
                    showMenu(activity, info);
                } catch (Throwable t) {
                    toast(activity, "Gagal membuka menu kartu");
                }
            }
        };
    }

    // ---------------------------------------------------------------- dialog

    /** Menu kecil: ukuran/lebar kartu, tampilan ikon dan label (hanya homescreen), atau ukuran font kartu itu. */
    private static void showMenu(final Object activity, final Object info) throws Exception {
        final boolean home = getInt(info, "container") == CONTAINER_DESKTOP;
        CharSequence[] items = home
                ? new CharSequence[] {"Ukuran kartu", "Tampilan ikon dan label", "Ukuran font"}
                : new CharSequence[] {"Lebar kartu", "Ukuran font"};
        new AlertDialog.Builder((Context) activity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Ubah kartu")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            if (home) {
                                if (which == 0) showDialog(activity, info);
                                else if (which == 1) showLook(activity, info);
                                else showFont(activity, info, true);
                            } else {
                                if (which == 0) simp.drawer.DrawerResize.show(activity, info);
                                else showFont(activity, info, false);
                            }
                        } catch (Throwable t) {
                            toast(activity, "Gagal membuka ubah ukuran");
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Dialog tampilan ikon dan label (simp.home.CardLook); pengaturan berlaku untuk kartu ini saja. */
    private static void showLook(final Object activity, final Object info) {
        View found = null;
        try {
            found = findItemView(activity, info);
        } catch (Throwable ignored) {
            // tanpa view: pratinjau memakai ukuran bawaan, kartu diperbarui saat di-bind ulang
        }
        final View view = found;
        CardLook.showDialog(activity, info, view, new Runnable() {
            @Override
            public void run() {
                CardLook.bindView(view, info);
            }
        });
    }

    private static void showFont(final Object activity, final Object info, final boolean home) {
        Runnable onChanged;
        if (home) {
            final View[] view = new View[1];
            try {
                view[0] = findItemView(activity, info);
            } catch (Throwable ignored) {
                // tanpa view: ukuran baru dipakai saat kartu di-bind ulang
            }
            onChanged = new Runnable() {
                @Override
                public void run() {
                    if (view[0] instanceof android.widget.TextView) {
                        CardFont.applyFont((android.widget.TextView) view[0], info, 0);
                    }
                }
            };
        } else {
            onChanged = new Runnable() {
                @Override
                public void run() {
                    try {
                        simp.drawer.DrawerResize.refresh(activity);
                    } catch (Throwable ignored) {
                        // tampil setelah drawer dibuka ulang
                    }
                }
            };
        }
        CardFont.showDialog(activity, info, home ? 0 : 1, onChanged);
    }

    private static void showDialog(final Object activity, final Object info) throws Exception {
        final Context ctx = (Context) activity;
        final View view = findItemView(activity, info);
        if (view == null) {
            toast(activity, "Kartu tidak ditemukan");
            return;
        }
        final Object cellLayout = cellLayoutOf(view);
        final int countX = (Integer) cellLayout.getClass().getMethod("getCountX").invoke(cellLayout);
        final int countY = (Integer) cellLayout.getClass().getMethod("getCountY").invoke(cellLayout);
        final int maxH = Math.min(MAX_ROWS_SPAN * HomeCards.SCALE, countY);
        final int curX = getInt(info, "spanX");
        final int curY = getInt(info, "spanY");

        final int n = countX * maxH;
        final int[] w = new int[n];
        final int[] h = new int[n];
        CharSequence[] labels = new CharSequence[n];
        int checked = -1;
        int k = 0;
        for (int sy = 1; sy <= maxH; sy++) {
            for (int sx = 1; sx <= countX; sx++) {
                w[k] = sx;
                h[k] = sy;
                labels[k] = "Lebar " + units(sx) + "  \u00D7  Tinggi " + units(sy);
                if (sx == curX && sy == curY) checked = k;
                k++;
            }
        }

        new AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Ubah ukuran kartu")
                .setSingleChoiceItems(labels, checked, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        try {
                            apply(activity, info, view, cellLayout, countX, countY, w[which], h[which]);
                        } catch (Throwable t) {
                            toast(activity, "Gagal mengubah ukuran");
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    /** Span (sel) -> satuan kartu penuh, mis. 3 -> "1,5"; 1 -> "0,5"; 4 -> "2". */
    private static String units(int span) {
        int whole = span / HomeCards.SCALE;
        int rest = span % HomeCards.SCALE;
        if (rest == 0) return String.valueOf(whole);
        if (HomeCards.SCALE == 2) return whole + ",5";
        return String.format(java.util.Locale.US, "%.2f", span / (float) HomeCards.SCALE).replace('.', ',');
    }

    // ---------------------------------------------------------------- terapkan

    private static void apply(Object activity, Object info, View view, Object cellLayout,
                              int countX, int countY, int sx, int sy) throws Exception {
        Object lp = view.getLayoutParams();
        int oldX = getInt(lp, "cellX");
        int oldY = getInt(lp, "cellY");
        if (sx == getInt(lp, "cellHSpan") && sy == getInt(lp, "cellVSpan")) return;

        // Jaga agar kartu tetap di dalam grid: geser ke kiri/atas bila melewati batas.
        int x = Math.max(0, Math.min(oldX, countX - sx));
        int y = Math.max(0, Math.min(oldY, countY - sy));
        int[] dir = new int[] {x < oldX ? -1 : 1, y < oldY ? -1 : 1};

        // CellLayout.createAreaForResize(cellX, cellY, spanX, spanY, View, int[] dir, boolean commit)
        // (package-private). commit=true: kartu lain yang tergeser langsung disimpan ke database.
        Method m = cellLayout.getClass().getDeclaredMethod("createAreaForResize",
                int.class, int.class, int.class, int.class, View.class, int[].class, boolean.class);
        m.setAccessible(true);
        boolean ok = (Boolean) m.invoke(cellLayout, x, y, sx, sy, view, dir, true);
        if (!ok) {
            toast(activity, "Ruang tidak cukup untuk ukuran itu");
            return;
        }

        // Kartu itu sendiri: perbarui layout params lalu simpan ke database.
        setInt(lp, "cellX", x);
        setInt(lp, "cellY", y);
        setInt(lp, "tmpCellX", x);
        setInt(lp, "tmpCellY", y);
        setInt(lp, "cellHSpan", sx);
        setInt(lp, "cellVSpan", sy);

        Object writer = activity.getClass().getMethod("getModelWriter").invoke(activity);
        Class<?> itemInfo = Class.forName("com.android.launcher3.ItemInfo", false,
                activity.getClass().getClassLoader());
        Method modify = writer.getClass().getMethod("modifyItemInDatabase", itemInfo,
                int.class, int.class, int.class, int.class, int.class, int.class);
        modify.invoke(writer, info, getInt(info, "container"), getInt(info, "screenId"), x, y, sx, sy);

        view.requestLayout();
        view.invalidate();
        ViewParent p = view.getParent();
        if (p instanceof View) ((View) p).requestLayout();
        ((View) cellLayout).requestLayout();
    }

    // ---------------------------------------------------------------- util refleksi

    private static View findItemView(Object activity, Object info) throws Exception {
        Object workspace = activity.getClass().getMethod("getWorkspace").invoke(activity);
        Method find = workspace.getClass().getMethod("getHomescreenIconByItemId", int.class);
        return (View) find.invoke(workspace, getInt(info, "id"));
    }

    /** View kartu -> ShortcutAndWidgetContainer -> CellLayout. */
    private static Object cellLayoutOf(View view) {
        ViewParent container = view.getParent();
        ViewParent cell = container == null ? null : container.getParent();
        if (cell == null) throw new IllegalStateException("CellLayout tidak ditemukan");
        return cell;
    }

    private static void closePopup(Object activity) {
        try {
            ClassLoader cl = activity.getClass().getClassLoader();
            Class<?> floating = Class.forName("com.android.launcher3.AbstractFloatingView", false, cl);
            Class<?> ctx = Class.forName("com.android.launcher3.views.ActivityContext", false, cl);
            floating.getMethod("closeAllOpenViews", ctx).invoke(null, activity);
        } catch (Throwable ignored) {
            // popup akan tertutup sendiri saat dialog tampil
        }
    }

    private static int getInt(Object o, String name) throws Exception {
        return field(o, name).getInt(o);
    }

    private static void setInt(Object o, String name, int v) throws Exception {
        field(o, name).setInt(o, v);
    }

    private static Field field(Object o, String name) throws NoSuchFieldException {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
                // naik ke superclass
            }
        }
        throw new NoSuchFieldException(name);
    }

    private static void toast(Object activity, String msg) {
        try {
            Toast.makeText((Context) activity, msg, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
            // abaikan
        }
    }
}
