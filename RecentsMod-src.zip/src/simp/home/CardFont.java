package simp.home;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Ukuran font label per kartu (homescreen dan app drawer).
 *
 * - applyFont(): dipanggil dari awal BubbleTextView.applyIconAndLabel (tools/patch_home.py) setiap kali kartu
 *   di-bind ke item. Bila item punya ukuran tersimpan, dipakai; bila tidak, kembali ke ukuran bawaan view
 *   (penting di drawer karena view didaur ulang antar aplikasi).
 * - showDialog(): dialog slider, dipanggil dari menu tekan-lama "Ubah kartu" (lewat simp.home.HomeResize).
 *
 * Kunci penyimpanan: homescreen = "h|" + id item di database (tiap kartu sendiri-sendiri);
 * drawer = "d|" + komponen + user (AppInfo tidak punya id). Disimpan di SharedPreferences.
 */
public final class CardFont {
    public static final float MIN_SP = 8f;
    public static final float MAX_SP = 24f;
    private static final float STEP_SP = 0.5f;

    private static final int DISPLAY_HOME = 0;
    private static final int DISPLAY_DRAWER = 1;

    private static final String PREFS = "shady_card_font";
    private static final Map<String, Float> CACHE = new HashMap<String, Float>();
    /** Ukuran bawaan (px) tiap view, dicatat saat bind pertama (sebelum ukuran kustom pernah dipasang). */
    private static final WeakHashMap<TextView, Float> DEFAULT_PX = new WeakHashMap<TextView, Float>();
    private static final float[] DISPLAY_DEFAULT_PX = new float[2];
    private static boolean loaded;

    private CardFont() {}

    // ---------------------------------------------------------------- dipanggil smali

    /** @param display nilai BubbleTextView.mDisplay: 0 = homescreen, 1 = app drawer; lainnya diabaikan. */
    public static synchronized void applyFont(TextView v, Object info, int display) {
        try {
            if (v == null || info == null) return;
            if (display != DISPLAY_HOME && display != DISPLAY_DRAWER) return;
            Float def = DEFAULT_PX.get(v);
            if (def == null) {
                def = v.getTextSize();
                DEFAULT_PX.put(v, def);
                if (DISPLAY_DEFAULT_PX[display] <= 0f) DISPLAY_DEFAULT_PX[display] = def;
            }
            ensureLoaded(v.getContext());
            Float sp = CACHE.isEmpty() ? null : CACHE.get(keyOf(info, display));
            float target = sp == null ? def : sp * v.getResources().getDisplayMetrics().scaledDensity;
            if (Math.abs(v.getTextSize() - target) > 0.01f) {
                v.setTextSize(TypedValue.COMPLEX_UNIT_PX, target);
            }
        } catch (Throwable ignored) {
            // gagal membaca pengaturan -> ukuran bawaan tetap dipakai
        }
    }

    // ---------------------------------------------------------------- penyimpanan

    private static void ensureLoaded(Context ctx) {
        if (loaded) return;
        Context c = ctx != null ? ctx.getApplicationContext() : null;
        if (c == null) return;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            if (e.getValue() instanceof Float) CACHE.put(e.getKey(), (Float) e.getValue());
        }
        loaded = true;
    }

    private static synchronized void save(Context ctx, String key, Float sp) {
        ensureLoaded(ctx);
        SharedPreferences.Editor ed = ctx.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (sp == null) {
            CACHE.remove(key);
            ed.remove(key);
        } else {
            CACHE.put(key, sp);
            ed.putFloat(key, sp);
        }
        ed.apply();
    }

    private static String keyOf(Object info, int display) throws Exception {
        if (display == DISPLAY_HOME) return "h|" + field(info, "id").getInt(info);
        return "d|" + simp.drawer.DrawerResize.keyOf(info);
    }

    private static Field field(Object o, String name) throws NoSuchFieldException {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
                // naik ke superclass
            }
        }
        throw new NoSuchFieldException(name);
    }

    // ---------------------------------------------------------------- dialog

    /**
     * @param display   0 = kartu homescreen, 1 = kartu app drawer
     * @param onChanged dijalankan di thread UI setelah ukuran disimpan/direset (untuk memperbarui tampilan)
     */
    public static void showDialog(final Object activity, final Object info, final int display,
                                  final Runnable onChanged) {
        try {
            final Context ctx = (Context) activity;
            ensureLoaded(ctx);
            final String key = keyOf(info, display);
            float density = ctx.getResources().getDisplayMetrics().scaledDensity;

            float defSp = display == DISPLAY_HOME ? HomeCards.LABEL_SP
                    : (DISPLAY_DEFAULT_PX[display] > 0f ? DISPLAY_DEFAULT_PX[display] / density : 14f);
            Float saved = CACHE.get(key);
            float start = clamp(saved != null ? saved : defSp);

            AlertDialog.Builder b = new AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert);
            final Context tc = b.getContext();
            float d = tc.getResources().getDisplayMetrics().density;
            int pad = Math.round(20 * d);

            LinearLayout box = new LinearLayout(tc);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(pad, pad / 2, pad, 0);

            final TextView preview = new TextView(tc);
            preview.setSingleLine(true);
            preview.setText(titleOf(info));
            preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, start);
            preview.setMinHeight(Math.round(48 * d));
            preview.setGravity(android.view.Gravity.CENTER_VERTICAL);
            box.addView(preview);

            final TextView value = new TextView(tc);
            value.setText(format(start) + (saved == null ? "  (bawaan)" : ""));
            box.addView(value);

            final SeekBar bar = new SeekBar(tc);
            bar.setMax(Math.round((MAX_SP - MIN_SP) / STEP_SP));
            bar.setProgress(Math.round((start - MIN_SP) / STEP_SP));
            bar.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                    float sp = MIN_SP + p * STEP_SP;
                    preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
                    value.setText(format(sp));
                }

                @Override
                public void onStartTrackingTouch(SeekBar sb) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar sb) {
                }
            });
            box.addView(bar);

            b.setTitle("Ukuran font")
                    .setView(box)
                    .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            save(ctx, key, MIN_SP + bar.getProgress() * STEP_SP);
                            run(onChanged);
                        }
                    })
                    .setNeutralButton("Bawaan", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            save(ctx, key, null);
                            run(onChanged);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable t) {
            try {
                Toast.makeText((Context) activity, "Gagal membuka pengaturan font", Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {
                // abaikan
            }
        }
    }

    private static void run(Runnable r) {
        try {
            if (r != null) r.run();
        } catch (Throwable ignored) {
            // tampilan akan diperbarui saat kartu di-bind ulang
        }
    }

    private static CharSequence titleOf(Object info) {
        try {
            Object t = field(info, "title").get(info);
            if (t instanceof CharSequence && ((CharSequence) t).length() > 0) return (CharSequence) t;
        } catch (Throwable ignored) {
            // pakai teks contoh
        }
        return "Contoh teks";
    }

    private static float clamp(float sp) {
        return Math.max(MIN_SP, Math.min(MAX_SP, sp));
    }

    private static String format(float sp) {
        float r = Math.round(sp * 2f) / 2f;
        String s = (r == (int) r) ? String.valueOf((int) r) : String.valueOf(r).replace('.', ',');
        return s + " sp";
    }
}
