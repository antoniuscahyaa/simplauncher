package simp.home;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * Kartu kaca homescreen gaya SimpLauncher: tinggi tetap {@link HomeCards#CARD_HEIGHT_DP} di tengah sel
 * (berapa pun tinggi sel Launcher3), jarak antar kartu {@link HomeCards#GAP_DP}, sudut membulat, garis tepi tipis,
 * dan lapisan terang saat ditekan.
 */
public final class HomeCardDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint press = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private boolean pressed;

    public HomeCardDrawable() {
        density = Resources.getSystem().getDisplayMetrics().density;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(HomeCards.FILL_COLOR);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(density);
        stroke.setColor(HomeCards.STROKE_COLOR);
        press.setStyle(Paint.Style.FILL);
        press.setColor(HomeCards.PRESS_COLOR);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float gap = HomeCards.GAP_DP * density;
        float h = Math.min(HomeCards.CARD_HEIGHT_DP * density, b.height() - gap);
        if (h <= 0 || b.width() <= gap) return;
        float cy = b.exactCenterY();
        rect.set(b.left + gap / 2f, cy - h / 2f, b.right - gap / 2f, cy + h / 2f);
        float r = HomeCards.RADIUS_DP * density;
        c.drawRoundRect(rect, r, r, fill);
        if (pressed) c.drawRoundRect(rect, r, r, press);
        float half = stroke.getStrokeWidth() / 2f;
        rect.inset(half, half);
        c.drawRoundRect(rect, r - half, r - half, stroke);
    }

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    protected boolean onStateChange(int[] state) {
        boolean p = false;
        for (int s : state) {
            if (s == android.R.attr.state_pressed) {
                p = true;
                break;
            }
        }
        if (p != pressed) {
            pressed = p;
            invalidateSelf();
            return true;
        }
        return false;
    }

    @Override
    public void setAlpha(int alpha) {
        // Alpha drawable dari luar menskalakan warna dasar.
        fill.setAlpha(((HomeCards.FILL_COLOR >>> 24) * alpha) / 255);
        stroke.setAlpha(((HomeCards.STROKE_COLOR >>> 24) * alpha) / 255);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        fill.setColorFilter(cf);
        stroke.setColorFilter(cf);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
