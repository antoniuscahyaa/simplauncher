package simp.home;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.view.View;

/**
 * Kartu kaca homescreen gaya SimpLauncher: tinggi tetap {@link HomeCards#CARD_HEIGHT_DP} di tengah sel
 * (berapa pun tinggi sel Launcher3), jarak antar kartu {@link HomeCards#GAP_DP}, sudut membulat, garis tepi tipis,
 * dan lapisan terang saat ditekan.
 */
public final class HomeCardDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint press = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint blurPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Matrix matrix = new Matrix();
    private final int[] loc = new int[2];
    private Bitmap shaderBmp;
    private final float density;
    private boolean pressed;

    public HomeCardDrawable() {
        density = Resources.getSystem().getDisplayMetrics().density;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(HomeCards.FILL_COLOR);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(density);
        stroke.setColor(HomeCards.STROKE_COLOR);
        press.setStyle(Paint.Style.FILL);
        press.setColor(HomeCards.PRESS_COLOR);
        tint.setStyle(Paint.Style.FILL);
        tint.setColor(HomeCards.TINT_COLOR);
    }

    /**
     * Isi kartu = potongan wallpaper blur (CardBlur) di posisi kartu di layar + lapisan putih translusen.
     * @return false bila blur tidak tersedia (pemanggil memakai warna datar FILL_COLOR)
     */
    private boolean drawBlur(Canvas c, float r) {
        Object cb = getCallback();
        if (!(cb instanceof View)) return false;
        View v = (View) cb;
        Bitmap bmp = CardBlur.bitmap(v.getContext());
        if (bmp == null || CardBlur.screenW() <= 0) return false;
        if (bmp != shaderBmp) {
            blurPaint.setShader(new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            shaderBmp = bmp;
        }
        v.getLocationOnScreen(loc);
        // bitmap = seluruh layar; titik (0,0) layar berada di (-loc) pada koordinat view
        matrix.setScale((float) CardBlur.screenW() / bmp.getWidth(), (float) CardBlur.screenH() / bmp.getHeight());
        matrix.postTranslate(-loc[0], -loc[1]);
        blurPaint.getShader().setLocalMatrix(matrix);
        c.drawRoundRect(rect, r, r, blurPaint);
        c.drawRoundRect(rect, r, r, tint);
        return true;
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float gap = HomeCards.GAP_DP * density;
        // Kartu 1 baris: tinggi tetap di tengah sel. Kartu yang diperbesar (tinggi > 1 baris, lihat HomeResize):
        // memenuhi seluruh tinggi sel dikurangi jarak.
        float nominalCell = (HomeCards.CARD_HEIGHT_DP + HomeCards.GAP_DP) * density;
        int rowsSpan = Math.max(1, Math.round(b.height() / nominalCell));
        float h = rowsSpan > 1
                ? b.height() - gap
                : Math.min(HomeCards.CARD_HEIGHT_DP * density, b.height() - gap);
        if (h <= 0 || b.width() <= gap) return;
        float cy = b.exactCenterY();
        rect.set(b.left + gap / 2f, cy - h / 2f, b.right - gap / 2f, cy + h / 2f);
        float r = HomeCards.RADIUS_DP * density;
        if (!drawBlur(c, r)) c.drawRoundRect(rect, r, r, fill);
        if (pressed) c.drawRoundRect(rect, r, r, press);
        float half = stroke.getStrokeWidth() / 2f;
        rect.inset(half, half);
        c.drawRoundRect(rect, r - half, r - half, stroke);
    }

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    protected boolean onStateChange(int[] state) {
        boolean p = false;
        for (int s : state) {
            if (s == android.R.attr.state_pressed) {
                p = true;
                break;
            }
        }
        if (p != pressed) {
            pressed = p;
            invalidateSelf();
            return true;
        }
        return false;
    }

    @Override
    public void setAlpha(int alpha) {
        // Alpha drawable dari luar menskalakan warna dasar.
        fill.setAlpha(((HomeCards.FILL_COLOR >>> 24) * alpha) / 255);
        tint.setAlpha(((HomeCards.TINT_COLOR >>> 24) * alpha) / 255);
        blurPaint.setAlpha(alpha);
        stroke.setAlpha(((HomeCards.STROKE_COLOR >>> 24) * alpha) / 255);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        fill.setColorFilter(cf);
        tint.setColorFilter(cf);
        blurPaint.setColorFilter(cf);
        stroke.setColorFilter(cf);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
