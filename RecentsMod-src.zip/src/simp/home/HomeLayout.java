package simp.home;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;

/**
 * Tata letak homescreen gaya SimpLauncher: kolom x baris kartu, rapat ke bawah, tanpa dock.
 *
 * Perubahan v5 (workspace sampai paling atas): sebelumnya jumlah baris diambil dari pengaturan grid
 * (mis. 7) dan padding atas diisi sisa layar, sehingga area workspace baru mulai di tengah layar dan
 * widget "mentok" di situ. Sekarang:
 *  - {@link #fitRows} menghitung jumlah baris yang memenuhi tinggi layar (tinggi sel = kartu + jarak),
 *    dipanggil dari InvariantDeviceProfile.initGridOption (tools/patch_home_grid.py);
 *  - {@link #adjust} membuat padding atas = 0, jadi workspace mulai tepat di bawah status bar dan
 *    widget/kartu bisa ditaruh sampai baris paling atas. Grid tetap menempel ke bawah (margin bawah tetap).
 */
public final class HomeLayout {
    /** Jarak grid dari tepi bawah area aman (sebelumnya 36dp; dikecilkan karena dock sudah tidak ada). */
    public static final int BOTTOM_MARGIN_DP = 10;
    /** Perkiraan status bar + gesture bar bila tidak bisa dibaca dari resource. */
    private static final int FALLBACK_INSETS_DP = 24 + 16;
    private static final int MIN_ROWS = 4;

    private HomeLayout() {}

    /**
     * Jumlah baris yang memenuhi layar portrait. Nilai dari pengaturan grid (prefRows) tidak dipakai lagi
     * karena batas atas slider-nya membuat workspace tidak bisa mencapai bagian atas layar.
     */
    public static int fitRows(Context ctx, int prefRows) {
        try {
            DisplayMetrics m = new DisplayMetrics();
            android.view.WindowManager wm =
                    (android.view.WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(m);
            float d = m.density;
            // Selalu pakai sisi panjang, supaya hasilnya tidak berubah saat layar diputar.
            int heightPx = Math.max(m.widthPixels, m.heightPixels);
            Resources r = ctx.getResources();
            int sb = 0;
            int id = r.getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) sb = r.getDimensionPixelSize(id);
            if (sb <= 0) sb = Math.round(24 * d);
            int gesture = Math.round((FALLBACK_INSETS_DP - 24) * d);
            float cellH = (HomeCards.CARD_HEIGHT_DP + HomeCards.GAP_DP) * d;
            float avail = heightPx - sb - gesture - BOTTOM_MARGIN_DP * d;
            // Baris kartu penuh dibulatkan dulu, lalu dikali SCALE: posisi lama (hasil migrasi x SCALE) tetap muat persis.
            int rows = Math.round(avail / cellH) * HomeCards.SCALE;
            return Math.max(MIN_ROWS * HomeCards.SCALE, rows);
        } catch (Throwable t) {
            return Math.max(MIN_ROWS * HomeCards.SCALE, prefRows);
        }
    }

    /**
     * Jumlah kolom grid = 3 kartu penuh x HomeCards.SCALE. Preferensi lama (pref_grid_columns) diabaikan:
     * nilai tersimpan dari versi sebelumnya (3) akan merusak migrasi grid 0,5.
     */
    public static int fitColumns(Context ctx, int prefColumns) {
        return 3 * HomeCards.SCALE;
    }

    /**
     * @param pad        DeviceProfile.workspacePadding (diubah di tempat)
     * @param heightPx   tinggi layar penuh (tidak dipakai lagi, dipertahankan agar panggilan smali tetap sama)
     * @param insets     inset sistem (status bar / gesture bar)
     * @param rows       jumlah baris grid (numRows)
     * @param verticalBar true bila layout landscape (dibiarkan apa adanya)
     */
    public static void adjust(Rect pad, int heightPx, Rect insets, int rows, boolean verticalBar) {
        if (verticalBar || rows <= 0 || pad == null || insets == null) return;
        float d = Resources.getSystem().getDisplayMetrics().density;
        // Padding atas 0: workspace memakai seluruh tinggi di bawah status bar. Launcher3 membagi tinggi itu
        // rata menjadi `rows` sel (selisih dengan CARD+GAP paling banyak sekitar 4%).
        pad.top = 0;
        pad.bottom = Math.round(BOTTOM_MARGIN_DP * d);
    }
}
