package simp.home;

import android.content.res.Resources;
import android.graphics.Rect;

/**
 * Tata letak homescreen gaya SimpLauncher: grid kolom x baris kartu, rapat ke bawah, tanpa dock.
 * Dipanggil dari smali DeviceProfile.updateWorkspacePadding lewat tools/patch_home_grid.py.
 *
 * Logika SimpLauncher (HomeScreen + HomeGrid): tinggi sel = tinggi kartu + jarak antar kartu, grid setinggi
 * rows * sel menempel di bawah layar dengan margin bawah tetap, sisa ruang di atas dipakai widget/tanggal.
 * Di sini sama: padding atas workspace dibuat sebesar sisa ruang itu, sehingga Launcher3 membagi tinggi
 * yang tersisa persis menjadi {@code rows} sel setinggi (CARD_HEIGHT_DP + GAP_DP).
 */
public final class HomeLayout {
    /** Jarak grid dari tepi bawah area aman (SimpLauncher: Spacer 36.dp). */
    public static final int BOTTOM_MARGIN_DP = 36;

    private HomeLayout() {}

    /**
     * @param pad        DeviceProfile.workspacePadding (diubah di tempat)
     * @param heightPx   tinggi layar penuh
     * @param insets     inset sistem (status bar / gesture bar)
     * @param rows       jumlah baris grid (numRows)
     * @param verticalBar true bila layout landscape (dibiarkan apa adanya)
     */
    public static void adjust(Rect pad, int heightPx, Rect insets, int rows, boolean verticalBar) {
        if (verticalBar || rows <= 0 || pad == null || insets == null) return;
        float d = Resources.getSystem().getDisplayMetrics().density;
        int cellH = Math.round((HomeCards.CARD_HEIGHT_DP + HomeCards.GAP_DP) * d);
        int bottom = Math.round(BOTTOM_MARGIN_DP * d);
        int top = heightPx - insets.top - insets.bottom - bottom - rows * cellH;
        // Baris lebih banyak dari yang muat (mis. diatur dari pengaturan grid di aplikasi): area grid mentok
        // di batas atas layar dan sel dimampatkan, supaya widget tetap bisa ditaruh sampai paling atas.
        if (top < 0) top = 0;
        pad.top = top;
        pad.bottom = bottom;
    }
}
