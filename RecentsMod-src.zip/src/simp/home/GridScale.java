package simp.home;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.lang.reflect.Method;

/**
 * Migrasi sekali jalan ke grid beresolusi {@link HomeCards#SCALE}x: posisi dan ukuran semua item homescreen
 * (container = desktop) dikali SCALE, sehingga tampilan lama persis sama dan ukuran kartu bisa kelipatan 0,5.
 *
 * Dipanggil dari awal GridSizeMigrationTask.migrateGridIfNeeded (tools/patch_half_grid.py), sebelum
 * Launcher3 membandingkan ukuran grid. Setelah berhasil, ukuran grid sumber migrasi bawaan Launcher3
 * disamakan dengan grid baru supaya GridSizeMigrationTask tidak menjalankan migrasinya sendiri
 * pada data yang sudah dikali. Isi folder dan hotseat tidak disentuh. Gagal -> tidak ada yang berubah
 * dan flag tidak diset (dicoba lagi di pemuatan berikutnya).
 */
public final class GridScale {
    private static final String TAG = "SimpGridScale";
    private static final String KEY_SCALE = "simp_grid_scale";
    private static final String KEY_SRC_SIZE = "migration_src_workspace_size";
    private static final int CONTAINER_DESKTOP = -100;

    private GridScale() {}

    public static void run(Context ctx, SharedPreferences prefs, String targetGrid) {
        Object tx = null;
        try {
            if (prefs.getInt(KEY_SCALE, 1) >= HomeCards.SCALE) return;
            ClassLoader cl = ctx.getClassLoader();
            Class<?> settings = Class.forName("com.android.launcher3.LauncherSettings$Settings", false, cl);
            Method call = settings.getMethod("call", ContentResolver.class, String.class);
            Bundle b = (Bundle) call.invoke(null, ctx.getContentResolver(), "new_db_transaction");
            tx = b.getBinder("value");
            SQLiteDatabase db = (SQLiteDatabase) tx.getClass().getMethod("getDb").invoke(tx);
            int f = HomeCards.SCALE;
            db.execSQL("UPDATE favorites SET cellX = cellX * " + f + ", cellY = cellY * " + f
                    + ", spanX = spanX * " + f + ", spanY = spanY * " + f
                    + " WHERE container = " + CONTAINER_DESKTOP);
            tx.getClass().getMethod("commit").invoke(tx);
            tx.getClass().getMethod("close").invoke(tx);
            tx = null;
            prefs.edit().putInt(KEY_SCALE, f).putString(KEY_SRC_SIZE, targetGrid).apply();
            Log.i(TAG, "grid homescreen dikali " + f + "; ukuran grid " + targetGrid);
        } catch (Throwable t) {
            Log.w(TAG, "migrasi grid x" + HomeCards.SCALE + " gagal; tidak ada perubahan", t);
            if (tx != null) {
                try {
                    tx.getClass().getMethod("close").invoke(tx);
                } catch (Throwable ignored) {
                    // transaksi dibatalkan karena tidak di-commit
                }
            }
        }
    }
}
