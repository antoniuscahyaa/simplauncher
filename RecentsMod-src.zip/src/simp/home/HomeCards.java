package simp.home;

import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

/**
 * Homescreen gaya SimpLauncher: tiap aplikasi = kartu kaca cerah (putih translusen, teks hitam) berisi nama saja (tanpa ikon), label rata kiri.
 * Dipanggil dari smali lewat tools/patch_home.py:
 *   - decorate(): akhir konstruktor BubbleTextView (hanya ikon homescreen/hotseat, display == 0)
 *   - textOnly(): awal applyCompoundDrawables (true = jangan gambar ikon)
 * Ubah konstanta di sini untuk menyetel tampilan. SHOW_ICON = true mengembalikan ikon di kiri label.
 */
public final class HomeCards {
    /** Nilai iconDisplay BubbleTextView untuk homescreen + hotseat. */
    public static final int DISPLAY_WORKSPACE = 0;

    public static final boolean SHOW_ICON = false;
    public static final int CARD_HEIGHT_DP = 52;
    public static final int GAP_DP = 10;
    public static final int RADIUS_DP = 16;
    public static final float LABEL_SP = 13.5f;
    public static final int LABEL_WEIGHT = 600; // SemiBold
    public static final int LABEL_COLOR = 0xFF000000;      // teks hitam
    public static final int FILL_COLOR = 0xB3FFFFFF;       // cadangan bila blur wallpaper gagal
    /** Lapisan putih di atas wallpaper blur (kartu cerah). Makin besar alpha = makin pucat/terbaca. */
    public static final int TINT_COLOR = 0x8CFFFFFF;
    public static final int STROKE_COLOR = 0x80FFFFFF;
    public static final int PRESS_COLOR = 0x26000000;      // gelap tipis saat ditekan (kartu terang)
    /** Jarak teks dari tepi kiri/kanan kartu (dp). Dulu efektifnya hanya ~3dp karena padding ditimpa measureChild. */
    public static final int PAD_X_DP = 14;

    private HomeCards() {}

    public static boolean textOnly(int display) {
        return display == DISPLAY_WORKSPACE && !SHOW_ICON;
    }

    public static void decorate(TextView v, int display) {
        if (display != DISPLAY_WORKSPACE) return;
        float d = v.getResources().getDisplayMetrics().density;
        v.setBackground(new HomeCardDrawable());
        v.setGravity(Gravity.CENTER_VERTICAL | Gravity.START); // label rata kiri
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, LABEL_SP);
        v.setTypeface(Typeface.create(Typeface.DEFAULT, LABEL_WEIGHT, false));
        v.setTextColor(LABEL_COLOR);
        int px = padXPx(d);
        v.setPadding(px, 0, px, 0);
        v.setSingleLine(true);
    }

    private static int padXPx(float density) {
        // kartu digambar menjorok GAP/2 dari tepi view, jadi padding = jarak teks + GAP/2
        return Math.round(PAD_X_DP * density) + Math.round(GAP_DP * density / 2f);
    }

    /**
     * Dipanggil dari ShortcutAndWidgetContainer.measureChild (tools/patch_home.py) tepat sebelum setPadding:
     * Launcher3 menimpa padding kiri/kanan ikon dengan workspaceCellPaddingXPx (~8dp) di setiap measure, sehingga
     * padding dari decorate() hilang dan label menempel di tepi kartu. Untuk view berlatar HomeCardDrawable
     * nilai itu diganti; view lain (folder, widget) tidak disentuh. Nilainya konstan, jadi tidak memicu requestLayout berulang.
     */
    public static int cellPadX(View v, int original) {
        if (v != null && v.getBackground() instanceof HomeCardDrawable) {
            return padXPx(v.getResources().getDisplayMetrics().density);
        }
        return original;
    }
}
