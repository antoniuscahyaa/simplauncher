package simp.home;

import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

/**
 * Homescreen gaya SimpLauncher: tiap aplikasi = kartu kaca berisi nama saja (tanpa ikon), label di tengah.
 * Dipanggil dari smali BubbleTextView lewat tools/patch_home.py:
 *   - decorate(): akhir konstruktor BubbleTextView (hanya ikon homescreen/hotseat, display == 0)
 *   - textOnly(): awal applyCompoundDrawables (true = jangan gambar ikon)
 * Ubah konstanta di sini untuk menyetel tampilan. SHOW_ICON = true mengembalikan ikon di kiri label.
 */
public final class HomeCards {
    /** Nilai iconDisplay BubbleTextView untuk homescreen + hotseat. */
    public static final int DISPLAY_WORKSPACE = 0;

    public static final boolean SHOW_ICON = false;
    public static final int CARD_HEIGHT_DP = 52;
    public static final int GAP_DP = 10;
    public static final int RADIUS_DP = 16;
    public static final float LABEL_SP = 13.5f;
    public static final int LABEL_WEIGHT = 600; // SemiBold
    public static final int LABEL_COLOR = 0xFFFFFFFF;
    public static final int FILL_COLOR = 0x66101C2C;
    public static final int STROKE_COLOR = 0x2EFFFFFF;
    public static final int PRESS_COLOR = 0x26FFFFFF;
    private static final int PAD_X_DP = 10;

    private HomeCards() {}

    public static boolean textOnly(int display) {
        return display == DISPLAY_WORKSPACE && !SHOW_ICON;
    }

    public static void decorate(TextView v, int display) {
        if (display != DISPLAY_WORKSPACE) return;
        float d = v.getResources().getDisplayMetrics().density;
        v.setBackground(new HomeCardDrawable());
        v.setGravity(textOnly(display) ? Gravity.CENTER : Gravity.CENTER_VERTICAL | Gravity.START);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, LABEL_SP);
        v.setTypeface(Typeface.create(Typeface.DEFAULT, LABEL_WEIGHT, false));
        v.setTextColor(LABEL_COLOR);
        int px = Math.round(PAD_X_DP * d) + Math.round(GAP_DP * d / 2f);
        v.setPadding(px, 0, px, 0);
        v.setSingleLine(true);
    }
}
