package simp.home;

import android.content.Context;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Homescreen gaya SimpLauncher: tiap aplikasi = kartu kaca cerah (putih translusen, teks hitam) berisi nama saja (tanpa ikon), label rata kiri.
 * Dipanggil dari smali lewat tools/patch_home.py:
 *   - decorate(): akhir konstruktor BubbleTextView (hanya ikon homescreen/hotseat, display == 0)
 *   - textOnly(): awal applyCompoundDrawables (true = jangan gambar ikon)
 * Ikon di kiri label bersifat opsional: saklar "Tampilkan ikon di kartu homescreen" di pengaturan (RecentsPrefs.KEY_HOME_ICON), mati secara bawaan.
 */
public final class HomeCards {
    /** Nilai iconDisplay BubbleTextView untuk homescreen + hotseat. */
    public static final int DISPLAY_WORKSPACE = 0;

    /**
     * Resolusi grid homescreen: 1 "kartu penuh" = SCALE x SCALE sel, sehingga ukuran kartu bisa kelipatan
     * 1/SCALE (0,5 bila SCALE = 2). Dipakai HomeLayout (jumlah baris), HomeResize (pilihan ukuran),
     * GridScale (migrasi database sekali jalan), dan tools/patch_home_grid.py (jumlah kolom = 3 x SCALE).
     */
    public static final int SCALE = 2;

    /** Ukuran ikon (dp) bila opsi ikon menyala, dan jarak ikon ke label. */
    public static final int ICON_DP = 28;
    public static final int ICON_GAP_DP = 8;
    public static final int CARD_HEIGHT_DP = 52;
    public static final int GAP_DP = 10;
    public static final int RADIUS_DP = 16;
    public static final float LABEL_SP = 13.5f;
    public static final int LABEL_WEIGHT = 600; // SemiBold
    public static final int LABEL_COLOR = 0xFF000000;      // teks hitam
    public static final int FILL_COLOR = 0xB3FFFFFF;       // cadangan bila blur wallpaper gagal
    /** Lapisan putih di atas wallpaper blur (kartu cerah). Makin besar alpha = makin pucat/terbaca. */
    public static final int TINT_COLOR = 0x66FFFFFF;
    public static final int STROKE_COLOR = 0x80FFFFFF;
    public static final int PRESS_COLOR = 0x26000000;      // gelap tipis saat ditekan (kartu terang)
    /** Jarak teks dari tepi kiri/kanan kartu (dp). Dulu efektifnya hanya ~3dp karena padding ditimpa measureChild. */
    public static final int PAD_X_DP = 14;

    private HomeCards() {}

    /** Kartu homescreen yang sudah dibuat, untuk menerapkan ulang opsi ikon seketika. */
    private static final Map<TextView, Boolean> CARDS = new WeakHashMap<TextView, Boolean>();
    private static volatile int sShowIcon = -1; // -1 belum dibaca

    public static boolean showIcon(Context c) {
        int v = sShowIcon;
        if (v < 0) {
            v = simp.recents.RecentsPrefs.homeIcon(c) ? 1 : 0;
            sShowIcon = v;
        }
        return v == 1;
    }

    /** Simpan opsi dan terapkan ke semua kartu yang tampil, tanpa memuat ulang Launcher. */
    public static void setShowIcon(Context c, boolean on) {
        simp.recents.RecentsPrefs.saveHomeIcon(c, on);
        sShowIcon = on ? 1 : 0;
        refreshIcons(c);
    }

    /**
     * Dipanggil dari awal BubbleTextView.applyCompoundDrawables (tools/patch_home.py).
     * @return 0 = bukan kartu homescreen (jalur bawaan Launcher3), 1 = jangan gambar ikon, 2 = gambar ikon di kiri label
     */
    public static int iconMode(TextView v, int display) {
        if (display != DISPLAY_WORKSPACE) return 0;
        return showIcon(v.getContext()) ? 2 : 1;
    }

    /** Ikon di kiri label; ukuran dibatasi tinggi kartu bila tinggi sudah diketahui. */
    public static void applyIcon(TextView v, Drawable icon) {
        if (icon == null) return;
        float d = v.getResources().getDisplayMetrics().density;
        int size = Math.round(ICON_DP * d);
        int h = v.getHeight();
        if (h > 0) size = Math.min(size, Math.max(1, Math.round(h - GAP_DP * d - 6 * d)));
        icon.setBounds(0, 0, size, size);
        v.setCompoundDrawablesRelative(icon, null, null, null);
        v.setCompoundDrawablePadding(Math.round(ICON_GAP_DP * d));
    }

    private static void refreshIcons(Context c) {
        try {
            boolean on = showIcon(c);
            for (TextView v : new java.util.ArrayList<TextView>(CARDS.keySet())) {
                if (v == null) continue;
                Drawable icon = null;
                try {
                    icon = (Drawable) v.getClass().getMethod("getIcon").invoke(v);
                } catch (Throwable ignored) {
                    // belum ada ikon; terpasang saat di-bind
                }
                if (on && icon != null) {
                    applyIcon(v, icon);
                } else {
                    v.setCompoundDrawablesRelative(null, null, null, null);
                    v.setCompoundDrawables(null, null, null, null);
                }
                v.requestLayout();
                v.invalidate();
            }
        } catch (Throwable ignored) {
            // sisanya mengikuti saat kartu di-bind ulang
        }
    }

    public static void decorate(TextView v, int display) {
        if (display != DISPLAY_WORKSPACE) return;
        CARDS.put(v, Boolean.TRUE);
        float d = v.getResources().getDisplayMetrics().density;
        v.setBackground(new HomeCardDrawable());
        v.setGravity(Gravity.CENTER_VERTICAL | Gravity.START); // label rata kiri
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, LABEL_SP);
        v.setTypeface(Typeface.create(Typeface.DEFAULT, LABEL_WEIGHT, false));
        v.setTextColor(LABEL_COLOR);
        int px = padXPx(d);
        v.setPadding(px, 0, px, 0);
        v.setSingleLine(true);
    }

    private static int padXPx(float density) {
        // kartu digambar menjorok GAP/2 dari tepi view, jadi padding = jarak teks + GAP/2
        return Math.round(PAD_X_DP * density) + Math.round(GAP_DP * density / 2f);
    }

    /**
     * Dipanggil dari awal DoubleShadowBubbleTextView.onDraw (tools/patch_home.py): untuk kartu homescreen teks digambar
     * polos, tanpa bayangan ganda bawaan Launcher3 (yang membuat teks tampak tebal/buram). Bayangan ambient dari
     * konstruktor juga dihapus dari paint. @return true = pakai BubbleTextView.onDraw biasa.
     */
    public static boolean plainText(TextView v) {
        if (v != null && v.getBackground() instanceof HomeCardDrawable) {
            v.getPaint().clearShadowLayer();
            return true;
        }
        return false;
    }

    /**
     * Dipanggil dari ShortcutAndWidgetContainer.measureChild (tools/patch_home.py) tepat sebelum setPadding:
     * Launcher3 menimpa padding kiri/kanan ikon dengan workspaceCellPaddingXPx (~8dp) di setiap measure, sehingga
     * padding dari decorate() hilang dan label menempel di tepi kartu. Untuk view berlatar HomeCardDrawable
     * nilai itu diganti; view lain (folder, widget) tidak disentuh. Nilainya konstan, jadi tidak memicu requestLayout berulang.
     */
    public static int cellPadX(View v, int original) {
        if (v != null && v.getBackground() instanceof HomeCardDrawable) {
            return padXPx(v.getResources().getDisplayMetrics().density);
        }
        return original;
    }

    /** True bila view ini kartu homescreen (berlatar HomeCardDrawable). */
    public static boolean isCardView(View v) {
        return v != null && v.getBackground() instanceof HomeCardDrawable;
    }

    /**
     * Persegi kartu (atau seluruh view bila bukan kartu) dalam koordinat layar. false bila view belum
     * punya ukuran. Dipakai animasi buka/tutup aplikasi supaya berpusat di lokasi aplikasi.
     */
    public static boolean screenRect(View v, RectF out) {
        if (v == null || v.getWidth() <= 0 || v.getHeight() <= 0) return false;
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        float l = loc[0];
        float t = loc[1];
        float w = v.getWidth();
        float h = v.getHeight();
        if (isCardView(v)) {
            float d = v.getResources().getDisplayMetrics().density;
            float gap = GAP_DP * d;
            float ch = Math.min(CARD_HEIGHT_DP * d, h - gap);
            float cy = t + h / 2f;
            out.set(l + gap / 2f, cy - ch / 2f, l + w - gap / 2f, cy + ch / 2f);
        } else {
            out.set(l, t, l + w, t + h);
        }
        return true;
    }
}
