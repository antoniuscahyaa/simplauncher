package simp.home;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import simp.recents.BoxBlur;

/**
 * Blur palsu untuk kartu homescreen (Android 10 tidak punya blur latar per-view): wallpaper di-blur SEKALI
 * menjadi bitmap seukuran layar (center-crop, sama seperti tampilan wallpaper), dipakai bersama semua kartu.
 * HomeCardDrawable menggambar potongan bitmap itu tepat di posisi kartunya, jadi kartu tampak seperti kaca buram.
 * Bitmap dibangun ulang bila wallpaper berganti (dicek paling sering tiap {@link #CHECK_MS}).
 */
public final class CardBlur {
    /** Lebar bitmap blur (px); tinggi mengikuti rasio layar. Makin kecil = makin halus dan makin ringan. */
    private static final int BMP_W = 160;
    /** Radius box blur pada bitmap kecil tadi; naikkan untuk blur lebih kuat. */
    private static final int RADIUS = 8;
    private static final long CHECK_MS = 3000;

    private static Bitmap sBitmap;
    /** true = wallpaper tidak terbaca (izin belum diberikan); bitmap null, dicoba lagi tiap CHECK_MS. */
    private static boolean sFailed;
    private static int sWallpaperId = Integer.MIN_VALUE;
    private static long sLastCheck;
    private static int sScreenW;
    private static int sScreenH;

    private CardBlur() {}

    /** @return bitmap blur, atau null bila wallpaper tidak bisa dibaca (pemanggil memakai warna datar). */
    public static synchronized Bitmap bitmap(Context ctx) {
        try {
            long now = System.currentTimeMillis();
            if (sLastCheck == 0 || now - sLastCheck > CHECK_MS) {
                sLastCheck = now;
                Context app = ctx.getApplicationContext();
                WallpaperManager wm = WallpaperManager.getInstance(app);
                int id = -1;
                try {
                    id = wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM);
                } catch (Throwable ignored) {
                    // id tidak terbaca: bitmap lama tetap dipakai setelah dibangun sekali
                }
                if (sBitmap == null || sFailed || id != sWallpaperId) {
                    sBitmap = build(app, wm);
                    sFailed = sBitmap == null;
                    sWallpaperId = id;
                }
            }
        } catch (Throwable t) {
            // biarkan sBitmap apa adanya
        }
        return sBitmap;
    }

    /** Ukuran layar nyata (px) yang dipetakan ke bitmap; valid setelah {@link #bitmap} dipanggil. */
    public static int screenW() {
        return sScreenW;
    }

    public static int screenH() {
        return sScreenH;
    }

    private static Bitmap build(Context app, WallpaperManager wm) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) app.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        // Selalu potret, supaya bitmap tidak berubah saat layar diputar.
        sScreenW = Math.min(dm.widthPixels, dm.heightPixels);
        sScreenH = Math.max(dm.widthPixels, dm.heightPixels);
        int w = BMP_W;
        int h = Math.max(1, Math.round(w * (float) sScreenH / sScreenW));
        Drawable wp = null;
        try {
            wp = wm.getDrawable();
        } catch (Throwable ignored) {
            // pakai warna cadangan
        }
        int iw = wp == null ? 0 : wp.getIntrinsicWidth();
        int ih = wp == null ? 0 : wp.getIntrinsicHeight();
        if (iw <= 0 || ih <= 0) return null;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float s = Math.max((float) w / iw, (float) h / ih);
        int dw = Math.round(iw * s);
        int dh = Math.round(ih * s);
        int l = (w - dw) / 2;
        int t = (h - dh) / 2;
        wp.setBounds(l, t, l + dw, t + dh);
        wp.draw(c);
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        BoxBlur.blur(px, w, h, RADIUS);
        bmp.setPixels(px, 0, w, 0, 0, w, h);
        return bmp;
    }
}
