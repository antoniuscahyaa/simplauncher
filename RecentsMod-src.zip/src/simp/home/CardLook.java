package simp.home;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Tampilan ikon dan label per kartu homescreen: label saja (bawaan), ikon + label, atau ikon saja; posisi ikon
 * (kiri/atas/kanan/bawah), rata konten (kiri/tengah/kanan), ukuran ikon, dan jarak ikon ke label.
 *
 * Kartu tanpa pengaturan tidak disentuh sama sekali (tetap tampil seperti sebelumnya). Kartu dengan pengaturan:
 *  - bind(): dipanggil dari CardFont.applyFont tiap kartu homescreen di-bind. Mencatat pengaturan kartu dan membuat warna teks
 *    bawaan TextView transparan, karena ikon dan label digambar sendiri oleh {@link #drawContent}.
 *  - afterDraw(): dipanggil dari DoubleShadowBubbleTextView.onDraw (tools/patch_home.py) setelah BubbleTextView.onDraw
 *    (titik notifikasi tetap digambar oleh Launcher3), menggambar ikon + label sesuai pengaturan.
 *  - showDialog(): dialog pengaturan dengan pratinjau langsung, dari menu tekan-lama "Ubah kartu".
 *
 * Kunci penyimpanan: "h|" + id item di database (per kartu), di SharedPreferences "shady_card_look".
 * Nilai: "mode,pos,align,ukuranIkonDp,jarakDp".
 */
public final class CardLook {
    public static final int MODE_LABEL = 0;
    public static final int MODE_BOTH = 1;
    public static final int MODE_ICON = 2;

    public static final int POS_LEFT = 0;
    public static final int POS_TOP = 1;
    public static final int POS_RIGHT = 2;
    public static final int POS_BOTTOM = 3;

    public static final int ALIGN_START = 0;
    public static final int ALIGN_CENTER = 1;
    public static final int ALIGN_END = 2;

    public static final int MIN_ICON_DP = 14;
    public static final int MAX_ICON_DP = 36;
    public static final int MAX_GAP_DP = 14;
    public static final int DEFAULT_ICON_DP = 22;
    public static final int DEFAULT_GAP_DP = 8;
    /** Jarak vertikal isi kartu ke tepi atas/bawah kartu (dp). */
    private static final float PAD_Y_DP = 6f;

    private static final String PREFS = "shady_card_look";
    private static final Map<String, Cfg> CACHE = new HashMap<String, Cfg>();
    private static final WeakHashMap<TextView, Cfg> VIEW_CFG = new WeakHashMap<TextView, Cfg>();
    private static final Paint ICON_PAINT = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private static boolean loaded;

    private CardLook() {}

    /** Pengaturan satu kartu. */
    public static final class Cfg {
        public int mode = MODE_LABEL;
        public int pos = POS_LEFT;
        public int align = ALIGN_START;
        public int size = DEFAULT_ICON_DP;
        public int gap = DEFAULT_GAP_DP;

        Cfg copy() {
            Cfg c = new Cfg();
            c.mode = mode;
            c.pos = pos;
            c.align = align;
            c.size = size;
            c.gap = gap;
            return c;
        }

        /** Sama dengan tampilan bawaan (label saja, rata kiri) -> tidak perlu disimpan. */
        boolean isDefault() {
            return mode == MODE_LABEL && align == ALIGN_START;
        }

        String encode() {
            return mode + "," + pos + "," + align + "," + size + "," + gap;
        }

        static Cfg decode(String s) {
            try {
                String[] p = s.split(",");
                if (p.length != 5) return null;
                Cfg c = new Cfg();
                c.mode = clampInt(Integer.parseInt(p[0].trim()), 0, 2);
                c.pos = clampInt(Integer.parseInt(p[1].trim()), 0, 3);
                c.align = clampInt(Integer.parseInt(p[2].trim()), 0, 2);
                c.size = clampInt(Integer.parseInt(p[3].trim()), MIN_ICON_DP, MAX_ICON_DP);
                c.gap = clampInt(Integer.parseInt(p[4].trim()), 0, MAX_GAP_DP);
                return c;
            } catch (Throwable t) {
                return null;
            }
        }
    }

    private static int clampInt(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ---------------------------------------------------------------- dipanggil smali / CardFont

    /** Catat pengaturan kartu ini (null bila tidak ada) dan atur warna teks bawaan TextView. Tidak melempar exception. */
    public static synchronized void bind(TextView v, Object info) {
        try {
            if (v == null || info == null) return;
            ensureLoaded(v.getContext());
            Cfg c = CACHE.isEmpty() ? null : CACHE.get(keyOf(info));
            if (c == null) {
                VIEW_CFG.remove(v);
                v.setTextColor(HomeCards.LABEL_COLOR);
            } else {
                VIEW_CFG.put(v, c);
                v.setTextColor(0); // teks digambar sendiri di afterDraw
            }
            v.invalidate();
        } catch (Throwable ignored) {
            // kartu tampil dengan gaya bawaan
        }
    }

    /** Dipanggil dari DoubleShadowBubbleTextView.onDraw setelah BubbleTextView.onDraw (hanya kartu homescreen). */
    public static void afterDraw(TextView v, Canvas c) {
        try {
            Cfg cfg = VIEW_CFG.get(v);
            if (cfg == null || c == null) return;
            float d = v.getResources().getDisplayMetrics().density;
            float gap = HomeCards.GAP_DP * d;
            float h = v.getHeight() - gap;
            if (h <= 0 || v.getWidth() <= gap) return;
            float cy = v.getHeight() / 2f;
            RectF card = new RectF(gap / 2f, cy - h / 2f, v.getWidth() - gap / 2f, cy + h / 2f);
            TextPaint p = new TextPaint(v.getPaint());
            p.clearShadowLayer();
            p.setColor(HomeCards.LABEL_COLOR);
            drawContent(c, card, cfg, iconOf(v.getTag()), v.getText(), p, d);
        } catch (Throwable ignored) {
            // gagal menggambar -> kartu kosong sesaat, tidak menjatuhkan launcher
        }
    }

    // ---------------------------------------------------------------- penggambaran

    /**
     * Menggambar ikon dan label di dalam kartu sesuai pengaturan. Dipakai juga oleh pratinjau di dialog.
     * @param card persegi kartu (tepi kartu yang terlihat)
     */
    static void drawContent(Canvas c, RectF card, Cfg cfg, Bitmap bmp, CharSequence title, TextPaint p, float d) {
        float padX = HomeCards.PAD_X_DP * d;
        float padY = PAD_Y_DP * d;
        float left = card.left + padX;
        float right = card.right - padX;
        float top = card.top + padY;
        float bottom = card.bottom - padY;
        float w = right - left;
        float h = bottom - top;
        if (w <= 0 || h <= 0) return;

        boolean showIcon = cfg.mode != MODE_LABEL && bmp != null;
        boolean showText = cfg.mode != MODE_ICON && title != null && title.length() > 0;
        float gap = cfg.gap * d;
        float want = cfg.size * d;
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineH = fm.descent - fm.ascent;
        float cy = (top + bottom) / 2f;

        c.save();
        c.clipRect(card);
        if (showIcon && showText && (cfg.pos == POS_TOP || cfg.pos == POS_BOTTOM)) {
            float icon = Math.min(want, w);
            float total = icon + gap + lineH;
            float y0 = cy - total / 2f;
            float iconY;
            float textY;
            if (cfg.pos == POS_TOP) {
                iconY = y0;
                textY = y0 + icon + gap;
            } else {
                textY = y0;
                iconY = y0 + lineH + gap;
            }
            CharSequence t = TextUtils.ellipsize(title, p, w, TextUtils.TruncateAt.END);
            float tw = p.measureText(t, 0, t.length());
            drawIcon(c, bmp, alignX(cfg.align, left, right, icon), iconY, icon);
            c.drawText(t, 0, t.length(), alignX(cfg.align, left, right, tw), textY - fm.ascent, p);
        } else if (showIcon && showText) {
            float icon = Math.min(want, h);
            float avail = Math.max(0f, w - icon - gap);
            CharSequence t = TextUtils.ellipsize(title, p, avail, TextUtils.TruncateAt.END);
            float tw = p.measureText(t, 0, t.length());
            float x0 = alignX(cfg.align, left, right, icon + gap + tw);
            float baseline = cy - (fm.ascent + fm.descent) / 2f;
            if (cfg.pos == POS_RIGHT) {
                c.drawText(t, 0, t.length(), x0, baseline, p);
                drawIcon(c, bmp, x0 + tw + gap, cy - icon / 2f, icon);
            } else {
                drawIcon(c, bmp, x0, cy - icon / 2f, icon);
                c.drawText(t, 0, t.length(), x0 + icon + gap, baseline, p);
            }
        } else if (showIcon) {
            float icon = Math.min(want, Math.min(w, h));
            drawIcon(c, bmp, alignX(cfg.align, left, right, icon), cy - icon / 2f, icon);
        } else if (showText) {
            CharSequence t = TextUtils.ellipsize(title, p, w, TextUtils.TruncateAt.END);
            float tw = p.measureText(t, 0, t.length());
            c.drawText(t, 0, t.length(), alignX(cfg.align, left, right, tw), cy - (fm.ascent + fm.descent) / 2f, p);
        }
        c.restore();
    }

    /** False bila ikon di atas/bawah label tidak muat di tinggi kartu ini (kartu 1 baris biasanya terlalu pendek). */
    static boolean fits(Cfg cfg, float cardW, float cardH, TextPaint p, float d) {
        if (cfg.mode != MODE_BOTH || (cfg.pos != POS_TOP && cfg.pos != POS_BOTTOM)) return true;
        float h = cardH - 2f * PAD_Y_DP * d;
        Paint.FontMetrics fm = p.getFontMetrics();
        return cfg.size * d + cfg.gap * d + (fm.descent - fm.ascent) <= h;
    }

    private static float alignX(int align, float left, float right, float width) {
        if (width >= right - left) return left;
        if (align == ALIGN_CENTER) return left + (right - left - width) / 2f;
        if (align == ALIGN_END) return right - width;
        return left;
    }

    private static void drawIcon(Canvas c, Bitmap bmp, float x, float y, float size) {
        if (bmp == null || size <= 0f) return;
        c.drawBitmap(bmp, null, new RectF(x, y, x + size, y + size), ICON_PAINT);
    }

    private static Bitmap iconOf(Object info) {
        try {
            if (info == null) return null;
            Object b = field(info, "iconBitmap").get(info);
            return b instanceof Bitmap ? (Bitmap) b : null;
        } catch (Throwable t) {
            return null;
        }
    }

    // ---------------------------------------------------------------- penyimpanan

    private static void ensureLoaded(Context ctx) {
        if (loaded) return;
        Context c = ctx != null ? ctx.getApplicationContext() : null;
        if (c == null) return;
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
            if (e.getValue() instanceof String) {
                Cfg cfg = Cfg.decode((String) e.getValue());
                if (cfg != null) CACHE.put(e.getKey(), cfg);
            }
        }
        loaded = true;
    }

    private static synchronized void save(Context ctx, String key, Cfg cfg) {
        ensureLoaded(ctx);
        SharedPreferences.Editor ed = ctx.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        if (cfg == null || cfg.isDefault()) {
            CACHE.remove(key);
            ed.remove(key);
        } else {
            CACHE.put(key, cfg);
            ed.putString(key, cfg.encode());
        }
        ed.apply();
    }

    private static String keyOf(Object info) throws Exception {
        return "h|" + field(info, "id").getInt(info);
    }

    private static Field field(Object o, String name) throws NoSuchFieldException {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
                // naik ke superclass
            }
        }
        throw new NoSuchFieldException(name);
    }

    // ---------------------------------------------------------------- dialog

    /** Pratinjau kartu: gambar kartu seukuran aslinya di atas latar wallpaper polos. */
    private static final class Preview extends View {
        private final Cfg cfg;
        private final Bitmap bmp;
        private final CharSequence title;
        private final TextPaint base;
        private final float cardW;
        private final float cardH;
        private final float d;
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        Preview(Context ctx, Cfg cfg, Bitmap bmp, CharSequence title, TextPaint base, float cardW, float cardH) {
            super(ctx);
            this.cfg = cfg;
            this.bmp = bmp;
            this.title = title;
            this.base = base;
            this.cardW = cardW;
            this.cardH = cardH;
            this.d = ctx.getResources().getDisplayMetrics().density;
            bg.setColor(0xFF7E9FB5);
            fill.setColor(0xB3FFFFFF);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(d);
            stroke.setColor(HomeCards.STROKE_COLOR);
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(MeasureSpec.getSize(widthSpec), Math.round(cardH + 24f * d));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            c.drawRoundRect(new RectF(0, 0, w, h), 12f * d, 12f * d, bg);
            float cw = Math.min(cardW, w - 16f * d);
            float x = (w - cw) / 2f;
            float y = (h - cardH) / 2f;
            RectF card = new RectF(x, y, x + cw, y + cardH);
            float r = HomeCards.RADIUS_DP * d;
            c.drawRoundRect(card, r, r, fill);
            c.drawRoundRect(card, r, r, stroke);
            TextPaint p = new TextPaint(base);
            p.setColor(HomeCards.LABEL_COLOR);
            drawContent(c, card, cfg, bmp, title, p, d);
        }
    }

    /** Deretan pilihan (segmented) sederhana. */
    private static final class Seg {
        final TextView[] items;
        int value;

        Seg(Context ctx, LinearLayout parent, String label, String[] names, int current, final Runnable onPick,
            final int[] holder) {
            float d = ctx.getResources().getDisplayMetrics().density;
            TextView lb = new TextView(ctx);
            lb.setText(label);
            lb.setTextSize(13f);
            lb.setPadding(0, Math.round(12 * d), 0, Math.round(4 * d));
            parent.addView(lb);
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            parent.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            items = new TextView[names.length];
            value = current;
            for (int i = 0; i < names.length; i++) {
                final int idx = i;
                TextView t = new TextView(ctx);
                t.setText(names[i]);
                t.setTextSize(13f);
                t.setGravity(Gravity.CENTER);
                t.setSingleLine(true);
                t.setPadding(Math.round(4 * d), Math.round(10 * d), Math.round(4 * d), Math.round(10 * d));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                lp.setMargins(Math.round(2 * d), 0, Math.round(2 * d), 0);
                t.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        value = idx;
                        holder[0] = idx;
                        paint(v.getContext());
                        onPick.run();
                    }
                });
                row.addView(t, lp);
                items[i] = t;
            }
            paint(ctx);
        }

        void paint(Context ctx) {
            float d = ctx.getResources().getDisplayMetrics().density;
            for (int i = 0; i < items.length; i++) {
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(8f * d);
                g.setColor(i == value ? 0xFF185FA5 : 0x33FFFFFF);
                items[i].setBackground(g);
                items[i].setTextColor(0xFFFFFFFF);
            }
        }
    }

    /**
     * @param view kartu yang ditekan (untuk ukuran asli dan font); boleh null
     * @param onChanged dijalankan di thread UI setelah pengaturan disimpan/direset
     */
    public static void showDialog(final Object activity, final Object info, final Object view,
                                  final Runnable onChanged) {
        try {
            final Context ctx = (Context) activity;
            ensureLoaded(ctx);
            final String key = keyOf(info);
            Cfg saved = CACHE.get(key);
            final Cfg cur = saved != null ? saved.copy() : new Cfg();
            if (saved == null) cur.mode = MODE_BOTH; // dialog dibuka dari bawaan: tampilkan dulu ikon + label

            AlertDialog.Builder b = new AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert);
            final Context tc = b.getContext();
            final float d = tc.getResources().getDisplayMetrics().density;
            int pad = Math.round(20 * d);

            float cardW = 120f * d;
            float cardH = HomeCards.CARD_HEIGHT_DP * d;
            TextPaint base = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            base.setTextSize(HomeCards.LABEL_SP * tc.getResources().getDisplayMetrics().scaledDensity);
            base.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,
                    HomeCards.LABEL_WEIGHT, false));
            if (view instanceof TextView && ((View) view).getWidth() > 0) {
                TextView tv = (TextView) view;
                float gap = HomeCards.GAP_DP * d;
                cardW = Math.max(40f * d, tv.getWidth() - gap);
                cardH = Math.max(20f * d, tv.getHeight() - gap);
                base = new TextPaint(tv.getPaint());
            }
            CharSequence title = titleOf(info);

            LinearLayout box = new LinearLayout(tc);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(pad, pad / 2, pad, 0);

            final Preview preview = new Preview(tc, cur, iconOf(info), title, base, cardW, cardH);
            box.addView(preview, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            final TextView note = new TextView(tc);
            note.setTextSize(12f);
            note.setTextColor(0xFFFFB74D);
            note.setPadding(0, Math.round(8 * d), 0, 0);

            final TextPaint fitPaint = base;
            final float fw = cardW;
            final float fh = cardH;
            final Runnable refresh = new Runnable() {
                @Override
                public void run() {
                    preview.invalidate();
                    note.setText(fits(cur, fw, fh, fitPaint, d) ? ""
                            : "Ikon di atas/bawah tidak muat di kartu ini. Kecilkan ikon atau jarak, atau ubah tinggi kartu.");
                }
            };

            final int[] hMode = {cur.mode};
            final int[] hPos = {cur.pos};
            final int[] hAlign = {cur.align};
            new Seg(tc, box, "Tampilan", new String[] {"Label", "Ikon + label", "Ikon"}, cur.mode, new Runnable() {
                @Override
                public void run() {
                    cur.mode = hMode[0];
                    refresh.run();
                }
            }, hMode);
            new Seg(tc, box, "Posisi ikon", new String[] {"Kiri", "Atas", "Kanan", "Bawah"}, cur.pos, new Runnable() {
                @Override
                public void run() {
                    cur.pos = hPos[0];
                    refresh.run();
                }
            }, hPos);
            new Seg(tc, box, "Rata konten", new String[] {"Kiri", "Tengah", "Kanan"}, cur.align, new Runnable() {
                @Override
                public void run() {
                    cur.align = hAlign[0];
                    refresh.run();
                }
            }, hAlign);

            addSlider(tc, box, "Ukuran ikon", MIN_ICON_DP, MAX_ICON_DP, cur.size, new SliderListener() {
                @Override
                public void onValue(int v) {
                    cur.size = v;
                    refresh.run();
                }
            });
            addSlider(tc, box, "Jarak ikon dan label", 0, MAX_GAP_DP, cur.gap, new SliderListener() {
                @Override
                public void onValue(int v) {
                    cur.gap = v;
                    refresh.run();
                }
            });
            box.addView(note);
            refresh.run();

            ScrollView sv = new ScrollView(tc);
            sv.addView(box);

            b.setTitle("Tampilan ikon dan label")
                    .setView(sv)
                    .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            save(ctx, key, cur);
                            run(onChanged);
                        }
                    })
                    .setNeutralButton("Bawaan", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            save(ctx, key, null);
                            run(onChanged);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable t) {
            try {
                Toast.makeText((Context) activity, "Gagal membuka pengaturan tampilan", Toast.LENGTH_SHORT).show();
            } catch (Throwable ignored) {
                // abaikan
            }
        }
    }

    /** Terapkan ulang pengaturan ke satu kartu (setelah dialog ditutup). */
    public static void bindView(View v, Object info) {
        if (v instanceof TextView) bind((TextView) v, info);
    }

    private interface SliderListener {
        void onValue(int v);
    }

    private static void addSlider(Context tc, LinearLayout box, String label, final int min, int max, int value,
                                  final SliderListener l) {
        float d = tc.getResources().getDisplayMetrics().density;
        final TextView lb = new TextView(tc);
        lb.setTextSize(13f);
        lb.setPadding(0, Math.round(12 * d), 0, 0);
        lb.setText(label + ": " + value + " dp");
        box.addView(lb);
        final String name = label;
        SeekBar bar = new SeekBar(tc);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                int v = min + p;
                lb.setText(name + ": " + v + " dp");
                l.onValue(v);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        box.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private static void run(Runnable r) {
        try {
            if (r != null) r.run();
        } catch (Throwable ignored) {
            // tampilan diperbarui saat kartu di-bind ulang
        }
    }

    private static CharSequence titleOf(Object info) {
        try {
            Object t = field(info, "title").get(info);
            if (t instanceof CharSequence && ((CharSequence) t).length() > 0) return (CharSequence) t;
        } catch (Throwable ignored) {
            // pakai teks contoh
        }
        return "Contoh";
    }
}
