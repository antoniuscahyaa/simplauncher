#!/usr/bin/env bash
# Membangun ShadyQuickStep: kartu kaca, action bar Force Stop, carousel bertumpuk, Clear All overlay, blur/scrim.
# Dijalankan oleh GitHub Actions dari folder proyek ini.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
ORIG="$ROOT/ShadyQuickStep.apk"
OUT="$ROOT/dist"
W="$ROOT/work"
DIAG="$OUT/diagnostics"
APKTOOL_VERSION="${APKTOOL_VERSION:-2.9.3}"

rm -rf "$W" "$OUT"
mkdir -p "$W" "$OUT" "$DIAG"

[ -f "$ORIG" ] || { echo "ShadyQuickStep.apk tidak ada di zip"; exit 1; }

# ---- SDK ----
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[ -n "$SDK" ] || { echo "ANDROID_HOME tidak diset"; exit 1; }
BT="$SDK/build-tools/$(ls "$SDK/build-tools" | sort -V | tail -n1)"
AJAR="$SDK/platforms/$(ls "$SDK/platforms" | sort -V | tail -n1)/android.jar"
echo "build-tools: $BT"
echo "android.jar: $AJAR"

# ---- tools ----
curl -fsSL -o "$W/apktool.jar" "https://github.com/iBotPeaches/Apktool/releases/download/v${APKTOOL_VERSION}/apktool_${APKTOOL_VERSION}.jar"

# ---- kunci tanda tangan: APK asli memakai AOSP platform key (publik). Dipakai ulang supaya
#      tanda tangan identik dengan aslinya. ----
KEYDIR="$W/key"
mkdir -p "$KEYDIR"
fetch_key() {
  local base="$1"
  curl -fsSL -o "$KEYDIR/platform.pk8" "$base/platform.pk8" && curl -fsSL -o "$KEYDIR/platform.x509.pem" "$base/platform.x509.pem"
}
fetch_key "https://raw.githubusercontent.com/aosp-mirror/platform_build/master/target/product/security" \
  || fetch_key "https://raw.githubusercontent.com/LineageOS/android_build/lineage-17.1/target/product/security" \
  || { echo "Gagal mengunduh platform key"; exit 1; }

orig_fp=$(unzip -p "$ORIG" META-INF/CERT.RSA | openssl pkcs7 -inform DER -print_certs | openssl x509 -noout -fingerprint -sha256)
key_fp=$(openssl x509 -in "$KEYDIR/platform.x509.pem" -noout -fingerprint -sha256)
echo "sertifikat asli : $orig_fp"
echo "sertifikat kunci: $key_fp"
if [ "$orig_fp" != "$key_fp" ]; then
  echo "GAGAL: kunci tidak cocok dengan tanda tangan APK asli. Berhenti supaya tidak membuat APK dengan tanda tangan berbeda."
  exit 1
fi

# ---- decode resource + smali (smali PagedView/RecentsView dibutuhkan untuk carousel) ----
java -jar "$W/apktool.jar" d -f -o "$W/dec" "$ORIG" 2>&1 | tee "$DIAG/apktool-decode.log"
cp "$W/dec/res/layout/task.xml" "$DIAG/task.orig.xml" || true
cp "$W/dec/res/layout/overview_clear_all_button.xml" "$DIAG/clear_all.orig.xml" || true
grep -rhE 'name="(task_thumbnail_top_margin|task_thumbnail_icon_size|task_corner_radius_small)"' "$W/dec/res"/values* > "$DIAG/dimens.orig.txt" || true
grep -rhE 'name="(all_apps_[a-z_]*|dynamic_grid_cell_[a-z_]*|BaseIcon[A-Za-z.]*)"' "$W/dec/res"/values* > "$DIAG/allapps-dimens.orig.txt" || true
# daftar resource terkait pencarian/QSB/scrim (hanya diagnostik)
(
  set +e
  {
    echo "## layout"; ls "$W/dec/res" | grep -E '^layout' | while read d; do ls "$W/dec/res/$d" | grep -iE 'search|qsb|all_apps'; done | sort -u
    echo "## drawable"; ls "$W/dec/res" | grep -E '^drawable' | while read d; do ls "$W/dec/res/$d" | grep -iE 'search|qsb|scrim|allapps|ic_allapps'; done | sort -u
    echo "## values (attr/style/color)"; grep -rhiE 'allAppsScrim|allAppsInterim|allAppsNavBar|scrim|qsb' "$W/dec/res/values/attrs.xml" "$W/dec/res/values/styles.xml" "$W/dec/res/values/colors.xml" "$W/dec/res/values/public.xml" 2>/dev/null | sort -u
  } > "$DIAG/res-search-scrim.txt"
  exit 0
) || true
# diagnostik homescreen (grid, geometri sel, hotseat) untuk tahap berikutnya
for f in launcher workspace_screen hotseat folder_icon user_folder_icon_normalized; do
  cp "$W/dec/res/layout/$f.xml" "$DIAG/$f.orig.xml" 2>/dev/null || true
done
cp "$W/dec/res/xml/device_profiles.xml" "$DIAG/device_profiles.orig.xml" 2>/dev/null || true
grep -rhE 'name="(dynamic_grid_[a-z_]*|workspace_[a-z_]*|hotseat_[a-z_]*|qsb_[a-z_]*|cell_layout_[a-z_]*)"' "$W/dec/res"/values* > "$DIAG/home-dimens.orig.txt" 2>/dev/null || true
for f in task_menu task_view_menu_option overview_panel digital_wellbeing_toast app_icon all_apps_icon all_apps all_apps_rv_layout search_container_all_apps_plus all_apps_fast_scroller floating_header_content; do
  cp "$W/dec/res/layout/$f.xml" "$DIAG/$f.orig.xml" 2>/dev/null || true
done

# ---- diagnostik tambahan: smali kelas Recents (hanya untuk dikirim ke saya, tidak masuk APK) ----
# Dekode terpisah tanpa resource (-r) supaya tidak mengganggu build utama; gagal pun tidak menghentikan build.
(
  set +e
  java -jar "$W/apktool.jar" d -r -f -o "$W/dec-smali" "$ORIG" > "$DIAG/apktool-smali.log" 2>&1
  if [ -d "$W/dec-smali" ]; then
    cd "$W/dec-smali"
    find . \( -path '*/com/android/quickstep/views/*' -o -path '*/com/android/quickstep/TaskOverlayFactory*' \
      -o -path '*/com/android/launcher3/PagedView*' -o -path '*/com/android/launcher3/PagedOrientationHandler*' \
      -o -path '*/com/android/quickstep/RecentsAnimation*' \
      -o -path '*/com/android/launcher3/allapps/*' -o -path '*/com/android/launcher3/BubbleTextView*' \
      -o -path '*/com/android/launcher3/views/DoubleShadowBubbleTextView*' \
      -o -path '*/com/android/launcher3/DeviceProfile*' -o -path '*/com/android/launcher3/InvariantDeviceProfile*' \
      -o -path '*/com/android/launcher3/Workspace*' -o -path '*/com/android/launcher3/CellLayout*' -o -path '*/com/android/launcher3/Hotseat*' \
      -o -path '*/com/android/launcher3/ShortcutAndWidgetContainer*' -o -path '*/com/android/launcher3/shady/ShadyLauncher*' \
      -o -path '*/com/android/launcher3/shady/qsb/*' -o -path '*/com/android/launcher3/views/ScrimView*' \
      -o -path '*/com/android/launcher3/LauncherState*' -o -path '*/com/android/launcher3/uioverrides/states/*' \
      -o -path '*/com/android/launcher3/ItemInfo*' -o -path '*/com/android/launcher3/LauncherSettings*' \
      -o -path '*/com/android/launcher3/Launcher.smali' -o -path '*/com/android/launcher3/Launcher$*' -o -path '*/com/android/launcher3/LauncherModel*' \
      -o -path '*/com/android/launcher3/model/*' -o -path '*/com/android/launcher3/popup/*' -o -path '*/com/android/launcher3/shortcuts/*' \
      -o -path '*/com/android/launcher3/util/GridOccupancy*' -o -path '*/com/android/launcher3/touch/ItemLongClickListener*' \
      -o -path '*/com/android/launcher3/AppWidgetResizeFrame*' -o -path '*/com/android/launcher3/LauncherAppWidget*' \
      -o -path '*/com/android/quickstep/util/LayoutUtils*' -o -path '*/com/android/quickstep/*ActivityControllerHelper*' \
      -o -path '*/com/android/quickstep/*ActivityInterface*' -o -path '*/com/android/launcher3/Utilities.smali' \) -name '*.smali' > "$W/smali-list.txt"
    wc -l "$W/smali-list.txt" | tee -a "$DIAG/apktool-smali.log"
    zip -q "$DIAG/smali-recents.zip" -@ < "$W/smali-list.txt"
    ls smali*/ -d > "$DIAG/smali-dirs.txt" 2>/dev/null
  fi
  exit 0
) || true

# ---- patch ----
python3 "$ROOT/tools/patch.py" "$W/dec" "$ROOT/patch" 2>&1 | tee "$DIAG/patch.log"
python3 "$ROOT/tools/patch_theme.py" "$W/dec" "$ROOT/patch" 2>&1 | tee "$DIAG/patch_theme.log"
python3 "$ROOT/tools/patch_drawer.py" "$W/dec" 2>&1 | tee "$DIAG/patch_drawer.log"
python3 "$ROOT/tools/patch_search.py" "$W/dec" "$ROOT/patch" 2>&1 | tee "$DIAG/patch_search.log"
python3 "$ROOT/tools/patch_home.py" "$W/dec" 2>&1 | tee "$DIAG/patch_home.log"
python3 "$ROOT/tools/patch_home_grid.py" "$W/dec" 2>&1 | tee "$DIAG/patch_home_grid.log"
cp "$W/dec/res/layout/task.xml" "$DIAG/task.patched.xml"

# ---- build resource ----
java -jar "$W/apktool.jar" b -f -o "$W/res-built.apk" "$W/dec" 2>&1 | tee "$DIAG/apktool-build.log"

# ---- kompilasi semua class Java tambahan (label, action bar, carousel, blur/scrim) ----
mkdir -p "$W/classes"
javac -source 8 -target 8 -Xlint:-options -cp "$AJAR" -d "$W/classes" $(find "$ROOT/src" -name '*.java')
(cd "$W/classes" && jar cf "$W/label.jar" .)
mkdir -p "$W/dexout"
"$BT/d8" --lib "$AJAR" --min-api 29 --output "$W/dexout" "$W/label.jar"
ls -l "$W/dexout"

# ---- gabungkan, align, tanda tangani ----
python3 "$ROOT/tools/inject_dex.py" "$W/res-built.apk" "$W/dexout/classes.dex" "$W/injected.apk"
"$BT/zipalign" -f -p 4 "$W/injected.apk" "$W/aligned.apk"
"$BT/apksigner" sign \
  --key "$KEYDIR/platform.pk8" --cert "$KEYDIR/platform.x509.pem" \
  --v1-signing-enabled true --v2-signing-enabled true \
  --out "$W/ShadyQuickStep.apk" "$W/aligned.apk"
"$BT/apksigner" verify --print-certs "$W/ShadyQuickStep.apk" | tee "$DIAG/verify.log"
signed_fp=$("$BT/apksigner" verify --print-certs "$W/ShadyQuickStep.apk" | grep -i 'SHA-256 digest' | head -n1 | sed 's/.*: //' | tr -d ':' | tr 'a-f' 'A-F')
orig_hex=$(echo "$orig_fp" | sed 's/.*=//' | tr -d ':')
[ "$signed_fp" = "$orig_hex" ] || { echo "GAGAL: sertifikat APK baru tidak sama dengan aslinya ($signed_fp vs $orig_hex)"; exit 1; }

# ---- zip flashable ----
make_zip() {
  local mode="$1" apk="$2" zipname="$3"
  local d="$W/zip-$mode"
  rm -rf "$d"
  mkdir -p "$d/payload"
  cp -r "$ROOT/flash/META-INF" "$d/"
  chmod 755 "$d/META-INF/com/google/android/update-binary"
  echo "$mode" > "$d/mode.txt"
  cp "$apk" "$d/payload/ShadyQuickStep.apk"
  (cd "$d" && zip -r -9 -X "$OUT/$zipname" META-INF mode.txt payload >/dev/null)
}
make_zip install "$W/ShadyQuickStep.apk" "RecentsMod-install.zip"
make_zip restore "$ORIG" "RecentsMod-restore.zip"

cp "$W/ShadyQuickStep.apk" "$OUT/ShadyQuickStep-patched.apk"
ls -l "$OUT"
echo "SELESAI"
