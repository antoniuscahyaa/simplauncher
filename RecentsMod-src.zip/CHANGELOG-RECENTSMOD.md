# RecentsMod — In-card collapsible actions

## UI changes
- Kept the existing overlapping Recents carousel controller and native TaskView/PagedView ownership.
- Removed the always-visible action rows from the default card state.
- Added a small centered chevron pill inside the bottom area of each task card.
- Tapping the chevron reveals the existing Split Screen, App Info, and Force Stop controls inside a translucent rounded panel at the bottom of that same card.
- Tapping the chevron again collapses the panel; changing the bound task rebuilds the action footer in its collapsed state.
- Reduced the thumbnail's bottom reservation to make room for the embedded chevron. The expanded action panel overlays the lower part of the preview rather than changing carousel page geometry.
- Added short alpha/vertical transitions for opening and closing the action panel.

## PagedView index repair retained
The supplied crash trace showed `PagedView.getPageScrolls()` indexing page 8 in an array of length 8 during `RecentsView.createTaskDismissAnimation()`. The prior custom page-count/filter/max-scroll changes remain removed so native Launcher page indexing stays consistent.

## Known limitations
- Full Android build and on-device interaction have not been run in this environment.
- Force Stop still stops the package only when the privileged permission is actually granted; removing its card from Recents remains unverified.
- Carousel appearance, swipe gestures, and panel positioning must be checked on the target Android 10 device after installing a successful build.


## Revisi carousel dan Clear All
- Mengembalikan susunan carousel ke algoritme stack awal yang lebih rapat: kartu aktif di depan, dua kartu berikutnya bertumpuk di belakang.
- Menghapus kompresi simetris dan lift vertikal ekstrem yang menyebabkan kartu tampak berjauhan/berantakan.
- ClearAllButton tetap menjadi child native PagedView; posisi visualnya dikembalikan ke kanan atas tanpa mengganti listener klik native.
- Model indeks PagedView dari perbaikan sebelumnya tetap dipertahankan (tidak ada filter/count override).
- Swipe-up dilaporkan pengguna sudah terselesaikan; tetap tidak mengubah mekanisme gesture native.
- Memperbaiki pencarian ClearAllButton sebagai child langsung RecentsView sebelum reposisi; listener klik native tidak disentuh.


## All task cards in the two-sided carousel
- Removed the hard-coded visibility window that limited the stack to the selected task plus two following tasks.
- Every visible TaskView supplied by Android Recents remains eligible for display.
- Cards are compressed toward the active viewport center on both sides, so previous and next tasks can peek into view while swiping in either direction.
- Distant cards progressively scale down and dim; task data, PagedView page model, and native swipe/dismiss handling are unchanged.


## Tema Simp -> Shady
- Tahap 1: ikon homescreen/hotseat dan drawer memakai kartu kaca (patch_theme.py; diverifikasi di perangkat).
- Tahap 2 (nomor 1): drawer 3 kolom dengan kartu lebar (ikon kiri, label kanan). tools/patch_drawer.py mengganti
  numAllAppsColumns/numColumns, allAppsCellHeightPx, allAppsIconSizePx, allAppsIconDrawablePaddingPx di smali drawer
  dengan simp.drawer.DrawerGrid; all_apps_icon.xml diberi layoutHorizontal. Nilai disetel di DrawerGrid.java.
- Belum diverifikasi: build penuh dan tampilan di perangkat. Sheet drawer 78% dan baris Recents/Pinned belum dikerjakan.
- Tahap 2 (nomor 2): drawer berbentuk sheet. all_apps.xml diberi latar drawer_sheet_bg (sudut atas 28dp); patch_drawer.py
  menyisipkan DrawerGrid.applyGap(this) di AllAppsContainerView.setInsets/reset sehingga container diberi margin atas
  (100 - persen) tinggi layar. Persen default 75, disetel lewat slider "Tinggi app drawer" di aplikasi "Recents blur".
- Belum diverifikasi: build penuh dan perilaku sheet di perangkat (margin pada container yang ditranslasi oleh
  AllAppsTransitionController, gestur tutup, dan tampilan area dim di atas sheet).
- Scrim drawer: patch lunak allAppsScrimColor -> #66F4F6F9 (hanya bila atribut ada). Diagnostik ditambah: smali shady/qsb, ScrimView,
  LauncherState, uioverrides/states, dan res-search-scrim.txt untuk analisis search bar dan blur latar.


## Search bar di header app drawer
- Tahap 2 (nomor 3): header drawer memakai search bar bawaan Launcher3 (AppsSearchContainerLayout + DefaultAppSearchAlgorithm)
  menggantikan QSB Google yang tidak memfilter. Ketik di pil -> grid hanya menampilkan aplikasi yang cocok; hapus teks -> daftar penuh.
- tools/patch_search.py: all_apps.xml include QSB diganti AppsSearchContainerLayout (id tetap search_container_all_apps);
  onMeasure diganti agar lebar mengikuti grid kartu (DrawerGrid.searchInsetPx, 13dp); latar pil patch/drawer_search_bg.xml.
- Belum diverifikasi: build penuh dan tampilan di perangkat. Periksa diagnostics/patch_search.log: daftar referensi
  AllAppsQsbContainer di luar shady/qsb (bila ada yang meng-cast view drawer ke kelas itu, perlu penyesuaian).
- Posisi vertikal grid bisa bergeser beberapa dp karena tinggi header berubah dari QSB ke pil 48dp.


## Homescreen gaya SimpLauncher
- Tahap 2 (nomor 4): ikon homescreen + hotseat menjadi kartu kaca berisi nama aplikasi saja (tanpa ikon), label di tengah,
  semibold 13,5sp, putih; kartu setinggi 52dp di tengah sel, jarak 10dp, radius 16dp, garis tepi tipis, lapisan terang saat ditekan.
  Mengikuti HomeCard/HomeGrid di SimpLauncher (Ui.kt), memakai gaya kartu gelap yang sama dengan drawer.
- Kode: simp/home/HomeCards.java (konstanta + dekorasi) dan HomeCardDrawable.java (gambar kartu). tools/patch_home.py hanya
  menyisipkan dua panggilan di smali BubbleTextView (akhir konstruktor + awal applyCompoundDrawables) dan hanya berlaku untuk
  iconDisplay == 0 (homescreen/hotseat); drawer dan folder tidak berubah. HomeCards.SHOW_ICON = true mengembalikan ikon.
- Belum dikerjakan (butuh smali DeviceProfile): grid 3 kolom x 4 baris rata bawah, tanggal/widget di atas, kartu lebar (span).
  Build ini sudah menyimpan bahan analisisnya di diagnostics/ (device_profiles.orig.xml, home-dimens.orig.txt, smali-recents.zip
  berisi DeviceProfile, InvariantDeviceProfile, Workspace, CellLayout, Hotseat, ShadyLauncher).
- Belum diverifikasi: build penuh dan tampilan di perangkat. Folder di homescreen tidak ikut berubah (memakai FolderIcon, bukan BubbleTextView).


## Homescreen logika SimpLauncher, dock dihapus (tahap 3)
- Grid homescreen 3 kolom x 4 baris (device_profiles.xml), kartu kaca teks-saja setinggi 52dp + jarak 10dp.
- Grid menempel di bawah dengan margin bawah 36dp; ruang di atasnya untuk widget/tanggal (sama seperti HomeScreen/HomeGrid SimpLauncher).
  Dihitung di simp.home.HomeLayout, dipanggil dari akhir DeviceProfile.updateWorkspacePadding (tools/patch_home_grid.py).
- Dock (Hotseat) dihapus: Hotseat.setVisibility di-override menjadi selalu GONE. Item hotseat lama tetap ada di database, tidak ditampilkan.
- Belum: lebar kartu 1-3 kolom (span). Launcher3 hanya mengenal shortcut 1x1.
- Penyetelan: HomeCards (tinggi, jarak, radius, warna), HomeLayout.BOTTOM_MARGIN_DP, COLS/ROWS di patch_home_grid.py.
- Belum dibuild/diuji di perangkat dari lingkungan ini; patch diuji terhadap smali hasil diagnostik (idempoten).

## Diagnostik untuk tahap 4 (lebar kartu 1-3 kolom)
- smali-recents.zip kini juga memuat: ItemInfo*, LauncherSettings*, Launcher, Launcher$*, LauncherModel*, model/* (LoaderCursor, LoaderTask, GridSizeMigrationTask, ModelWriter), popup/*, shortcuts/*, util/GridOccupancy*, ItemLongClickListener, AppWidgetResizeFrame, LauncherAppWidget*.
- Hanya diagnostik; tidak mengubah APK.

## Perbaikan tahap 3 (setelah uji di perangkat)
- Panah swipe-up (drag handle all-apps) tidak digambar lagi: ScrimView.drawDragHandle langsung return. Gesture swipe-up tetap berfungsi.
- Grid yang lebih tinggi dari layar tidak lagi membatalkan perhitungan: area grid mentok di atas dan sel dimampatkan,
  sehingga widget bisa ditaruh sampai paling atas bila jumlah baris dinaikkan dari pengaturan grid di aplikasi.
- Kolom/baris di device_profiles.xml (3x4) hanya nilai bawaan; pengaturan grid di aplikasi tetap menang.

## Diagnostik untuk ruang kosong di Recents
- smali-recents.zip juga memuat quickstep/util/LayoutUtils*, *ActivityControllerHelper*, *ActivityInterface*, dan Utilities.
- Tujuan: LayoutUtils.calculateLauncherTaskSize menyisakan ruang setinggi swipe-height + drag handle + hotseat di bawah kartu Recents.
  Patch untuk menghilangkannya ditulis setelah smali itu terlihat (belum ada).


## Perbaikan 17 Nov 2026: workspace sampai atas + ruang dock di Recents hilang
Penyebab (dari screenshot + kode):
- Homescreen: HomeLayout mengisi padding atas workspace dengan "sisa layar" (rows x sel dihitung dari pengaturan grid, mis. 7 baris),
  jadi area workspace baru mulai di sekitar tengah layar. Widget hanya bisa ditaruh di dalam area itu -> "mentok".
  Baris di atasnya memang tidak ada di grid.
- Recents: LayoutUtils.calculateLauncherTaskSize masih menyisihkan swipe-height + drag handle + hotseat extra + hotseat bottom padding
  di bawah kartu, walau dock sudah GONE -> ruang kosong ~1/4 layar di bawah kartu.
Perubahan:
- HomeLayout.adjust: padding atas = 0 (workspace mulai tepat di bawah status bar), margin bawah tetap 36dp.
- HomeLayout.fitRows (baru) dipasang di InvariantDeviceProfile.initGridOption (patch_home_grid.py langkah 5): jumlah baris dihitung
  agar memenuhi tinggi layar (tinggi sel = kartu 52dp + jarak 10dp). Pengaturan "baris" di app tidak dipakai lagi.
  device_profiles.xml bawaan 3x12.
- tools/patch_dock_space.py (baru, dipanggil build.sh): LayoutUtils.calculateLauncherTaskSize -> ruang cadangan bawah selalu 0.
  Kartu Recents kini dihitung terhadap seluruh tinggi layar (lebih besar & di tengah).
Catatan:
- Item homescreen lama tersimpan di baris 0..N (dari atas), jadi setelah baris bertambah kartu/widget lama muncul di bagian atas;
  geser ke bawah sekali secara manual.
- Belum dibuild/diuji di perangkat dari lingkungan ini; kedua patch diuji terhadap smali diagnostik (jalan dan idempoten).

## Perbaikan 17 Nov 2026 (2): sisa dock di homescreen
- Garis kecil di bawah homescreen = WorkspacePageIndicator (indikator halaman, tingginya vertical_drag_handle_size, diposisikan di bekas area dock).
  tools/patch_hide_indicator.py: launcher.xml visibility=gone + smali onDraw return (lapis kedua bila method cocok). Dipanggil build.sh.
- HomeLayout.BOTTOM_MARGIN_DP 36 -> 10: grid menempel lebih ke bawah. Ubah konstanta ini untuk menyetel jarak.

## Perbaikan 17 Nov 2026 (3): kotak dock saat start + force close di baris bawah
- 5 kotak kosong di bawah saat aplikasi pertama dibuka = Hotseat masih VISIBLE sampai ada yang memanggil setVisibility (override GONE
  belum terpicu). tools/patch_hotseat_off.py: hotseat.xml root visibility=gone.
- Force close saat ikon dijatuhkan di baris paling bawah: Hotseat GONE masih menyimpan batas layout lama (area bawah layar), jadi
  Workspace.isPointInSelfOverHotseat menganggap drop itu jatuh di hotseat -> memakai CellLayout hotseat tanpa ukuran sel -> crash.
  Patch: isPointInSelfOverHotseat selalu false.
- Belum diuji di perangkat. Bila masih crash, kirim logcat/crash trace (nama method di baris "at com.android.launcher3...").


## Ubah ukuran kartu homescreen (17 Nov 2026)
- Tekan lama kartu di homescreen -> item menu "Ubah ukuran" -> pilih Lebar (1..jumlah kolom) x Tinggi (1..2).
- simp/home/HomeResize.java: dialog pilihan ukuran + terapkan lewat CellLayout.createAreaForResize(commit=true)
  (kartu lain yang menghalangi ikut digeser dan disimpan) lalu ModelWriter.modifyItemInDatabase untuk kartu itu.
  Bila tidak muat, ukuran ditolak dengan Toast. Kartu yang melewati batas kanan/bawah digeser ke kiri/atas.
- tools/patch_home_resize.py (dipanggil build.sh setelah patch_home_grid.py):
  1. kelas smali baru SystemShortcut$ShadyResize, ditambahkan ke daftar system shortcut lewat hook di
     PopupContainerWithArrow.populateAndShow (HomeResize.addTo). Item hanya muncul untuk app/shortcut di homescreen
     (bukan di app drawer). Catatan: factory yang dipakai APK ini adalah customization.ShadeShortcutFactory (resource
     system_shortcut_factory_class), bukan SystemShortcutFactory bawaan, jadi percobaan pertama (menambah elemen di
     SystemShortcutFactory) tidak berpengaruh dan sudah dihapus.
  2. LoaderCursor.applyCommonProperties membaca spanX/spanY dari database. Bawaan Launcher3 hanya membaca span untuk
     widget, jadi tanpa patch ini ukuran kembali ke 1x1 setelah launcher dimuat ulang.
- HomeCardDrawable: kartu dengan tinggi > 1 baris memenuhi seluruh tinggi sel (kartu 1 baris tetap 52dp di tengah).
- patch_home_resize.py sudah diuji terhadap smali-recents.zip: berhasil dan idempoten.
- Belum diverifikasi: kompilasi Java (tanpa android.jar di sini), serta perilaku di perangkat: dialog, penggeseran kartu
  lain, drag kartu yang sudah besar, dan ukuran bertahan setelah restart. Refleksi memakai nama dari smali Launcher3 Android 10.


## Lebar kartu app drawer + label homescreen rata kiri (17 Nov 2026)
- Label kartu homescreen sekarang rata kiri (HomeCards.decorate: gravity CENTER_VERTICAL|START).
- App drawer: tekan lama app -> "Ubah ukuran" -> Lebar 1..3 kolom (hanya lebar, per aplikasi). simp/drawer/DrawerResize.java
  menyimpan ke SharedPreferences "shady_drawer_spans" (kunci = komponen|user); patch_home_resize.py langkah 3 membuat
  AllAppsGridAdapter$GridSpanSizer.getSpanSize memakai DrawerResize.spanFor untuk item ikon. Header/pembatas tetap penuh.
- Perubahan lebar memanggil invalidateSpanIndexCache + notifyDataSetChanged pada RecyclerView drawer yang aktif.
- Diketahui/belum diverifikasi: posisi fast scroller dan sisipan huruf bisa bergeser sedikit (perhitungan baris di
  AlphabeticalAppsList mengasumsikan tiap app 1 kolom); kartu lebar di kolom terakhir pindah baris (ada celah).
  Kompilasi Java dan perilaku di perangkat belum diuji.


## Padding label, font per kartu, kartu drawer 1,5x (17 Nov 2026)
- Padding label homescreen: akar masalahnya `ShortcutAndWidgetContainer.measureChild` yang menimpa padding kiri/kanan ikon
  dengan `workspaceCellPaddingXPx` (~8dp) di setiap measure, sehingga padding dari `HomeCards.decorate` tidak pernah berlaku
  (teks hanya ~3dp dari tepi kartu). Sekarang `HomeCards.cellPadX` mengganti nilai itu untuk view berlatar kartu
  (tools/patch_home.py, langkah 4). Jarak teks ke tepi kartu = `HomeCards.PAD_X_DP` (14dp); ubah konstanta itu bila kurang/lebih.
- Ukuran font per kartu (homescreen dan drawer): tekan lama kartu -> "Ubah kartu" -> "Ukuran font" (slider 8-24sp, tombol
  Simpan / Bawaan). Homescreen disimpan per item (id database), drawer per aplikasi (komponen + user), di SharedPreferences
  `shady_card_font`. Logika di simp/home/CardFont.java; hook `applyIconAndLabel` di BubbleTextView (patch_home.py, langkah 3)
  memasang ukuran tiap kartu di-bind dan mengembalikan ke ukuran bawaan bila tidak ada pengaturan (view drawer didaur ulang).
- Menu tekan-lama "Ubah ukuran" menjadi "Ubah kartu": dialog kecil berisi "Ukuran kartu"/"Lebar kartu" dan "Ukuran font".
- Drawer: pilihan lebar kartu 1 / 1,5 / 2 / 3 kolom. GridLayoutManager sekarang memakai 6 satuan span per baris
  (`DrawerGrid.COLUMNS = 6`, 1 kolom = 2 satuan, 1,5 kolom = 3 satuan). Lebar tersimpan dalam satuan span di prefs
  `shady_drawer_spans2`; pengaturan lama (`shady_drawer_spans`, satuan kolom) dimigrasi otomatis (x2) saat pertama dibaca.
  Hitungan baris scrollbar tetap 3 kolom nominal (`DrawerGrid.nominalColumns()`).
- Belum diverifikasi: kompilasi Java (tanpa android.jar di sini; dikompilasi build.sh/GitHub Actions) dan tampilan di perangkat.
  patch_home.py, patch_home_resize.py, dan patch_drawer.py sudah diuji terhadap smali-recents.zip: berhasil dan idempoten.


## Kartu cerah, teks hitam (17 Nov 2026)
- Homescreen dan drawer: kartu putih translusen (~70%), garis tepi putih, teks hitam, ripple gelap tipis.
  Warna homescreen di HomeCards (FILL_COLOR, STROKE_COLOR, PRESS_COLOR, LABEL_COLOR) dan patch/home_card_bg.xml;
  drawer di patch/drawer_card_bg.xml + android:textColor di all_apps_icon.xml (tools/patch_theme.py).
- Ini translusen biasa, bukan blur latar sungguhan (Android 10 tidak punya blur belakang-view per kartu).


## Blur palsu kartu homescreen + frosted drawer (17 Nov 2026)
- Homescreen: simp/home/CardBlur.java mem-blur wallpaper sekali (bitmap layar 160px lebar, radius 8, memakai BoxBlur) dan
  dibangun ulang saat wallpaper berganti. HomeCardDrawable menggambar potongan bitmap itu di posisi kartu (BitmapShader +
  getLocationOnScreen) lalu lapisan putih HomeCards.TINT_COLOR (55%). Bila blur gagal, jatuh ke FILL_COLOR datar.
  Batas: hanya wallpaper yang ter-blur; saat geser antar halaman blur ikut bergerak bersama kartu (bukan tetap di layar).
- Drawer: drawer_card_bg.xml gradien putih -> abu kebiruan muda + garis tepi tipis, supaya kartu terlihat di atas sheet putih keruh.
- Belum dikompilasi dan belum diuji di perangkat.


## Perbaikan kartu cerah (17 Nov 2026, sore)
- Blur homescreen tidak tampil: wallpaper tidak terbaca (Android 10 butuh izin READ_EXTERNAL_STORAGE yang sudah dideklarasikan
  tetapi belum diberikan), sehingga kartu memakai warna cadangan seragam. CardBlur kini mengembalikan null bila wallpaper
  tidak terbaca (kartu jatuh ke putih translusen datar) dan mencoba lagi tiap 3 detik. Layar pengaturan "Recents blur"
  mendapat tombol "Beri izin" (requestPermissions) + status; BlurScrimDrawable juga mencoba lagi setelah izin diberikan.
- Teks homescreen polos tanpa bayangan: patch_home.py langkah 5 (DoubleShadowBubbleTextView.onDraw -> BubbleTextView.onDraw
  + clearShadowLayer lewat HomeCards.plainText) untuk kartu berlatar HomeCardDrawable.
- Drawer: label/ikon naik karena BubbleTextView.onMeasure menghitung padding atas negatif untuk susunan horizontal;
  DrawerGrid.fixTopPad memotongnya ke 0 (patch_drawer.py). Kartu drawer kini datar translusen (tanpa gradien/garis).
- Tint blur homescreen diturunkan ke 40% (HomeCards.TINT_COLOR) agar blur terlihat.
- Drawer, tahap 2: ikon dan label masih ~3,5px di atas tengah kartu (diukur dari screenshot; ikon dan teks sama-sama naik) karena
  padding bawah bawaan ~3dp. patch_drawer.py kini juga menolkan padding bawah di BubbleTextView.onMeasure.


## Font umum kartu (17 Nov 2026)
- Aplikasi "Recents blur" mendapat dua slider: font kartu homescreen dan font kartu drawer (8-24sp; kiri penuh = bawaan).
  Disimpan di RecentsPrefs (font_home, font_drawer). Prioritas: font manual per kartu (CardFont, tekan lama -> Ubah kartu ->
  Ukuran font) > font umum > bawaan. Tombol dialog "Bawaan" diganti "Ikut umum" (menghapus pengaturan manual kartu itu).
- Perubahan slider langsung diterapkan ke kartu yang sedang ada (CardFont.refreshAll lewat tag view; pengaturan satu proses
  dengan launcher). Belum dikompilasi dan belum diuji di perangkat.
