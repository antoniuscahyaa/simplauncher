# RecentsMod — In-card collapsible actions

## UI changes
- Kept the existing overlapping Recents carousel controller and native TaskView/PagedView ownership.
- Removed the always-visible action rows from the default card state.
- Added a small centered chevron pill inside the bottom area of each task card.
- Tapping the chevron reveals the existing Split Screen, App Info, and Force Stop controls inside a translucent rounded panel at the bottom of that same card.
- Tapping the chevron again collapses the panel; changing the bound task rebuilds the action footer in its collapsed state.
- Reduced the thumbnail's bottom reservation to make room for the embedded chevron. The expanded action panel overlays the lower part of the preview rather than changing carousel page geometry.
- Added short alpha/vertical transitions for opening and closing the action panel.

## PagedView index repair retained
The supplied crash trace showed `PagedView.getPageScrolls()` indexing page 8 in an array of length 8 during `RecentsView.createTaskDismissAnimation()`. The prior custom page-count/filter/max-scroll changes remain removed so native Launcher page indexing stays consistent.

## Known limitations
- Full Android build and on-device interaction have not been run in this environment.
- Force Stop still stops the package only when the privileged permission is actually granted; removing its card from Recents remains unverified.
- Carousel appearance, swipe gestures, and panel positioning must be checked on the target Android 10 device after installing a successful build.


## Revisi carousel dan Clear All
- Mengembalikan susunan carousel ke algoritme stack awal yang lebih rapat: kartu aktif di depan, dua kartu berikutnya bertumpuk di belakang.
- Menghapus kompresi simetris dan lift vertikal ekstrem yang menyebabkan kartu tampak berjauhan/berantakan.
- ClearAllButton tetap menjadi child native PagedView; posisi visualnya dikembalikan ke kanan atas tanpa mengganti listener klik native.
- Model indeks PagedView dari perbaikan sebelumnya tetap dipertahankan (tidak ada filter/count override).
- Swipe-up dilaporkan pengguna sudah terselesaikan; tetap tidak mengubah mekanisme gesture native.
- Memperbaiki pencarian ClearAllButton sebagai child langsung RecentsView sebelum reposisi; listener klik native tidak disentuh.


## All task cards in the two-sided carousel
- Removed the hard-coded visibility window that limited the stack to the selected task plus two following tasks.
- Every visible TaskView supplied by Android Recents remains eligible for display.
- Cards are compressed toward the active viewport center on both sides, so previous and next tasks can peek into view while swiping in either direction.
- Distant cards progressively scale down and dim; task data, PagedView page model, and native swipe/dismiss handling are unchanged.


## Tema Simp -> Shady
- Tahap 1: ikon homescreen/hotseat dan drawer memakai kartu kaca (patch_theme.py; diverifikasi di perangkat).
- Tahap 2 (nomor 1): drawer 3 kolom dengan kartu lebar (ikon kiri, label kanan). tools/patch_drawer.py mengganti
  numAllAppsColumns/numColumns, allAppsCellHeightPx, allAppsIconSizePx, allAppsIconDrawablePaddingPx di smali drawer
  dengan simp.drawer.DrawerGrid; all_apps_icon.xml diberi layoutHorizontal. Nilai disetel di DrawerGrid.java.
- Belum diverifikasi: build penuh dan tampilan di perangkat. Sheet drawer 78% dan baris Recents/Pinned belum dikerjakan.
- Tahap 2 (nomor 2): drawer berbentuk sheet. all_apps.xml diberi latar drawer_sheet_bg (sudut atas 28dp); patch_drawer.py
  menyisipkan DrawerGrid.applyGap(this) di AllAppsContainerView.setInsets/reset sehingga container diberi margin atas
  (100 - persen) tinggi layar. Persen default 75, disetel lewat slider "Tinggi app drawer" di aplikasi "Recents blur".
- Belum diverifikasi: build penuh dan perilaku sheet di perangkat (margin pada container yang ditranslasi oleh
  AllAppsTransitionController, gestur tutup, dan tampilan area dim di atas sheet).
