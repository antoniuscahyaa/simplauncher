# RecentsMod — perubahan yang diterapkan

## Tampilan kartu Recents
- Action bar sekarang memiliki dua tombol sejajar dengan lebar seimbang: **Split Screen** dan **App Info**.
- Tombol **Force Stop** berada di baris berikutnya dan memenuhi lebar action bar.
- Tombol Kill lama tidak ditampilkan lagi.
- Thumbnail menyisakan ruang yang cukup untuk label aplikasi dan dua baris tombol.
- Kartu memakai latar kaca/translusen yang sudah menjadi dasar desain sebelumnya.

## Force Stop sebenarnya
- Menambahkan deklarasi `android.permission.FORCE_STOP_PACKAGES`.
- Sebelum aksi dijalankan, aplikasi memeriksa apakah permission sistem tersebut benar-benar diberikan.
- Aksi memanggil Binder `forceStopPackage(packageName, taskUserId)` (dengan wrapper current-user sebagai fallback yang dibatasi), bukan sekadar menutup kartu atau memanggil `killProcess()`.
- Kartu Recents baru di-dismiss setelah pemanggilan Force Stop berhasil. Jika izin/API ditolak, pengguna menerima pesan gagal dan kartu tidak dihapus.
- Permission bertipe signature/privileged pada Android. APK harus tetap dipasang sebagai build sistem dengan sertifikat yang sesuai; deklarasi manifest saja tidak menjamin izin diberikan.

## Carousel kartu bertumpuk
- Satu kartu aktif di depan, dua kartu berikutnya tampak di belakangnya.
- Skala kartu belakang: 88% dan 78%; opasitas konten kartu belakang sedikit diturunkan.
- Kartu di luar tiga posisi tersebut disembunyikan secara visual, tetapi tetap menjadi halaman PagedView sehingga semua task masih dapat dicapai dengan swipe.
- Transform mengikuti scroll dan arah RTL/LTR tanpa mengganti mekanisme gesture, snapping, atau lifecycle TaskView bawaan Launcher.

## Clear All
- Clear All dikeluarkan dari daftar halaman scroll dan diposisikan sebagai overlay tetap di kanan atas, di luar kartu.
- Posisi overlay dikompensasi terhadap `scrollX`, sehingga tombol tetap di tempat ketika carousel digeser.
- Click listener dan aksi Clear All bawaan `RecentsView` dipertahankan.
- Tampilan tombol memakai drawable kaca/translusen.

## Blur dan scrim
- Blur wallpaper dan scrim hitam transparan adalah dua nilai terpisah.
- Scrim memakai slider 0–100%: 0 tanpa gelap tambahan, 25% nilai default, 50% sedang, dan 100% hitam penuh.
- Preview scrim diperbarui langsung saat slider digeser; nilai tersimpan otomatis saat selesai mengubah atau saat layar pengaturan ditinggalkan.
- `getOpacity()` pada drawable tetap `OPAQUE` dengan sengaja karena drawable menggambar bitmap wallpaper/fallback yang mengisi seluruh area; lapisan scrim hitam di atasnya tetap menggunakan alpha/transparansi.

## Build dan verifikasi
- `build.sh` kini mendekode smali pada build utama agar patch `PagedView` dan `RecentsView` ikut diterapkan.
- Patch smali berhenti dengan error jika kelas atau method target tidak ditemukan, untuk menghindari APK setengah terpatch.
- Uji patch sumber pada salinan smali diagnostik: semua target patch berhasil ditemukan dan ditulis.
- Build APK penuh dan pengujian runtime belum dilakukan di lingkungan penyusunan ini karena Android SDK/build-tools tidak tersedia dan akses unduhan eksternal gagal. Jalankan `build.sh` pada runner GitHub Actions/lingkungan Android SDK yang sesuai sebelum memasang ZIP flashable.
- Build script mempertahankan pemeriksaan fingerprint sertifikat terhadap APK sumber; proses berhenti jika sertifikat platform hasil unduh tidak cocok.
