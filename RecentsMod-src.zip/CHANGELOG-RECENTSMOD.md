# RecentsMod — follow-up carousel and Clear All fixes

## Included
- Smooth, fractional interpolation of rear-card scale and dimming instead of snapping at rounded page offsets.
- Each rear card is lifted by approximately 86dp per stack position. This corresponds to the two-row action bar (Split Screen/App Info plus Force Stop) and is intended to expose the rear card's controls up to the upper edge of the card in front.
- Launcher-owned translationX/translationY is preserved by subtracting the last carousel offset before applying the next offset. This is important during native swipe-up task dismissal animations.
- Carousel update is guarded so a presentation-only exception does not propagate into the Launcher/Recents gesture path.
- Clear All is now explicitly found as the `ClearAllButton` child. The previous controller passed the RecentsView itself into `positionClearAll(View)`, so its parent check could never position the actual button. The button is now translated to the top-right viewport position without calling `View.layout()` during RecentsView layout.
- Clear All is hidden when there are no task cards and shown when tasks exist.

## Existing behavior retained
- Native TaskView/PagedView continue to own task data, horizontal paging, touch handling, and task lifecycle.
- Action bar retains App Info, Split Screen, and full-width Force Stop.
- Rear-card scale remains 88% and 78%, with opacity dimming.

## Important: swipe-up force-close report
The code now preserves Launcher-controlled Y translation during swipe-up dismissal and catches presentation-only failures, reducing the chance that carousel transforms interfere with the native gesture. However, the exact force-close root cause cannot be proven from screenshots alone. A logcat crash trace from the moment ShadyLauncher closes is still required to confirm whether the remaining cause is a Launcher exception, a task-dismiss lifecycle issue, or an unrelated system crash.

## Verification
- `RecentsStackCarousel.java` compiled with minimal Android API stubs: passed.
- `tools/patch.py` and `tools/inject_dex.py` Python syntax: passed.
- `build.sh` shell syntax: passed.
- ZIP integrity: to be checked after packaging.
- Full Android APK build and device test: not performed here because no Android SDK platform/build-tools are installed in this environment.
