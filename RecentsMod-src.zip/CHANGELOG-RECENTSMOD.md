# RecentsMod best-effort layout revision

## Changes
- Carousel positioning now treats pages symmetrically around the active card, so adjacent tasks can remain visible on both the left and right sides.
- Removed TaskView visibility toggling from the carousel controller. Launcher remains responsible for attaching, hiding, and dismissing tasks; this avoids the controller hiding pages or changing visibility during swipe-dismiss.
- Kept the previously agreed rear-card scale and vertical lift progression, applied by distance from the active card.

## Important limitations
- This is a source-level best-effort revision. It has not been built into an APK or tested on the device.
- The Force Stop API still stops the package, but successful removal of its task card has not been verified against this Launcher's exact RecentsView implementation.
- Clear All positioning remains unverified because the supplied screenshots show it absent and the APK's runtime view hierarchy is not available here.
- Swipe-up stability cannot be certified without a device test. The revised controller avoids changing TaskView visibility, but this does not prove every Launcher gesture conflict is resolved.
