#!/usr/bin/env python3
"""Terapkan layout menu recent (opsi D-lite) ke hasil `apktool d` ShadyQuickStep.
Pemakaian: python3 patch_menu_d.py <folder_hasil_apktool> [folder_diagnostics]
Jalankan SEBELUM `apktool b`, sesudah patch task.xml yang sudah ada."""
import sys, shutil, pathlib
here = pathlib.Path(__file__).resolve().parent
dec = pathlib.Path(sys.argv[1]); diag = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
res = dec / "res"
if not res.is_dir(): sys.exit(f"res/ tidak ada di {dec}")
if diag: diag.mkdir(parents=True, exist_ok=True)
n = 0
for name in ("task_menu.xml", "task_view_menu_option.xml"):
    targets = [p for p in res.glob(f"layout*/{name}")]
    if not targets: sys.exit(f"{name} tidak ditemukan di {res}")
    for t in targets:
        if diag: shutil.copy(t, diag / f"{t.parent.name}_{name}.orig")
        shutil.copy(here / "res/layout" / name, t); n += 1
        print(f"{name} dipatch -> {t.relative_to(dec)}")
(res / "drawable").mkdir(exist_ok=True)
shutil.copy(here / "res/drawable/menu_tile_bg.xml", res / "drawable/menu_tile_bg.xml")
print(f"menu_tile_bg.xml ditambahkan; {n} layout dipatch\npatch menu selesai")
