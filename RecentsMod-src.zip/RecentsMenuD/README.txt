RecentsMenuD - menu recent: tiga tile sejajar (App info / Split / Kill)
BELUM DIUJI di perangkat. Simpan RecentsMod-restore.zip sebagai cadangan.

Pasang di pipeline RecentsMod, setelah patch task.xml & clear_all lama:
  python3 patch_menu_d.py work/decoded dist/diagnostics
lalu lanjut apktool b, inject dex, zipalign, sign seperti biasa.

Isi: res/layout/task_menu.xml, res/layout/task_view_menu_option.xml,
     res/drawable/menu_tile_bg.xml
Belum termasuk: tombol Kill lebar & merah (perlu hook smali di TaskMenuView.addMenuOption).
