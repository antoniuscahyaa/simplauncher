#!/usr/bin/env python3
"""Patch smali: grid homescreen beresolusi 2x, sehingga ukuran kartu bisa kelipatan 0,5.

Pemakaian: patch_half_grid.py <folder_decoded>
Satu "kartu penuh" = HomeCards.SCALE x HomeCards.SCALE sel (3 kartu penuh = 6 kolom). Perubahan (gagal keras
bila pola tidak cocok; idempoten):
  1. InvariantDeviceProfile.initGridOption: numColumns = HomeLayout.fitColumns (3 x SCALE), preferensi lama diabaikan.
     (jumlah baris sudah ditangani patch_home_grid.py -> HomeLayout.fitRows, juga x SCALE)
  2. ItemInfo.<init>(): spanX/spanY bawaan = SCALE (item baru dari drawer = kartu penuh, bukan setengah).
  3. GridSizeMigrationTask.migrateGridIfNeeded: GridScale.run(...) di awal -> posisi/ukuran item lama dikali SCALE
     satu kali sebelum migrasi grid bawaan Launcher3.
  4. FolderPagedView: layout params item folder memakai span 1 (grid folder tidak memakai satuan baru).
Lebar/tinggi kartu per item diatur HomeResize (menu tekan-lama "Ubah kartu").
"""
import glob
import os
import re
import sys

work = sys.argv[1]
SCALE = 2


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_smali(class_path):
    hits = [os.path.join(d, class_path + ".smali") for d in glob.glob(os.path.join(work, "smali*"))
            if os.path.isfile(os.path.join(d, class_path + ".smali"))]
    if len(hits) != 1:
        die("smali %s ditemukan %d kali" % (class_path, len(hits)))
    return hits[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1. kolom ----
idp = find_smali("com/android/launcher3/InvariantDeviceProfile")
src = read(idp)
if "HomeLayout;->fitColumns" in src:
    print("sudah dipatch: InvariantDeviceProfile kolom")
else:
    old = ("    invoke-static {p1, v0}, Lcom/android/launcher3/Utilities;->getGridColumns(Landroid/content/Context;I)I\n\n"
           "    move-result v0\n")
    if src.count(old) != 1:
        die("IDP: getGridColumns muncul %d kali (butuh 1)" % src.count(old))
    new = old + ("\n    invoke-static {p1, v0}, Lsimp/home/HomeLayout;->fitColumns(Landroid/content/Context;I)I\n\n"
                 "    move-result v0\n")
    write(idp, src.replace(old, new))
    print("dipatch: InvariantDeviceProfile.initGridOption -> numColumns = fitColumns")

# ---- 2. ItemInfo default span ----
ii = find_smali("com/android/launcher3/ItemInfo")
src = read(ii)
if "# simp: span bawaan = SCALE" in src:
    print("sudah dipatch: ItemInfo span bawaan")
else:
    m = re.search(r"(?ms)^\.method public constructor <init>\(\)V\n.*?^\.end method", src)
    if not m:
        die("ItemInfo.<init>() tidak ditemukan")
    body = m.group(0)
    pat = re.compile(r"(    const/4 v0, 0x1\s+(?:\.line \d+\s+)?    iput v0, p0, Lcom/android/launcher3/ItemInfo;->spanX:I\s+"
                     r"(?:\.line \d+\s+)?    iput v0, p0, Lcom/android/launcher3/ItemInfo;->spanY:I\n)")
    if len(pat.findall(body)) != 1:
        die("ItemInfo.<init>(): blok span tidak cocok (%d)" % len(pat.findall(body)))
    add = ("\n    # simp: span bawaan = SCALE (kartu penuh = SCALE x SCALE sel)\n"
           "    const/4 v0, 0x%d\n\n"
           "    iput v0, p0, Lcom/android/launcher3/ItemInfo;->spanX:I\n\n"
           "    iput v0, p0, Lcom/android/launcher3/ItemInfo;->spanY:I\n\n"
           "    const/4 v0, 0x1\n") % SCALE
    body2 = pat.sub(lambda mm: mm.group(1) + add, body, count=1)
    write(ii, src[:m.start()] + body2 + src[m.end():])
    print("dipatch: ItemInfo.<init>() span bawaan = %d" % SCALE)

# ---- 3. migrasi database ----
gm = find_smali("com/android/launcher3/model/GridSizeMigrationTask")
src = read(gm)
if "GridScale;->run" in src:
    print("sudah dipatch: GridSizeMigrationTask")
else:
    m = re.search(r"(?ms)^\.method public static migrateGridIfNeeded\(Landroid/content/Context;\)Z\n.*?^\.end method", src)
    if not m:
        die("migrateGridIfNeeded tidak ditemukan")
    body = m.group(0)
    pat = re.compile(r"(    invoke-static \{v0, v5\}, Lcom/android/launcher3/Utilities;->getPointString\(II\)Ljava/lang/String;\s+"
                     r"    move-result-object v5\n)")
    # versi asli: invoke-static {v0, v5} setelah iget v0/v5 -> v5 = string ukuran grid
    pat = re.compile(r"(    invoke-static \{v0, v5\}, Lcom/android/launcher3/Utilities;->getPointString\(II\)Ljava/lang/String;\s+"
                     r"(?:\.line \d+\s+)?    move-result-object v5\n)")
    if len(pat.findall(body)) != 1:
        die("migrateGridIfNeeded: pola getPointString tidak cocok (%d)" % len(pat.findall(body)))
    add = ("\n    # simp: kalikan posisi/ukuran item lama dengan SCALE sebelum migrasi bawaan\n"
           "    move-object/from16 v0, p0\n\n"
           "    invoke-static {v0, v3, v5}, Lsimp/home/GridScale;->run"
           "(Landroid/content/Context;Landroid/content/SharedPreferences;Ljava/lang/String;)V\n")
    body2 = pat.sub(lambda mm: mm.group(1) + add, body, count=1)
    write(gm, src[:m.start()] + body2 + src[m.end():])
    print("dipatch: GridSizeMigrationTask.migrateGridIfNeeded -> GridScale.run")

# ---- 4. FolderPagedView ----
fp = find_smali("com/android/launcher3/folder/FolderPagedView")
src = read(fp)
a = "    iget v4, p1, Lcom/android/launcher3/WorkspaceItemInfo;->spanX:I\n"
b = "    iget p1, p1, Lcom/android/launcher3/WorkspaceItemInfo;->spanY:I\n"
if "# simp: item folder span 1" in src:
    print("sudah dipatch: FolderPagedView")
else:
    if src.count(a) != 1 or src.count(b) != 1:
        die("FolderPagedView: pola span tidak cocok (%d, %d)" % (src.count(a), src.count(b)))
    src = src.replace(a, "    # simp: item folder span 1\n    const/4 v4, 0x1\n")
    src = src.replace(b, "    const/4 p1, 0x1\n")
    write(fp, src)
    print("dipatch: FolderPagedView span item folder = 1")
print("patch_half_grid selesai")
