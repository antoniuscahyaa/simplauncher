#!/usr/bin/env python3
"""Tahap 4 tema Simp -> Shady: ubah ukuran kartu homescreen (lebar 1..kolom, tinggi 1..2).

Pemakaian: patch_home_resize.py <folder_decoded>
Tiga perubahan smali (gagal keras bila pola tidak ditemukan tepat sekali; idempoten). Logika ada di
simp.home.HomeResize:
  1. Kelas baru popup/SystemShortcut$ShadyResize (item menu tekan-lama "Ubah ukuran"); ikon dan listener
     dari HomeResize.icon() / HomeResize.listener(). listener() mengembalikan null untuk item non-homescreen,
     sehingga item tidak tampil di app drawer.
  2. popup/PopupContainerWithArrow.populateAndShow(BubbleTextView, ItemInfo, SystemShortcutFactory): sebelum daftar
     system shortcut dirender, HomeResize.addTo() menambahkan ShadyResize. Factory sebenarnya bukan SystemShortcutFactory
     bawaan melainkan com.android.launcher3.customization.ShadeShortcutFactory (resource system_shortcut_factory_class),
     sehingga menambah elemen di SystemShortcutFactory tidak berpengaruh; hook di popup berlaku untuk factory apa pun.
  3. allapps/AllAppsGridAdapter$GridSpanSizer.getSpanSize: item ikon app drawer memakai lebar tersimpan dari
     simp.drawer.DrawerResize.spanFor (1..3 kolom, per aplikasi) alih-alih selalu 1.
  4. model/LoaderCursor.applyCommonProperties: baca kolom spanX/spanY dari database. Bawaan Launcher3 hanya
     membaca span untuk widget, jadi tanpa ini ukuran kartu kembali ke 1x1 setiap launcher dimuat ulang.
"""
import glob
import os
import re
import sys

work = sys.argv[1]

SHORTCUT_CLASS = r"""# Item menu tekan-lama "Ubah ukuran" untuk kartu homescreen (dibuat oleh tools/patch_home_resize.py).
.class public Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;
.super Lcom/android/launcher3/popup/SystemShortcut;
.source "SystemShortcut.java"


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-static {}, Lsimp/home/HomeResize;->icon()Landroid/graphics/drawable/Icon;

    move-result-object v0

    const-string v1, "Ubah ukuran"

    const-string v2, "Ubah ukuran kartu"

    const/4 v3, 0x0

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/android/launcher3/popup/SystemShortcut;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Ljava/lang/CharSequence;I)V

    return-void
.end method


# virtual methods
.method public getOnClickListener(Lcom/android/launcher3/BaseDraggingActivity;Lcom/android/launcher3/ItemInfo;)Landroid/view/View$OnClickListener;
    .locals 1

    invoke-static {p1, p2}, Lsimp/home/HomeResize;->listener(Ljava/lang/Object;Ljava/lang/Object;)Landroid/view/View$OnClickListener;

    move-result-object v0

    return-object v0
.end method
"""


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_one(rel):
    c = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, rel)] if os.path.isfile(p)]
    if len(c) != 1:
        die("%s ditemukan %d (butuh tepat 1)" % (rel, len(c)))
    return c[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1. kelas shortcut baru (di folder smali yang sama dengan SystemShortcut) ----
sc = find_one("com/android/launcher3/popup/SystemShortcut.smali")
new_cls = os.path.join(os.path.dirname(sc), "SystemShortcut$ShadyResize.smali")
write(new_cls, SHORTCUT_CLASS)
print("smali dibuat:", os.path.relpath(new_cls, work))

# ---- 2. PopupContainerWithArrow.populateAndShow ----
popup = find_one("com/android/launcher3/popup/PopupContainerWithArrow.smali")
src = read(popup)
if "Lsimp/home/HomeResize;->addTo" in src:
    print("PopupContainerWithArrow sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method protected populateAndShow\(Lcom/android/launcher3/BubbleTextView;Lcom/android/launcher3/ItemInfo;"
                  r"Lcom/android/launcher3/popup/SystemShortcutFactory;\)V\n.*?^\.end method", src)
    if not m:
        die("PopupContainerWithArrow.populateAndShow(BubbleTextView, ItemInfo, SystemShortcutFactory) tidak ditemukan")
    body = m.group(0)
    if not re.search(r"\.locals 3\n", body):
        die("populateAndShow: .locals bukan 3 (struktur beda dari yang diperkirakan)")
    if re.search(r"\bv3\b", body):
        die("populateAndShow sudah memakai v3")
    call = ("    invoke-virtual {p0, p1, v1, v0, p2}, Lcom/android/launcher3/popup/PopupContainerWithArrow;->populateAndShow("
            "Lcom/android/launcher3/BubbleTextView;ILjava/util/List;Ljava/util/List;)V")
    if body.count(call) != 1:
        die("pemanggilan populateAndShow 4-argumen tidak ditemukan tepat sekali")
    add = (
        "    new-instance v3, Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;\n\n"
        "    invoke-direct {v3}, Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;-><init>()V\n\n"
        "    invoke-static {p2, v3, v2, p1}, Lsimp/home/HomeResize;->addTo(Ljava/util/List;Ljava/lang/Object;Ljava/lang/Object;Landroid/view/View;)V\n\n"
    )
    body = body.replace(".locals 3\n", ".locals 4\n", 1).replace(call, add + call)
    write(popup, src[: m.start()] + body + src[m.end():])
    print("smali dipatch: PopupContainerWithArrow.populateAndShow -> +ShadyResize lewat HomeResize.addTo")

# ---- 3. GridSpanSizer.getSpanSize (app drawer) ----
sizer = find_one("com/android/launcher3/allapps/AllAppsGridAdapter$GridSpanSizer.smali")
src = read(sizer)
if "Lsimp/drawer/DrawerResize;" in src:
    print("GridSpanSizer sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method public getSpanSize\(I\)I\n.*?^\.end method", src)
    if not m:
        die("GridSpanSizer.getSpanSize tidak ditemukan")
    body = m.group(0)
    if not re.search(r"\.locals 1\n", body):
        die("getSpanSize: .locals bukan 1")
    cast = "    check-cast p1, Lcom/android/launcher3/allapps/AlphabeticalAppsList$AdapterItem;\n"
    if body.count(cast) != 1:
        die("check-cast AdapterItem tidak ditemukan tepat sekali")
    # cabang ikon: 'const/4 p1, 0x1' lalu 'return p1' (cabang pertama sebelum :cond_0)
    icon = re.search(r"(?m)^    const/4 p1, 0x1\n\n    return p1\n", body)
    if not icon or body.count("    const/4 p1, 0x1\n\n    return p1\n") != 1:
        die("cabang ikon (const/4 p1, 0x1; return p1) tidak ditemukan tepat sekali")
    # v0 (daftar) tidak dipakai lagi setelah get(); simpan AdapterItem di v0 untuk cabang ikon.
    body = body.replace(cast, cast + "\n    move-object v0, p1\n", 1)
    body = body.replace(
        icon.group(0),
        "    iget-object v0, v0, Lcom/android/launcher3/allapps/AlphabeticalAppsList$AdapterItem;->appInfo:Lcom/android/launcher3/AppInfo;\n\n"
        "    invoke-static {v0}, Lsimp/drawer/DrawerResize;->spanFor(Ljava/lang/Object;)I\n\n"
        "    move-result p1\n\n"
        "    return p1\n", 1)
    write(sizer, src[: m.start()] + body + src[m.end():])
    print("smali dipatch: GridSpanSizer.getSpanSize -> DrawerResize.spanFor")

# ---- 4. LoaderCursor.applyCommonProperties ----
lc = find_one("com/android/launcher3/model/LoaderCursor.smali")
src = read(lc)
if "Lsimp/home/HomeResize;" in src:
    print("LoaderCursor sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method public applyCommonProperties\(Lcom/android/launcher3/ItemInfo;\)V\n.*?^\.end method", src)
    if not m:
        die("LoaderCursor.applyCommonProperties tidak ditemukan")
    body = m.group(0)
    lm = re.search(r"\.locals (\d+)", body)
    if not lm or int(lm.group(1)) < 1:
        die("applyCommonProperties: .locals < 1")
    tail = "\n    return-void\n.end method"
    if not body.endswith(tail):
        die("applyCommonProperties tidak berakhir dengan return-void biasa")
    hook = ""
    for col in ("spanX", "spanY"):
        hook += (
            '\n    const-string v0, "%s"\n\n'
            "    invoke-static {p0, v0}, Lsimp/home/HomeResize;->span(Landroid/database/Cursor;Ljava/lang/String;)I\n\n"
            "    move-result v0\n\n"
            "    iput v0, p1, Lcom/android/launcher3/ItemInfo;->%s:I\n" % (col, col)
        )
    body = body[: -len(tail)] + "\n" + hook + tail
    write(lc, src[: m.start()] + body + src[m.end():])
    print("smali dipatch: LoaderCursor.applyCommonProperties -> baca spanX/spanY")

print("patch resize selesai")
