#!/usr/bin/env python3
"""Tahap 4 tema Simp -> Shady: ubah ukuran kartu homescreen (lebar 1..kolom, tinggi 1..2).

Pemakaian: patch_home_resize.py <folder_decoded>
Tiga perubahan smali (gagal keras bila pola tidak ditemukan tepat sekali; idempoten). Logika ada di
simp.home.HomeResize:
  1. Kelas baru popup/SystemShortcut$ShadyResize (item menu tekan-lama "Ubah ukuran"); ikon dan listener
     dari HomeResize.icon() / HomeResize.listener(). listener() mengembalikan null untuk item non-homescreen,
     sehingga item tidak tampil di app drawer.
  2. popup/SystemShortcutFactory.<init>(): array shortcut 5 -> 6 elemen, elemen ke-6 = ShadyResize.
  3. model/LoaderCursor.applyCommonProperties: baca kolom spanX/spanY dari database. Bawaan Launcher3 hanya
     membaca span untuk widget, jadi tanpa ini ukuran kartu kembali ke 1x1 setiap launcher dimuat ulang.
"""
import glob
import os
import re
import sys

work = sys.argv[1]

SHORTCUT_CLASS = r"""# Item menu tekan-lama "Ubah ukuran" untuk kartu homescreen (dibuat oleh tools/patch_home_resize.py).
.class public Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;
.super Lcom/android/launcher3/popup/SystemShortcut;
.source "SystemShortcut.java"


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-static {}, Lsimp/home/HomeResize;->icon()Landroid/graphics/drawable/Icon;

    move-result-object v0

    const-string v1, "Ubah ukuran"

    const-string v2, "Ubah ukuran kartu"

    const/4 v3, 0x0

    invoke-direct {p0, v0, v1, v2, v3}, Lcom/android/launcher3/popup/SystemShortcut;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Ljava/lang/CharSequence;I)V

    return-void
.end method


# virtual methods
.method public getOnClickListener(Lcom/android/launcher3/BaseDraggingActivity;Lcom/android/launcher3/ItemInfo;)Landroid/view/View$OnClickListener;
    .locals 1

    invoke-static {p1, p2}, Lsimp/home/HomeResize;->listener(Ljava/lang/Object;Ljava/lang/Object;)Landroid/view/View$OnClickListener;

    move-result-object v0

    return-object v0
.end method
"""


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_one(rel):
    c = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, rel)] if os.path.isfile(p)]
    if len(c) != 1:
        die("%s ditemukan %d (butuh tepat 1)" % (rel, len(c)))
    return c[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1 + 2. SystemShortcutFactory ----
factory = find_one("com/android/launcher3/popup/SystemShortcutFactory.smali")
src = read(factory)
if "SystemShortcut$ShadyResize" in src:
    print("SystemShortcutFactory sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method public constructor <init>\(\)V\n.*?^\.end method", src)
    if not m:
        die("SystemShortcutFactory.<init>() tidak ditemukan")
    body = m.group(0)
    if body.count("const/4 v0, 0x5\n") != 1:
        die("ukuran array shortcut bukan 5 persis satu kali (struktur beda dari yang diperkirakan)")
    lm = re.search(r"\.locals (\d+)", body)
    if not lm or int(lm.group(1)) < 3:
        die(".locals SystemShortcutFactory.<init>() < 3")
    call = "    invoke-direct {p0, v0}, Lcom/android/launcher3/popup/SystemShortcutFactory;-><init>([Lcom/android/launcher3/popup/SystemShortcut;)V"
    if body.count(call) != 1:
        die("pemanggilan konstruktor varargs tidak ditemukan tepat sekali")
    add = (
        "    new-instance v1, Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;\n\n"
        "    invoke-direct {v1}, Lcom/android/launcher3/popup/SystemShortcut$ShadyResize;-><init>()V\n\n"
        "    const/4 v2, 0x5\n\n"
        "    aput-object v1, v0, v2\n\n"
    )
    body = body.replace("const/4 v0, 0x5\n", "const/4 v0, 0x6\n").replace(call, add + call)
    src = src[: m.start()] + body + src[m.end():]
    write(factory, src)
    print("smali dipatch: SystemShortcutFactory -> +ShadyResize (6 shortcut)")

# kelas baru, di folder smali yang sama dengan SystemShortcut
sc = find_one("com/android/launcher3/popup/SystemShortcut.smali")
new_cls = os.path.join(os.path.dirname(sc), "SystemShortcut$ShadyResize.smali")
write(new_cls, SHORTCUT_CLASS)
print("smali dibuat:", os.path.relpath(new_cls, work))

# ---- 3. LoaderCursor.applyCommonProperties ----
lc = find_one("com/android/launcher3/model/LoaderCursor.smali")
src = read(lc)
if "Lsimp/home/HomeResize;" in src:
    print("LoaderCursor sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method public applyCommonProperties\(Lcom/android/launcher3/ItemInfo;\)V\n.*?^\.end method", src)
    if not m:
        die("LoaderCursor.applyCommonProperties tidak ditemukan")
    body = m.group(0)
    lm = re.search(r"\.locals (\d+)", body)
    if not lm or int(lm.group(1)) < 1:
        die("applyCommonProperties: .locals < 1")
    tail = "\n    return-void\n.end method"
    if not body.endswith(tail):
        die("applyCommonProperties tidak berakhir dengan return-void biasa")
    hook = ""
    for col in ("spanX", "spanY"):
        hook += (
            '\n    const-string v0, "%s"\n\n'
            "    invoke-static {p0, v0}, Lsimp/home/HomeResize;->span(Landroid/database/Cursor;Ljava/lang/String;)I\n\n"
            "    move-result v0\n\n"
            "    iput v0, p1, Lcom/android/launcher3/ItemInfo;->%s:I\n" % (col, col)
        )
    body = body[: -len(tail)] + "\n" + hook + tail
    write(lc, src[: m.start()] + body + src[m.end():])
    print("smali dipatch: LoaderCursor.applyCommonProperties -> baca spanX/spanY")

print("patch resize selesai")
