#!/usr/bin/env python3
"""Tahap 2 (nomor 3) tema Simp -> Shady: search bar di header app drawer.

Pemakaian: patch_search.py <folder_decoded> <folder_patch>

Drawer Shady memakai QSB Google (AllAppsQsbContainer) yang tidak memfilter aplikasi. APK ini
masih membawa search bar bawaan Launcher3 (AppsSearchContainerLayout + DefaultAppSearchAlgorithm),
jadi patch ini:
  1. mengganti <include search_container_all_apps_plus> di res/layout/all_apps.xml dengan
     AppsSearchContainerLayout bergaya pil (id tetap search_container_all_apps, sehingga
     AllAppsContainerView tetap menemukannya lewat SearchUiManager);
  2. mengganti AppsSearchContainerLayout.onMeasure supaya lebar pil mengikuti lebar grid kartu
     (stock menghitung dari hotseat), lewat simp.drawer.DrawerGrid.searchInsetPx();
  3. menyalin drawable latar pil.
Gagal keras bila pola tidak ditemukan tepat sekali. Referensi lain ke AllAppsQsbContainer hanya dilaporkan.
"""
import glob
import os
import re
import shutil
import sys

work, patch = sys.argv[1], sys.argv[2]
res = os.path.join(work, "res")


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1. drawable + layout ----
dd = os.path.join(res, "drawable")
os.makedirs(dd, exist_ok=True)
shutil.copy(os.path.join(patch, "drawer_search_bg.xml"), os.path.join(dd, "drawer_search_bg.xml"))

SEARCH_VIEW = """<com.android.launcher3.allapps.search.AppsSearchContainerLayout
        android:id="@id/search_container_all_apps"
        android:layout_width="fill_parent"
        android:layout_height="@dimen/all_apps_search_bar_field_height"
        android:layout_gravity="center|top"
        android:layout_centerHorizontal="true"
        android:background="@drawable/drawer_search_bg"
        android:focusableInTouchMode="true"
        android:gravity="center_vertical|start"
        android:hint="@string/all_apps_search_bar_hint"
        android:imeOptions="actionSearch|flagNoExtractUi"
        android:inputType="text|textNoSuggestions|textCapWords"
        android:maxLines="1"
        android:singleLine="true"
        android:saveEnabled="false"
        android:paddingLeft="18.0dip"
        android:paddingRight="18.0dip"
        android:textColor="#FF1B2430"
        android:textColorHint="#8A1B2430"
        android:textSize="16.0sp"
        android:translationY="0.0dip"
        android:elevation="0.0dip"
        xmlns:android="http://schemas.android.com/apk/res/android" />"""

path = os.path.join(res, "layout", "all_apps.xml")
if not os.path.isfile(path):
    die("res/layout/all_apps.xml tidak ada")
s = read(path)
if "AppsSearchContainerLayout" in s:
    print("all_apps.xml sudah memakai AppsSearchContainerLayout")
else:
    pat = re.compile(r'<include\b[^>]*?layout="@layout/search_container_all_apps_plus"[^>]*?/>', re.S)
    hits = pat.findall(s)
    if len(hits) != 1:
        die("include search_container_all_apps_plus muncul %d kali di all_apps.xml (butuh 1)" % len(hits))
    if "@id/search_container_all_apps" not in hits[0]:
        die("include QSB tidak membawa id search_container_all_apps: " + " ".join(hits[0].split()))
    # xmlns sudah dideklarasikan di root; hapus deklarasi ganda pada anak.
    view = SEARCH_VIEW.replace('\n        xmlns:android="http://schemas.android.com/apk/res/android"', "")
    s = s.replace(hits[0], view)
    write(path, s)
    print("all_apps.xml: QSB diganti AppsSearchContainerLayout")

# ---- 2. onMeasure ----
cands = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, "com/android/launcher3/allapps/search/AppsSearchContainerLayout.smali")]
         if os.path.isfile(p)]
if len(cands) != 1:
    die("AppsSearchContainerLayout.smali ditemukan %d (butuh tepat 1)" % len(cands))
sp = cands[0]
src = read(sp)

NEW_MEASURE = """.method protected onMeasure(II)V
    .locals 1

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    invoke-static {}, Lsimp/drawer/DrawerGrid;->searchInsetPx()I

    move-result v0

    mul-int/lit8 v0, v0, 0x2

    sub-int/2addr p1, v0

    const/high16 v0, 0x40000000    # EXACTLY

    invoke-static {p1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    invoke-super {p0, p1, p2}, Lcom/android/launcher3/ExtendedEditText;->onMeasure(II)V

    return-void
.end method"""

if "DrawerGrid;->searchInsetPx" in src:
    print("onMeasure sudah dipatch")
else:
    m = list(re.finditer(r"(?ms)^\.method protected onMeasure\(II\)V\n.*?^\.end method", src))
    if len(m) != 1:
        die("onMeasure(II)V di AppsSearchContainerLayout muncul %d kali (butuh 1)" % len(m))
    if "ExtendedEditText;->onMeasure" not in m[0].group(0):
        die("onMeasure asli tidak memanggil ExtendedEditText.onMeasure; struktur beda dari yang diperkirakan")
    src = src[: m[0].start()] + NEW_MEASURE + src[m[0].end():]
    write(sp, src)
    print("smali dipatch: AppsSearchContainerLayout.onMeasure -> lebar grid")

# ---- 3. laporan referensi lain ke QSB drawer (tidak menggagalkan build) ----
refs = []
for d in glob.glob(os.path.join(work, "smali*")):
    for root, _, files in os.walk(d):
        if "/shady/qsb" in root.replace("\\", "/"):
            continue
        for fn in files:
            if not fn.endswith(".smali"):
                continue
            p = os.path.join(root, fn)
            if "AllAppsQsbContainer" in read(p):
                refs.append(os.path.relpath(p, work))
print("referensi AllAppsQsbContainer di luar shady/qsb: %d" % len(refs))
for r in refs:
    print("  ", r)
print("patch search selesai")
