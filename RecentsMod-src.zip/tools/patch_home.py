#!/usr/bin/env python3
"""Tahap 2 (nomor 4) tema Simp -> Shady: homescreen kartu kaca teks-saja gaya SimpLauncher.

Pemakaian: patch_home.py <folder_decoded>
Sisipan kecil di smali (logika ada di simp.home.HomeCards dan simp.home.CardFont):
  1. BubbleTextView, akhir konstruktor 3-argumen: HomeCards.decorate(this, mDisplay)  -> latar kartu, label tengah, font
  2. BubbleTextView.applyCompoundDrawables, awal: bila HomeCards.textOnly(mDisplay) -> return (ikon tidak digambar)
  3. BubbleTextView.applyIconAndLabel, awal: CardFont.applyFont(this, info, mDisplay) -> ukuran font per kartu
     (homescreen = display 0, drawer = display 1; display lain tidak berubah)
  4. ShortcutAndWidgetContainer.measureChild: padding kiri/kanan yang dihitung Launcher3 (workspaceCellPaddingXPx, ~8dp)
     lewat HomeCards.cellPadX -> label tidak menempel di tepi kartu. Tanpa ini padding dari decorate() ditimpa
     setiap measure.
Hanya ikon dengan iconDisplay == 0 (homescreen + hotseat) yang berubah tampilannya; drawer (1) dan folder (2) tidak.
Gagal keras bila pola tidak ditemukan tepat sekali.
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


cands = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, "com/android/launcher3/BubbleTextView.smali")] if os.path.isfile(p)]
if len(cands) != 1:
    die("BubbleTextView.smali ditemukan %d (butuh tepat 1)" % len(cands))
path = cands[0]
with open(path, encoding="utf-8") as f:
    src = f.read()

if "Lsimp/home/HomeCards;" in src:
    print("BubbleTextView sudah dipatch")
else:
    FIELD = "Lcom/android/launcher3/BubbleTextView;->mDisplay:I"
    if ".field private final mDisplay:I" not in src:
        die("field mDisplay tidak ada di BubbleTextView; struktur beda dari yang diperkirakan")


    def method(sig):
        m = list(re.finditer(r"(?ms)^\.method[^\n]*" + re.escape(sig) + r"[^\n]*\n.*?^\.end method", src))
        if len(m) != 1:
            die("method %s muncul %d kali (butuh 1)" % (sig, len(m)))
        return m[0]


    # 1. konstruktor 3-argumen
    m = method("<init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V")
    body = m.group(0)
    tail = "\n    return-void\n.end method"
    if not body.endswith(tail):
        die("konstruktor tidak berakhir dengan return-void biasa")
    if not re.search(r"\.locals (\d+)", body) or int(re.search(r"\.locals (\d+)", body).group(1)) < 2:
        die(".locals konstruktor terlalu kecil untuk register sementara")
    hook = (
        "\n    iget v0, p0, %s\n\n"
        "    invoke-static {p0, v0}, Lsimp/home/HomeCards;->decorate(Landroid/widget/TextView;I)V\n"
    ) % FIELD
    body = body[: -len(tail)] + "\n" + hook + tail
    src = src[: m.start()] + body + src[m.end():]

    # 2. applyCompoundDrawables
    m = method("applyCompoundDrawables(Landroid/graphics/drawable/Drawable;)V")
    body = m.group(0)
    lm = re.search(r"\.locals (\d+)\n", body)
    if not lm or int(lm.group(1)) < 1:
        die("applyCompoundDrawables: .locals tidak cocok")
    guard = (
        "\n    iget v0, p0, %s\n\n"
        "    invoke-static {v0}, Lsimp/home/HomeCards;->textOnly(I)Z\n\n"
        "    move-result v0\n\n"
        "    if-eqz v0, :simp_show_icon\n\n"
        "    return-void\n\n"
        "    :simp_show_icon\n"
    ) % FIELD
    body = body[: lm.end()] + guard + body[lm.end():]
    src = src[: m.start()] + body + src[m.end():]

    # 3. applyIconAndLabel: ukuran font per kartu (p1 = ItemInfoWithIcon, masih utuh di awal method; v0 bebas)
    m = method("applyIconAndLabel(Lcom/android/launcher3/ItemInfoWithIcon;)V")
    body = m.group(0)
    lm = re.search(r"\.locals (\d+)\n", body)
    if not lm or int(lm.group(1)) < 1:
        die("applyIconAndLabel: .locals tidak cocok")
    font = (
        "\n    iget v0, p0, %s\n\n"
        "    invoke-static {p0, p1, v0}, Lsimp/home/CardFont;->applyFont(Landroid/widget/TextView;Ljava/lang/Object;I)V\n"
    ) % FIELD
    body = body[: lm.end()] + font + body[lm.end():]
    src = src[: m.start()] + body + src[m.end():]

    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
    print("smali dipatch: BubbleTextView ctor -> HomeCards.decorate; applyCompoundDrawables -> HomeCards.textOnly; "
          "applyIconAndLabel -> CardFont.applyFont")


# ---- 4. ShortcutAndWidgetContainer.measureChild: padding kiri/kanan kartu ----
cands = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, "com/android/launcher3/ShortcutAndWidgetContainer.smali")] if os.path.isfile(p)]
if len(cands) != 1:
    die("ShortcutAndWidgetContainer.smali ditemukan %d (butuh tepat 1)" % len(cands))
with open(cands[0], encoding="utf-8") as f:
    sw = f.read()
if "Lsimp/home/HomeCards;->cellPadX" in sw:
    print("ShortcutAndWidgetContainer sudah dipatch")
else:
    m = re.search(r"(?ms)^\.method public measureChild\(Landroid/view/View;\)V\n.*?^\.end method", sw)
    if not m:
        die("ShortcutAndWidgetContainer.measureChild tidak ditemukan")
    mb = m.group(0)
    call = "    invoke-virtual {p1, v1, v2, v1, v3}, Landroid/view/View;->setPadding(IIII)V\n"
    if mb.count(call) != 1:
        die("measureChild: setPadding(v1, v2, v1, v3) tidak ditemukan tepat sekali")
    hook = ("    invoke-static {p1, v1}, Lsimp/home/HomeCards;->cellPadX(Landroid/view/View;I)I\n\n"
            "    move-result v1\n\n")
    mb = mb.replace(call, hook + call)
    with open(cands[0], "w", encoding="utf-8") as f:
        f.write(sw[: m.start()] + mb + sw[m.end():])
    print("smali dipatch: ShortcutAndWidgetContainer.measureChild -> HomeCards.cellPadX")
print("patch home selesai")
