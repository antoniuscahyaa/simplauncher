#!/usr/bin/env python3
"""Tahap 2 (nomor 4) tema Simp -> Shady: homescreen kartu kaca teks-saja gaya SimpLauncher.

Pemakaian: patch_home.py <folder_decoded>
Dua sisipan kecil di smali BubbleTextView (semua logika ada di simp.home.HomeCards):
  1. akhir konstruktor 3-argumen: HomeCards.decorate(this, mDisplay)  -> latar kartu, label tengah, font
  2. awal applyCompoundDrawables: bila HomeCards.textOnly(mDisplay) -> return (ikon tidak digambar)
Hanya ikon dengan iconDisplay == 0 (homescreen + hotseat) yang berubah; drawer (1) dan folder (2) tidak.
Gagal keras bila pola tidak ditemukan tepat sekali.
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


cands = [p for d in glob.glob(os.path.join(work, "smali*"))
         for p in [os.path.join(d, "com/android/launcher3/BubbleTextView.smali")] if os.path.isfile(p)]
if len(cands) != 1:
    die("BubbleTextView.smali ditemukan %d (butuh tepat 1)" % len(cands))
path = cands[0]
with open(path, encoding="utf-8") as f:
    src = f.read()

FIELD = "Lcom/android/launcher3/BubbleTextView;->mDisplay:I"
if "Lsimp/home/HomeCards;" in src:
    print("BubbleTextView sudah dipatch")
    sys.exit(0)
if ".field private final mDisplay:I" not in src:
    die("field mDisplay tidak ada di BubbleTextView; struktur beda dari yang diperkirakan")


def method(sig):
    m = list(re.finditer(r"(?ms)^\.method[^\n]*" + re.escape(sig) + r"[^\n]*\n.*?^\.end method", src))
    if len(m) != 1:
        die("method %s muncul %d kali (butuh 1)" % (sig, len(m)))
    return m[0]


# 1. konstruktor 3-argumen
m = method("<init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V")
body = m.group(0)
tail = "\n    return-void\n.end method"
if not body.endswith(tail):
    die("konstruktor tidak berakhir dengan return-void biasa")
if not re.search(r"\.locals (\d+)", body) or int(re.search(r"\.locals (\d+)", body).group(1)) < 2:
    die(".locals konstruktor terlalu kecil untuk register sementara")
hook = (
    "\n    iget v0, p0, %s\n\n"
    "    invoke-static {p0, v0}, Lsimp/home/HomeCards;->decorate(Landroid/widget/TextView;I)V\n"
) % FIELD
body = body[: -len(tail)] + "\n" + hook + tail
src = src[: m.start()] + body + src[m.end():]

# 2. applyCompoundDrawables
m = method("applyCompoundDrawables(Landroid/graphics/drawable/Drawable;)V")
body = m.group(0)
lm = re.search(r"\.locals (\d+)\n", body)
if not lm or int(lm.group(1)) < 1:
    die("applyCompoundDrawables: .locals tidak cocok")
guard = (
    "\n    iget v0, p0, %s\n\n"
    "    invoke-static {v0}, Lsimp/home/HomeCards;->textOnly(I)Z\n\n"
    "    move-result v0\n\n"
    "    if-eqz v0, :simp_show_icon\n\n"
    "    return-void\n\n"
    "    :simp_show_icon\n"
) % FIELD
body = body[: lm.end()] + guard + body[lm.end():]
src = src[: m.start()] + body + src[m.end():]

with open(path, "w", encoding="utf-8") as f:
    f.write(src)
print("smali dipatch: BubbleTextView ctor -> HomeCards.decorate; applyCompoundDrawables -> HomeCards.textOnly")
print("patch home selesai")
