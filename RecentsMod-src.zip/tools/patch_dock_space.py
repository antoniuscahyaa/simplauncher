#!/usr/bin/env python3
"""Hilangkan ruang cadangan dock/swipe-shelf di bawah kartu Recents.

Pemakaian: patch_dock_space.py <folder_decoded>

LayoutUtils.calculateLauncherTaskSize menyisihkan di bawah kartu: tinggi swipe-up + drag handle +
hotseat extra + hotseat bottom padding (ruang dock). Dock sudah dihapus, jadi ruang itu cuma
meninggalkan area kosong di bawah Recents. Patch ini membuat nilai cadangan itu selalu 0
(kartu dihitung terhadap seluruh tinggi layar dan diposisikan di tengah).
Gagal keras bila pola tidak ditemukan tepat sekali; idempoten.
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


c = [p for d in glob.glob(os.path.join(work, "smali*"))
     for p in [os.path.join(d, "com/android/quickstep/util/LayoutUtils.smali")] if os.path.isfile(p)]
if len(c) != 1:
    die("LayoutUtils.smali ditemukan %d (butuh 1)" % len(c))
path = c[0]
src = open(path, encoding="utf-8").read()

if "# simp: tanpa ruang dock" in src:
    print("LayoutUtils sudah dipatch")
    sys.exit(0)

m = re.search(r"(?ms)^\.method public static calculateLauncherTaskSize\(.*?^\.end method", src)
if not m:
    die("calculateLauncherTaskSize tidak ditemukan")
body = m.group(0)
old = "    :goto_0\n    const/4 v1, 0x1\n"
if body.count(old) != 1:
    die("calculateLauncherTaskSize: pola :goto_0 / const/4 v1, 0x1 muncul %d kali (butuh 1)" % body.count(old))
new = "    :goto_0\n    # simp: tanpa ruang dock\n    const/4 v0, 0x0\n\n    const/4 v1, 0x1\n"
body = body.replace(old, new)
src = src[: m.start()] + body + src[m.end():]
open(path, "w", encoding="utf-8").write(src)
print("smali dipatch: LayoutUtils.calculateLauncherTaskSize -> ruang dock/swipe 0")
