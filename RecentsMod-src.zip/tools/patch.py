#!/usr/bin/env python3
"""Terapkan patch tampilan Recents ke hasil `apktool d` (folder decoded).

Pemakaian: patch.py <folder_decoded> <folder_patch>
Gagal keras (exit 1) bila bagian penting tidak ditemukan, supaya build tidak
menghasilkan APK yang setengah jadi.
"""
import glob
import os
import re
import shutil
import sys

work, patch = sys.argv[1], sys.argv[2]
res = os.path.join(work, "res")

# Nilai yang diubah (dp). Header kartu 28dp, ikon asli dikecilkan hingga tak terlihat.
DIMENS = {
    "task_thumbnail_top_margin": "28.0dip",
    "task_thumbnail_icon_size": "1.0dip",
}
SIDE_MARGIN = "9dp"  # padding kiri/kanan thumbnail di dalam bingkai kaca
# Bar aksi di dasar kartu: 2 baris tombol 36dp + jarak 6dp, rapat ke tepi bingkai 9dp,
# lalu 8dp ke thumbnail. Harus sinkron dengan BTN_H / GAP di TaskActionBar.java.
BAR_MARGIN = "9dp"
THUMB_BOTTOM = "48dp"  # ruang footer untuk chevron; panel aksi dibuka secara overlay


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def find_smali(class_path):
    matches = []
    for folder in glob.glob(os.path.join(work, "smali*")):
        candidate = os.path.join(folder, class_path + ".smali")
        if os.path.isfile(candidate):
            matches.append(candidate)
    if not matches:
        die("kelas smali tidak ditemukan: " + class_path)
    if len(matches) > 1:
        die("kelas smali duplikat, tidak aman dipatch: " + class_path)
    return matches[0]


def patch_method(path, signature, transformer, description):
    source = read(path)
    pattern = re.compile(r"(?ms)^\.method[^\n]*" + re.escape(signature) + r"[^\n]*\n.*?^\.end method")
    match = pattern.search(source)
    if not match:
        die("method smali tidak ditemukan (" + description + "): " + signature)
    old_method = match.group(0)
    new_method = transformer(old_method)
    if new_method == old_method:
        die("method smali tidak berubah (" + description + ")")
    write(path, source[:match.start()] + new_method + source[match.end():])
    print("smali dipatch: " + description)


# ---- 1. dimens -------------------------------------------------------------
found = {k: 0 for k in DIMENS}
for path in glob.glob(os.path.join(res, "values*", "*.xml")):
    s = read(path)
    new = s
    for name, val in DIMENS.items():
        pat = re.compile(r'(<dimen\b[^>]*\bname="%s"[^>]*>)([^<]*)(</dimen>)' % re.escape(name))

        def sub(m, val=val, name=name):
            found[name] += 1
            print("dimen %s: %s -> %s  (%s)" % (name, m.group(2), val, os.path.relpath(path, work)))
            return m.group(1) + val + m.group(3)

        new = pat.sub(sub, new)
    if new != s:
        write(path, new)
for name, n in found.items():
    if n == 0:
        die("dimen %s tidak ditemukan" % name)

# ---- 2. drawable baru ------------------------------------------------------
dd = os.path.join(res, "drawable")
os.makedirs(dd, exist_ok=True)
shutil.copy(os.path.join(patch, "task_glass_bg.xml"), os.path.join(dd, "task_glass_bg.xml"))
shutil.copy(os.path.join(patch, "clear_all_bg.xml"), os.path.join(dd, "clear_all_bg.xml"))

# ---- 3. layout task.xml ----------------------------------------------------
task_path = os.path.join(res, "layout", "task.xml")
if not os.path.exists(task_path):
    die("res/layout/task.xml tidak ada")
t = read(task_path)

ROOT = "com.android.quickstep.views.TaskView"
THUMB = "com.android.quickstep.views.TaskThumbnailView"

if "task_glass_bg" in t:
    die("task.xml sudah dipatch (jalankan dari hasil decode yang bersih)")

# bingkai kaca di root
m = re.search(r"<%s\b" % re.escape(ROOT), t)
if not m:
    die("tag root TaskView tidak ditemukan")
t = t[: m.end()] + '\n    android:background="@drawable/task_glass_bg"' + t[m.end():]

# margin thumbnail
m = re.search(r"<%s\b" % re.escape(THUMB), t)
if not m:
    die("tag TaskThumbnailView tidak ditemukan")
ins = (
    '\n    android:layout_marginStart="%s"'
    '\n    android:layout_marginEnd="%s"'
    '\n    android:layout_marginBottom="%s"' % (SIDE_MARGIN, SIDE_MARGIN, THUMB_BOTTOM)
)
t = t[: m.end()] + ins + t[m.end():]

# label di paling atas (terakhir = paling depan)
label = (
    '    <simp.recents.TaskLabelView\n'
    '        android:layout_width="match_parent"\n'
    '        android:layout_height="@dimen/task_thumbnail_top_margin"\n'
    '        android:layout_gravity="top|start"\n'
    '        android:paddingStart="12dp"\n'
    '        android:paddingEnd="12dp" />\n'
    # panel aksi ringkas: chevron tertanam di footer kartu; tombol tersembunyi awalnya
    '    <simp.recents.TaskActionBar\n'
    '        android:layout_width="match_parent"\n'
    '        android:layout_height="wrap_content"\n'
    '        android:layout_gravity="bottom"\n'
    '        android:layout_marginStart="%s"\n'
    '        android:layout_marginEnd="%s"\n'
    '        android:layout_marginBottom="%s" />\n' % (BAR_MARGIN, BAR_MARGIN, BAR_MARGIN)
)
close = "</%s>" % ROOT
idx = t.rfind(close)
if idx < 0:
    die("penutup root TaskView tidak ditemukan")
t = t[:idx] + label + t[idx:]
write(task_path, t)
print("task.xml dipatch")

# ---- 4. tombol Hapus semua ---------------------------------------------------
ca_path = os.path.join(res, "layout", "overview_clear_all_button.xml")
if not os.path.exists(ca_path):
    die("res/layout/overview_clear_all_button.xml tidak ada")
c = read(ca_path)
m = re.search(r"<com\.android\.quickstep\.views\.ClearAllButton\b", c)
if not m:
    die("tag ClearAllButton tidak ditemukan dalam layout")
if "clear_all_bg" not in c:
    c = re.sub(r'\s+android:textColor="[^"]*"', "", c)
    m = re.search(r"<com\.android\.quickstep\.views\.ClearAllButton\b", c)
    add = (
        '\n    android:background="@drawable/clear_all_bg"'
        '\n    android:textColor="#FF14243A"'
        '\n    android:paddingStart="20dp"'
        '\n    android:paddingEnd="20dp"'
        '\n    android:minHeight="40dp"'
    )
    c = c[: m.end()] + add + c[m.end():]
    write(ca_path, c)
    print("overview_clear_all_button.xml dipatch")
else:
    print("overview_clear_all_button.xml sudah memakai clear_all_bg")

# ---- 5. Permission sistem untuk Force Stop -----------------------------------
mf_path = os.path.join(work, "AndroidManifest.xml")
if not os.path.exists(mf_path):
    die("AndroidManifest.xml tidak ada")
mf = read(mf_path)
permission = '    <uses-permission android:name="android.permission.FORCE_STOP_PACKAGES" />\n'
if "android.permission.FORCE_STOP_PACKAGES" not in mf:
    app_match = re.search(r"<application\b", mf)
    if not app_match:
        die("tag application tidak ditemukan saat menambahkan izin Force Stop")
    mf = mf[:app_match.start()] + permission + mf[app_match.start():]
    write(mf_path, mf)
    print("manifest: FORCE_STOP_PACKAGES ditambahkan")
else:
    print("manifest: FORCE_STOP_PACKAGES sudah ada")

# ---- 6. Activity pengaturan blur/scrim di manifest ---------------------------
mf_path = os.path.join(work, "AndroidManifest.xml")
if not os.path.exists(mf_path):
    die("AndroidManifest.xml tidak ada")
mf = read(mf_path)
if "RecentsSettingsActivity" not in mf:
    activity = (
        '    <activity android:theme="@android:style/Theme.DeviceDefault.NoActionBar"'
        ' android:label="Recents blur" android:icon="@android:drawable/ic_menu_preferences"'
        ' android:name="simp.recents.RecentsSettingsActivity" android:exported="true"'
        ' android:excludeFromRecents="true">\n'
        '        <intent-filter>\n'
        '            <action android:name="android.intent.action.MAIN"/>\n'
        '            <category android:name="android.intent.category.LAUNCHER"/>\n'
        '        </intent-filter>\n'
        '    </activity>\n'
    )
    idx = mf.rfind("</application>")
    if idx < 0:
        die("</application> tidak ditemukan di manifest")
    mf = mf[:idx] + activity + mf[idx:]
    write(mf_path, mf)
    print("manifest: RecentsSettingsActivity ditambahkan")


# ---- 7. Pertahankan model halaman native Launcher ---------------------------
# Jangan keluarkan ClearAllButton dari PagedView page model. PagedView.getPageScrolls()
# mengindeks child pages; mengurangi getPageCount()/filter child secara terpisah
# menyebabkan ArrayIndexOutOfBoundsException saat createTaskDismissAnimation().
# Clear All tetap merupakan child/page native. RecentsStackCarousel hanya
# mentranslasikannya ke kanan atas sebagai overlay visual.

paged = find_smali("com/android/launcher3/PagedView")
recents = find_smali("com/android/quickstep/views/RecentsView")

# Re-apply visual transforms after Launcher has applied its own page curve transforms.
def add_before_returns(method, count, label):
    call = "    invoke-static {p0}, Lsimp/recents/RecentsStackCarousel;->update(Landroid/view/ViewGroup;)V\n"
    actual = method.count("    return-void")
    if actual != count:
        die(label + ": jumlah return-void berubah (" + str(actual) + ")")
    return method.replace("    return-void", call + "    return-void")

patch_method(recents, "updateCurveProperties()V",
             lambda m: add_before_returns(m, 2, "updateCurveProperties"),
             "carousel mengikuti perubahan scroll")
patch_method(recents, "onLayout(ZIIII)V",
             lambda m: add_before_returns(m, 1, "RecentsView.onLayout"),
             "carousel saat layout")
patch_method(paged, "scrollTo(II)V",
             lambda m: add_before_returns(m, 1, "PagedView.scrollTo"),
             "Clear All tetap di kanan atas saat swipe")


print("patch selesai")
