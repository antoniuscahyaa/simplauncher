#!/usr/bin/env python3
"""Tahap 2 (nomor 1) tema Simp -> Shady: app drawer 3 kolom dengan kartu lebar.

Pemakaian: patch_drawer.py <folder_decoded>
Mengganti pembacaan jumlah kolom, tinggi sel, ukuran ikon, dan jarak ikon-label drawer
dengan panggilan ke simp.drawer.DrawerGrid. Gagal keras bila jumlah kemunculan tidak sesuai.

Span: GridLayoutManager memakai 6 satuan per baris (AllAppsContainerView/AllAppsGridAdapter -> columns()) supaya kartu
bisa selebar 1,5 kolom; hitungan baris scrollbar (AllAppsRecyclerView/AlphabeticalAppsList) tetap 3 (nominalColumns()).
"""
import glob
import os
import re
import sys

work = sys.argv[1]
H = "Lcom/android/launcher3/"
CALL = "Lsimp/drawer/DrawerGrid;->%s()I"


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_smali(class_path):
    hits = [p for d in glob.glob(os.path.join(work, "smali*"))
            for p in [os.path.join(d, class_path + ".smali")] if os.path.isfile(p)]
    if len(hits) != 1:
        die("kelas smali %s: ditemukan %d (butuh tepat 1)" % (class_path, len(hits)))
    return hits[0]


# (kelas, kelas pemilik field, field, fungsi pengganti, jumlah kemunculan yang diharapkan)
EDITS = [
    ("allapps/AllAppsContainerView", "InvariantDeviceProfile", "numAllAppsColumns", "columns", 1),
    ("allapps/AllAppsGridAdapter", "InvariantDeviceProfile", "numAllAppsColumns", "columns", 1),
    ("allapps/AllAppsGridAdapter", "DeviceProfile", "allAppsCellHeightPx", "cellHeightPx", 1),
    ("allapps/AllAppsRecyclerView", "InvariantDeviceProfile", "numColumns", "nominalColumns", 1),
    ("allapps/AllAppsRecyclerView", "DeviceProfile", "allAppsCellHeightPx", "cellHeightPx", 1),
    ("allapps/AlphabeticalAppsList", "InvariantDeviceProfile", "numColumns", "nominalColumns", 1),
    ("BubbleTextView", "DeviceProfile", "allAppsIconSizePx", "iconPx", 1),
    ("BubbleTextView", "DeviceProfile", "allAppsIconDrawablePaddingPx", "gapPx", 1),
]

cache = {}
for cls, owner, field, fn, expected in EDITS:
    path = find_smali("com/android/launcher3/" + cls)
    src = cache.get(path)
    if src is None:
        with open(path, encoding="utf-8") as f:
            src = f.read()
    pat = re.compile(r"^([ \t]*)iget (\w+), \w+, %s%s;->%s:I[ \t]*$" % (re.escape(H), owner, field), re.M)
    n = len(pat.findall(src))
    if n != expected:
        die("%s: %s.%s muncul %d kali, diharapkan %d" % (cls, owner, field, n, expected))
    src = pat.sub(lambda m: "%sinvoke-static {}, %s\n\n%smove-result %s" % (m.group(1), CALL % fn, m.group(1), m.group(2)), src)
    cache[path] = src
    print("smali dipatch: %s %s -> DrawerGrid.%s()" % (cls, field, fn))

def insert_call(cls, sig):
    """Sisipkan DrawerGrid.applyGap(this) sebelum baris kode pertama sebuah method."""
    path = find_smali("com/android/launcher3/" + cls)
    src = cache.get(path)
    if src is None:
        with open(path, encoding="utf-8") as f:
            src = f.read()
    m = re.search(r"(?ms)^\.method[^\n]*" + re.escape(sig) + r"[^\n]*\n.*?^\.end method", src)
    if not m:
        die("method tidak ditemukan: %s %s" % (cls, sig))
    body = m.group(0)
    i = body.find("\n    .line ")
    if i < 0:
        die("tidak ada .line di %s %s" % (cls, sig))
    call = "\n    invoke-static {p0}, Lsimp/drawer/DrawerGrid;->applyGap(Landroid/view/View;)V\n"
    body = body[: i] + call + body[i:]
    cache[path] = src[: m.start()] + body + src[m.end():]
    print("smali dipatch: %s %s -> applyGap" % (cls, sig))


insert_call("allapps/AllAppsContainerView", "setInsets(Landroid/graphics/Rect;)V")
insert_call("allapps/AllAppsContainerView", "reset(Z)V")

for path, src in cache.items():
    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
print("patch drawer selesai")
