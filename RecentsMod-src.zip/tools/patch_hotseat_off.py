#!/usr/bin/env python3
"""Matikan hotseat (dock) sepenuhnya.

Pemakaian: patch_hotseat_off.py <folder_decoded>
Dua perbaikan (gagal keras bila pola tidak ditemukan; idempoten):
  1. res/layout/hotseat.xml: root diberi visibility=gone. Override Hotseat.setVisibility baru berlaku setelah
     ada yang memanggilnya, jadi saat aplikasi pertama dibuka hotseat sempat tampil (5 kotak kosong di bawah).
  2. smali Workspace.isPointInSelfOverHotseat -> selalu false. Hotseat yang GONE masih menyimpan batas layout lama
     (area bawah layar); menjatuhkan ikon di baris paling bawah dianggap "jatuh di hotseat" lalu memakai
     CellLayout hotseat yang tidak punya ukuran sel -> force close.
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


# ---- 1. hotseat.xml ----
xml = os.path.join(work, "res", "layout", "hotseat.xml")
if not os.path.isfile(xml):
    die("res/layout/hotseat.xml tidak ada")
s = open(xml, encoding="utf-8").read()
m = re.search(r"<com\.android\.launcher3\.[A-Za-z0-9_.]*Hotseat[A-Za-z0-9_]*\b[^>]*>", s)
if not m:
    die("root Hotseat di hotseat.xml tidak ditemukan")
tag = m.group(0)
if 'android:visibility="gone"' in tag:
    print("hotseat.xml sudah dipatch")
else:
    if "android:visibility=" in tag:
        new = re.sub(r'android:visibility="[^"]*"', 'android:visibility="gone"', tag)
    else:
        new = re.sub(r"^(<[^\s>]+)", r'\1 android:visibility="gone"', tag, count=1)
    open(xml, "w", encoding="utf-8").write(s.replace(tag, new, 1))
    print("hotseat.xml: root -> visibility gone")

# ---- 2. Workspace.isPointInSelfOverHotseat ----
c = [p for d in glob.glob(os.path.join(work, "smali*"))
     for p in [os.path.join(d, "com/android/launcher3/Workspace.smali")] if os.path.isfile(p)]
if len(c) != 1:
    die("Workspace.smali ditemukan %d (butuh 1)" % len(c))
src = open(c[0], encoding="utf-8").read()
if "# simp: tidak pernah di atas hotseat" in src:
    print("Workspace sudah dipatch")
else:
    pat = re.compile(r"(\.method isPointInSelfOverHotseat\(II\)Z\n    \.locals \d+\n)")
    if len(pat.findall(src)) != 1:
        die("Workspace.isPointInSelfOverHotseat tidak cocok pola (%d)" % len(pat.findall(src)))
    src = pat.sub(lambda m: m.group(1) + "\n    # simp: tidak pernah di atas hotseat\n    const/4 p1, 0x0\n\n    return p1\n", src)
    open(c[0], "w", encoding="utf-8").write(src)
    print("smali dipatch: Workspace.isPointInSelfOverHotseat -> selalu false")
print("patch hotseat selesai")
