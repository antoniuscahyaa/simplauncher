#!/usr/bin/env python3
"""Sembunyikan indikator halaman workspace (garis kecil di bawah homescreen).

Pemakaian: patch_hide_indicator.py <folder_decoded>
Dua lapis: (1) launcher.xml: WorkspacePageIndicator diberi visibility=gone;
(2) smali WorkspacePageIndicator.onDraw -> langsung return (bila method ditemukan).
Gagal keras hanya bila KEDUA lapis gagal. Idempoten.
"""
import glob
import os
import re
import sys

work = sys.argv[1]
ok = False

# ---- 1. layout ----
xml = os.path.join(work, "res", "layout", "launcher.xml")
if os.path.isfile(xml):
    s = open(xml, encoding="utf-8").read()
    m = re.search(r"<com\.android\.launcher3\.pageindicators\.WorkspacePageIndicator\b[^>]*>", s)
    if m:
        tag = m.group(0)
        if 'android:visibility="gone"' in tag:
            print("launcher.xml sudah dipatch")
            ok = True
        elif "android:visibility=" in tag:
            new = re.sub(r'android:visibility="[^"]*"', 'android:visibility="gone"', tag)
            open(xml, "w", encoding="utf-8").write(s.replace(tag, new))
            print("launcher.xml: page indicator -> gone"); ok = True
        else:
            new = tag.replace("<com.android.launcher3.pageindicators.WorkspacePageIndicator",
                              '<com.android.launcher3.pageindicators.WorkspacePageIndicator android:visibility="gone"', 1)
            open(xml, "w", encoding="utf-8").write(s.replace(tag, new))
            print("launcher.xml: page indicator -> gone"); ok = True
    else:
        print("peringatan: WorkspacePageIndicator tidak ada di launcher.xml")
else:
    print("peringatan: launcher.xml tidak ada")

# ---- 2. smali onDraw ----
c = [p for d in glob.glob(os.path.join(work, "smali*"))
     for p in [os.path.join(d, "com/android/launcher3/pageindicators/WorkspacePageIndicator.smali")] if os.path.isfile(p)]
if len(c) == 1:
    src = open(c[0], encoding="utf-8").read()
    if "# simp: indikator halaman tidak digambar" in src:
        print("WorkspacePageIndicator sudah dipatch"); ok = True
    else:
        pat = re.compile(r"(\.method (?:public|protected) onDraw\(Landroid/graphics/Canvas;\)V\n    \.locals \d+\n)")
        if len(pat.findall(src)) == 1:
            src = pat.sub(lambda m: m.group(1) + "\n    # simp: indikator halaman tidak digambar\n    return-void\n", src)
            open(c[0], "w", encoding="utf-8").write(src)
            print("smali dipatch: WorkspacePageIndicator.onDraw -> tidak menggambar"); ok = True
        else:
            print("peringatan: onDraw WorkspacePageIndicator tidak cocok pola")
else:
    print("peringatan: WorkspacePageIndicator.smali ditemukan %d" % len(c))

if not ok:
    print("GAGAL: indikator halaman tidak bisa disembunyikan lewat kedua cara")
    sys.exit(1)
print("patch indikator selesai")
