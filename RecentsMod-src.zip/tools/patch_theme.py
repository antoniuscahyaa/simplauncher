#!/usr/bin/env python3
"""Tahap 1 tema Simp -> Shady: kartu kaca di ikon homescreen dan app drawer.

Pemakaian: patch_theme.py <folder_decoded> <folder_patch>
Hanya menyentuh resource XML (tanpa smali). Gagal keras bila layout ikon tidak ada.
"""
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

work, patch = sys.argv[1], sys.argv[2]
res = os.path.join(work, "res")


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


dd = os.path.join(res, "drawable")
os.makedirs(dd, exist_ok=True)
for name in ("home_card_bg.xml", "drawer_card_bg.xml"):
    shutil.copy(os.path.join(patch, name), os.path.join(dd, name))

# layout -> (drawable). Yang dipatch adalah elemen ROOT layout (view ikon itu sendiri),
# apa pun nama kelasnya, karena Shady bisa memakai subclass BubbleTextView sendiri.
TARGETS = {
    "app_icon.xml": "home_card_bg",          # homescreen + hotseat
    "all_apps_icon.xml": "drawer_card_bg",    # app drawer
}
# atribut tambahan: kartu lebar di drawer (ikon di kiri, label di kanan; didukung BubbleTextView)
EXTRA = {
    "all_apps_icon.xml": (
        '\n    launcher:layoutHorizontal="true"'
        '\n    android:gravity="center_vertical|start"'
    ),
}
ROOT_TAG = re.compile(r"<(?![?!/])([A-Za-z_][\w.\-]*)")

done = 0
for fname, drawable in TARGETS.items():
    path = os.path.join(res, "layout", fname)
    if not os.path.exists(path):
        print("PERINGATAN: res/layout/%s tidak ada, dilewati" % fname)
        continue
    s = read(path)
    if drawable in s:
        print(fname, "sudah dipatch")
        done += 1
        continue
    s = re.sub(r"<!--.*?-->", lambda m: " " * len(m.group(0)), s, flags=re.S)  # abaikan komentar saat mencari root
    orig = read(path)
    m = ROOT_TAG.search(s)
    if not m:
        die("elemen root tidak ditemukan di " + fname)
    tag = m.group(1)
    end = orig.index(">", m.end())
    print("  tag root asli:", " ".join(orig[m.start():end + 1].split()))
    head = re.sub(r'\s+android:background="[^"]*"', "", orig[m.end():end])
    orig = orig[: m.end()] + head + orig[end:]
    # sisipkan di AKHIR tag pembuka (setelah semua deklarasi xmlns), bukan tepat setelah nama tag
    end = orig.index(">", m.end())
    pos = end - 1 if orig[end - 1] == "/" else end
    add = '\n    android:background="@drawable/%s"' % drawable
    if fname in EXTRA:
        extra = EXTRA[fname]
        for line in extra.split("\n"):
            key = line.strip().split("=")[0]
            if key and key in orig[m.start():end + 1]:
                orig = re.sub(r'\s+%s="[^"]*"' % re.escape(key), "", orig)  # buang nilai lama
        end = orig.index(">", m.end())
        add += extra
        if "xmlns:launcher=" not in orig[m.start():end + 1]:
            add = '\n    xmlns:launcher="http://schemas.android.com/apk/res-auto"' + add
    # root app_icon.xml asli tidak mendeklarasikan namespace android: tambahkan bila belum ada
    if 'xmlns:android=' not in orig[m.start():end + 1]:
        add = '\n    xmlns:android="http://schemas.android.com/apk/res/android"' + add
        print('  xmlns:android ditambahkan ke root', fname)
    orig = orig[:pos].rstrip() + add + ("\n    " if pos != end else "") + orig[pos:]
    try:
        ET.fromstring(orig.encode("utf-8"))
    except ET.ParseError as e:
        die("%s tidak valid setelah dipatch: %s" % (fname, e))
    write(path, orig)
    print(fname, "dipatch (root <%s>) ->" % tag, drawable)
    done += 1

if done == 0:
    die("tidak ada layout ikon yang bisa dipatch")
print("patch tema selesai")
