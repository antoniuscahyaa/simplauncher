#!/usr/bin/env python3
"""Tahap 1 tema Simp -> Shady: kartu kaca di ikon homescreen dan app drawer.

Pemakaian: patch_theme.py <folder_decoded> <folder_patch>
Hanya menyentuh resource XML (tanpa smali). Gagal keras bila layout ikon tidak ada.
"""
import os
import re
import shutil
import sys

work, patch = sys.argv[1], sys.argv[2]
res = os.path.join(work, "res")


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


dd = os.path.join(res, "drawable")
os.makedirs(dd, exist_ok=True)
for name in ("home_card_bg.xml", "drawer_card_bg.xml"):
    shutil.copy(os.path.join(patch, name), os.path.join(dd, name))

# layout -> (drawable, padding dp). Padding menjaga isi tidak menempel ke tepi kartu.
TARGETS = {
    "app_icon.xml": ("home_card_bg", "4dp"),          # homescreen + hotseat
    "all_apps_icon.xml": ("drawer_card_bg", "4dp"),    # app drawer
}
TAG = r"<com\.android\.launcher3\.BubbleTextView\b"

for fname, (drawable, pad) in TARGETS.items():
    path = os.path.join(res, "layout", fname)
    if not os.path.exists(path):
        die("res/layout/%s tidak ada" % fname)
    s = read(path)
    if drawable in s:
        print(fname, "sudah dipatch")
        continue
    m = re.search(TAG, s)
    if not m:
        die("tag BubbleTextView tidak ditemukan di " + fname)
    # buang background lama (bila ada) pada tag ini saja
    end = s.index(">", m.end())
    head = re.sub(r'\s+android:background="[^"]*"', "", s[m.end():end])
    s = s[: m.end()] + head + s[end:]
    m = re.search(TAG, s)
    add = '\n    android:background="@drawable/%s"' % drawable
    s = s[: m.end()] + add + s[m.end():]
    write(path, s)
    print(fname, "dipatch ->", drawable)

print("patch tema selesai")
