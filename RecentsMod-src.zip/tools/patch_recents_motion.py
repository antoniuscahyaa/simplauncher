#!/usr/bin/env python3
"""Patch smali Recents: gerak buka vertikal, handle panah dihapus, Hapus semua di semua kartu.

Pemakaian: patch_recents_motion.py <folder_decoded>

Beberapa perubahan (semua idempoten, gagal keras bila pola smali tidak cocok):
 1. ScrimView.drawDragHandle -> tidak menggambar panah ke atas di dasar Recents.
 2. ScrimView.onTouchEvent   -> area handle tidak lagi menerima sentuhan (tombol tersembunyi).
 3. LauncherRecentsView.getOffscreenTranslationX -> tanpa geser horizontal saat Recents
    masuk/keluar lewat gesture swipe-up (itu sumber animasi "kiri ke kanan").
 4. LauncherActivityControllerHelper$2.setRecentsAttachedToAppWindow dan
    LauncherRecentsView.onStateTransitionStart -> memanggil simp.recents.RecentsMotion
    (animasi masuk/keluar vertikal; geser antar kartu tetap horizontal).
 4b. LauncherRecentsView.setTranslationX (override baru) -> RecentsView tidak digeser horizontal
    selama Overview (sumber animasi horizontal yang terlihat di layar).
 4c. RecentsView.isTaskViewVisible -> hanya kartu di tengah yang menerima swipe-up; kartu
    bertumpuk tidak lagi "mencuri" gesture dari kartu depan.
 5. ClearAllButton.onPageScroll -> alpha-scroll selalu 1, sehingga Hapus semua terlihat
    dan bisa diklik di semua kartu (bukan hanya di kartu paling kiri).
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_smali(class_path):
    hits = [p for d in glob.glob(os.path.join(work, "smali*"))
            for p in [os.path.join(d, class_path + ".smali")] if os.path.isfile(p)]
    if len(hits) != 1:
        die("smali %s ditemukan %d kali: %s" % (class_path, len(hits), class_path))
    return hits[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def method_span(src, header_regex, label):
    m = re.search(r"(?ms)^\.method " + header_regex + r"[^\n]*\n.*?^\.end method", src)
    if not m:
        die("method tidak ditemukan: " + label)
    return m


def patch(path, marker, header_regex, label, transform):
    src = read(path)
    if marker in src:
        print("sudah dipatch:", label)
        return
    m = method_span(src, header_regex, label)
    old = m.group(0)
    new = transform(old)
    if new == old:
        die("tidak berubah: " + label)
    write(path, src[:m.start()] + new + src[m.end():])
    print("dipatch:", label)


# ---- 1 + 2. handle panah ScrimView ---------------------------------------------
scrim = find_smali("com/android/launcher3/views/ScrimView")


def after_locals(insert):
    def t(method):
        mm = re.match(r"(\.method[^\n]*\n\s*\.locals \d+\n)", method)
        if not mm:
            die("pola .locals tidak cocok")
        return mm.group(1) + insert + method[mm.end():]
    return t


patch(scrim, "# simp: handle tidak digambar",
      r"protected drawDragHandle\(Landroid/graphics/Canvas;\)V",
      "ScrimView.drawDragHandle -> tidak menggambar",
      after_locals("\n    # simp: handle tidak digambar\n    return-void\n"))

patch(scrim, "# simp: handle tidak menerima sentuhan",
      r"public onTouchEvent\(Landroid/view/MotionEvent;\)Z",
      "ScrimView.onTouchEvent -> false",
      after_locals("\n    # simp: handle tidak menerima sentuhan\n    const/4 v0, 0x0\n\n    return v0\n"))

# ---- 3. tanpa geser horizontal ------------------------------------------------
lrv = find_smali("com/android/quickstep/views/LauncherRecentsView")

NEUTRAL = (
    ".method public getOffscreenTranslationX(F)F\n"
    "    .locals 1\n"
    "\n"
    "    # simp: tanpa geser horizontal; animasi masuk vertikal (RecentsMotion)\n"
    "    invoke-virtual {p0}, Lcom/android/quickstep/views/LauncherRecentsView;->getScrollOffset()F\n"
    "\n"
    "    move-result v0\n"
    "\n"
    "    return v0\n"
    ".end method"
)
patch(lrv, "# simp: tanpa geser horizontal",
      r"public getOffscreenTranslationX\(F\)F",
      "LauncherRecentsView.getOffscreenTranslationX -> netral",
      lambda m: NEUTRAL)

# ---- 4a. hook state transition (pembukaan dari Home/tombol) -----------------------
def hook_state(method):
    anchor = "    iget-boolean p1, p1, Lcom/android/launcher3/LauncherState;->overviewUi:Z\n"
    if method.count(anchor) != 1:
        die("onStateTransitionStart: anchor overviewUi tidak unik")
    call = ("    # simp: animasi masuk vertikal (kirim objek state)\n"
            "    invoke-static {p0, p1}, Lsimp/recents/RecentsMotion;->onStateStart"
            "(Landroid/view/ViewGroup;Ljava/lang/Object;)V\n\n")
    return method.replace(anchor, call + anchor)


patch(lrv, "RecentsMotion;->onStateStart",
      r"public onStateTransitionStart\(Lcom/android/launcher3/LauncherState;\)V",
      "LauncherRecentsView.onStateTransitionStart -> RecentsMotion",
      hook_state)

# ---- 4b'. override setTranslationX: RecentsView tidak digeser horizontal ------------------
SET_TX = (
    ".method public setTranslationX(F)V\n"
    "    .locals 1\n"
    "\n"
    "    # simp: RecentsView tidak digeser horizontal selama Overview\n"
    "    invoke-static {p0, p1}, Lsimp/recents/RecentsMotion;->filterTranslationX"
    "(Landroid/view/View;F)F\n"
    "\n"
    "    move-result v0\n"
    "\n"
    "    invoke-super {p0, v0}, Lcom/android/quickstep/views/RecentsView;->setTranslationX(F)V\n"
    "\n"
    "    return-void\n"
    ".end method\n"
    "\n"
)
src = read(lrv)
if "# simp: RecentsView tidak digeser horizontal" in src:
    print("sudah dipatch: LauncherRecentsView.setTranslationX")
else:
    if re.search(r"(?m)^\.method [^\n]* setTranslationX\(F\)V", src):
        die("LauncherRecentsView sudah punya setTranslationX; sesuaikan patch")
    mm = re.search(r"(?m)^\.method public setTranslationY\(F\)V", src)
    if not mm:
        die("anchor setTranslationY tidak ditemukan di LauncherRecentsView")
    write(lrv, src[:mm.start()] + SET_TX + src[mm.start():])
    print("dipatch: LauncherRecentsView.setTranslationX (override baru)")

# ---- 4c. hanya kartu tengah yang bisa di-swipe-up --------------------------------------
recents_smali = find_smali("com/android/quickstep/views/RecentsView")
VISIBLE = (
    ".method public isTaskViewVisible(Lcom/android/quickstep/views/TaskView;)Z\n"
    "    .locals 1\n"
    "\n"
    "    # simp: hanya kartu di tengah layar (kartu depan) yang dianggap bisa digeser\n"
    "    invoke-virtual {p0, p1}, Lcom/android/quickstep/views/RecentsView;->indexOfChild(Landroid/view/View;)I\n"
    "\n"
    "    move-result p1\n"
    "\n"
    "    invoke-virtual {p0}, Lcom/android/quickstep/views/RecentsView;->getPageNearestToCenterOfScreen()I\n"
    "\n"
    "    move-result v0\n"
    "\n"
    "    if-ne p1, v0, :cond_0\n"
    "\n"
    "    const/4 v0, 0x1\n"
    "\n"
    "    goto :goto_0\n"
    "\n"
    "    :cond_0\n"
    "    const/4 v0, 0x0\n"
    "\n"
    "    :goto_0\n"
    "    return v0\n"
    ".end method"
)
patch(recents_smali, "# simp: hanya kartu di tengah layar",
      r"public isTaskViewVisible\(Lcom/android/quickstep/views/TaskView;\)Z",
      "RecentsView.isTaskViewVisible -> hanya kartu tengah",
      lambda m: VISIBLE)

# ---- 4b. hook attach/detach saat gesture ------------------------------------------
helper = find_smali("com/android/quickstep/LauncherActivityControllerHelper$2")


def hook_attach(method):
    anchor = "    check-cast v0, Lcom/android/quickstep/views/LauncherRecentsView;\n"
    if method.count(anchor) != 1:
        die("setRecentsAttachedToAppWindow: anchor check-cast tidak unik (%d)" % method.count(anchor))
    call = ("\n    # simp: animasi masuk/keluar vertikal\n"
            "    invoke-static {v0, p1, p2}, Lsimp/recents/RecentsMotion;->onAttach"
            "(Landroid/view/ViewGroup;ZZ)V\n")
    return method.replace(anchor, anchor + call)


patch(helper, "RecentsMotion;->onAttach",
      r"public setRecentsAttachedToAppWindow\(ZZ\)V",
      "setRecentsAttachedToAppWindow -> RecentsMotion",
      hook_attach)

# ---- 5. Hapus semua terlihat di semua kartu ------------------------------------------
clear_all = find_smali("com/android/quickstep/views/ClearAllButton")


def always_visible(method):
    anchor = "    iput v1, p0, Lcom/android/quickstep/views/ClearAllButton;->mScrollAlpha:F\n"
    if method.count(anchor) != 1:
        die("ClearAllButton.onPageScroll: anchor mScrollAlpha tidak unik")
    force = "    # simp: Hapus semua selalu terlihat\n    const/high16 v1, 0x3f800000    # 1.0f\n\n"
    return method.replace(anchor, force + anchor)


patch(clear_all, "# simp: Hapus semua selalu terlihat",
      r"public onPageScroll\(Lcom/android/quickstep/views/RecentsView\$ScrollState;\)V",
      "ClearAllButton.onPageScroll -> alpha-scroll 1",
      always_visible)

print("patch_recents_motion selesai")
