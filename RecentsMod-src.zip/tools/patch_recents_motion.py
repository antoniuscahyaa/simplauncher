#!/usr/bin/env python3
"""Patch smali Recents: gerak buka vertikal, handle panah dihapus, Hapus semua di semua kartu.

Pemakaian: patch_recents_motion.py <folder_decoded>

Beberapa perubahan (semua idempoten, gagal keras bila pola smali tidak cocok):
 1. ScrimView.drawDragHandle -> tidak menggambar panah ke atas di dasar Recents.
 2. ScrimView.onTouchEvent   -> area handle tidak lagi menerima sentuhan (tombol tersembunyi).
 3. getOffscreenTranslationX = 0, UiFactory.getOverviewScaleAndTranslationForNormalState = di bawah
    layar (mode gesture memakai posisi di luar layar sisi kanan = lebar - paddingStart; itu sumber
    animasi "dari samping") dan attach ke jendela aplikasi disesuaikan.
 4. LauncherActivityControllerHelper$2.setRecentsAttachedToAppWindow dan
    LauncherRecentsView.onStateTransitionStart -> memanggil simp.recents.RecentsMotion
    (animasi masuk/keluar vertikal; geser antar kartu tetap horizontal).
 4b. LauncherRecentsView.setTranslationX (override baru) -> RecentsView tidak digeser horizontal
    selama Overview (sumber animasi horizontal yang terlihat di layar).
 4c. RecentsView.isTaskViewVisible -> hanya kartu di tengah yang menerima swipe-up; kartu
    bertumpuk tidak lagi "mencuri" gesture dari kartu depan.
 5. ClearAllButton.onPageScroll -> alpha-scroll selalu 1, sehingga Hapus semua terlihat
    dan bisa diklik di semua kartu (bukan hanya di kartu paling kiri).
 6. Animasi jendela aplikasi berbasis kartu, bukan ikon (icon pack):
    6a. swipe ke Home: jendela menyusut ke persegi berbentuk kartu di tengah layar.
    6b. buka aplikasi dari ikon (Home/laci/folder/dock): jendela membesar dari kartu di tengah layar.
        Buka dari kartu Recents tidak berubah (sudah berbasis kartu).
"""
import glob
import os
import re
import sys

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_smali(class_path):
    hits = [p for d in glob.glob(os.path.join(work, "smali*"))
            for p in [os.path.join(d, class_path + ".smali")] if os.path.isfile(p)]
    if len(hits) != 1:
        die("smali %s ditemukan %d kali: %s" % (class_path, len(hits), class_path))
    return hits[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def method_span(src, header_regex, label):
    m = re.search(r"(?ms)^\.method " + header_regex + r"[^\n]*\n.*?^\.end method", src)
    if not m:
        die("method tidak ditemukan: " + label)
    return m


def patch(path, marker, header_regex, label, transform):
    src = read(path)
    if marker in src:
        print("sudah dipatch:", label)
        return
    m = method_span(src, header_regex, label)
    old = m.group(0)
    new = transform(old)
    if new == old:
        die("tidak berubah: " + label)
    write(path, src[:m.start()] + new + src[m.end():])
    print("dipatch:", label)


# ---- 1 + 2. handle panah ScrimView ---------------------------------------------
scrim = find_smali("com/android/launcher3/views/ScrimView")


def after_locals(insert):
    def t(method):
        mm = re.match(r"(\.method[^\n]*\n\s*\.locals \d+\n)", method)
        if not mm:
            die("pola .locals tidak cocok")
        return mm.group(1) + insert + method[mm.end():]
    return t


patch(scrim, "# simp: handle tidak digambar",
      r"protected drawDragHandle\(Landroid/graphics/Canvas;\)V",
      "ScrimView.drawDragHandle -> tidak menggambar",
      after_locals("\n    # simp: handle tidak digambar\n    return-void\n"))

patch(scrim, "# simp: handle tidak menerima sentuhan",
      r"public onTouchEvent\(Landroid/view/MotionEvent;\)Z",
      "ScrimView.onTouchEvent -> false",
      after_locals("\n    # simp: handle tidak menerima sentuhan\n    const/4 v0, 0x0\n\n    return v0\n"))

# ---- 3. tanpa geser horizontal ------------------------------------------------
lrv = find_smali("com/android/quickstep/views/LauncherRecentsView")

NEUTRAL = (
    ".method public getOffscreenTranslationX(F)F\n"
    "    .locals 1\n"
    "\n"
    "    # simp: tanpa geser horizontal; animasi masuk vertikal (RecentsMotion)\n"
    "    const/4 v0, 0x0\n"
    "\n"
    "    return v0\n"
    ".end method"
)
patch(lrv, "# simp: tanpa geser horizontal",
      r"public getOffscreenTranslationX\(F\)F",
      "LauncherRecentsView.getOffscreenTranslationX -> 0",
      lambda m: NEUTRAL)

# ---- 3b. attach ke jendela aplikasi: awal/akhir translasi dikurangi scrollOffset; karena
# getOffscreenTranslationX kini 0, samakan dengan scrollOffset agar hasilnya tetap 0.
helper_attach = find_smali("com/android/quickstep/LauncherActivityControllerHelper$2")


def attach_zero(method):
    anchor = ("    invoke-virtual {v0, v3}, Lcom/android/quickstep/views/LauncherRecentsView;"
              "->getOffscreenTranslationX(F)F\n\n    move-result v3\n")
    if method.count(anchor) != 1:
        die("setRecentsAttachedToAppWindow: anchor getOffscreenTranslationX tidak unik")
    return method.replace(anchor, anchor + "\n    # simp: translasi attach = 0 (v5 = scrollOffset)\n    move v3, v5\n")


patch(helper_attach, "# simp: translasi attach = 0",
      r"public setRecentsAttachedToAppWindow\(ZZ\)V",
      "setRecentsAttachedToAppWindow -> translasi 0",
      attach_zero)

# ---- 3c. posisi Recents di state Home (NORMAL): di bawah layar, bukan di sisi kanan ------
# Mode gesture menaruh Recents di luar layar sisi kanan (translationX = lebar - paddingStart);
# semua transisi masuk meluncur dari sana. Diganti translationY = tinggi layar, sehingga animasi
# bawaan Launcher menaikkan Recents dari bawah (sinkron dengan jari) dan Recents tetap
# tersembunyi di luar layar saat Home.
ui_factory = find_smali("com/android/launcher3/uioverrides/UiFactory")
NORMAL_BELOW = (
    ".method public static getOverviewScaleAndTranslationForNormalState(Lcom/android/launcher3/Launcher;)Lcom/android/launcher3/LauncherState$ScaleAndTranslation;\n"
    "    .locals 4\n"
    "\n"
    "    # simp: Recents di state Home berada di bawah layar; masuk dari bawah ke atas\n"
    "    invoke-virtual {p0}, Lcom/android/launcher3/Launcher;->getDeviceProfile()Lcom/android/launcher3/DeviceProfile;\n"
    "\n"
    "    move-result-object v0\n"
    "\n"
    "    iget v0, v0, Lcom/android/launcher3/DeviceProfile;->heightPx:I\n"
    "\n"
    "    int-to-float v0, v0\n"
    "\n"
    "    new-instance v1, Lcom/android/launcher3/LauncherState$ScaleAndTranslation;\n"
    "\n"
    "    const/high16 v2, 0x3f800000    # 1.0f\n"
    "\n"
    "    const/4 v3, 0x0\n"
    "\n"
    "    invoke-direct {v1, v2, v3, v0}, Lcom/android/launcher3/LauncherState$ScaleAndTranslation;-><init>(FFF)V\n"
    "\n"
    "    return-object v1\n"
    ".end method"
)
patch(ui_factory, "# simp: Recents di state Home berada di bawah layar",
      r"public static getOverviewScaleAndTranslationForNormalState\(Lcom/android/launcher3/Launcher;\)Lcom/android/launcher3/LauncherState\$ScaleAndTranslation;",
      "UiFactory.getOverviewScaleAndTranslationForNormalState -> di bawah layar",
      lambda m: NORMAL_BELOW)

# ---- 4a. hook state transition (pembukaan dari Home/tombol) -----------------------
def hook_state(method):
    anchor = "    iget-boolean p1, p1, Lcom/android/launcher3/LauncherState;->overviewUi:Z\n"
    if method.count(anchor) != 1:
        die("onStateTransitionStart: anchor overviewUi tidak unik")
    call = ("    # simp: animasi masuk vertikal (kirim objek state)\n"
            "    invoke-static {p0, p1}, Lsimp/recents/RecentsMotion;->onStateStart"
            "(Landroid/view/ViewGroup;Ljava/lang/Object;)V\n\n")
    return method.replace(anchor, call + anchor)


patch(lrv, "RecentsMotion;->onStateStart",
      r"public onStateTransitionStart\(Lcom/android/launcher3/LauncherState;\)V",
      "LauncherRecentsView.onStateTransitionStart -> RecentsMotion",
      hook_state)

# ---- 4b'. override setTranslationX: RecentsView tidak digeser horizontal ------------------
SET_TX = (
    ".method public setTranslationX(F)V\n"
    "    .locals 1\n"
    "\n"
    "    # simp: RecentsView tidak digeser horizontal selama Overview\n"
    "    invoke-static {p0, p1}, Lsimp/recents/RecentsMotion;->filterTranslationX"
    "(Landroid/view/View;F)F\n"
    "\n"
    "    move-result v0\n"
    "\n"
    "    invoke-super {p0, v0}, Lcom/android/quickstep/views/RecentsView;->setTranslationX(F)V\n"
    "\n"
    "    return-void\n"
    ".end method\n"
    "\n"
)
src = read(lrv)
if "# simp: RecentsView tidak digeser horizontal" in src:
    print("sudah dipatch: LauncherRecentsView.setTranslationX")
else:
    if re.search(r"(?m)^\.method [^\n]* setTranslationX\(F\)V", src):
        die("LauncherRecentsView sudah punya setTranslationX; sesuaikan patch")
    mm = re.search(r"(?m)^\.method public setTranslationY\(F\)V", src)
    if not mm:
        die("anchor setTranslationY tidak ditemukan di LauncherRecentsView")
    write(lrv, src[:mm.start()] + SET_TX + src[mm.start():])
    print("dipatch: LauncherRecentsView.setTranslationX (override baru)")

# ---- 4c. hanya kartu tengah yang bisa di-swipe-up -------------------------------------
# isTaskViewVisible (+-1 dari halaman aktif) tetap dipakai logika lain (mis. memilih animasi
# buka aplikasi dari kartu). Untuk swipe-up membuang kartu dibuat metode baru yang hanya
# meluluskan kartu paling dekat tengah layar, lalu TaskViewTouchController diarahkan ke sana.
recents_smali = find_smali("com/android/quickstep/views/RecentsView")
FRONT_CARD = (
    ".method public isTaskViewFrontCard(Lcom/android/quickstep/views/TaskView;)Z\n"
    "    .locals 1\n"
    "\n"
    "    # simp: hanya kartu di tengah layar (kartu depan) yang bisa digeser\n"
    "    invoke-virtual {p0, p1}, Lcom/android/quickstep/views/RecentsView;->indexOfChild(Landroid/view/View;)I\n"
    "\n"
    "    move-result p1\n"
    "\n"
    "    invoke-virtual {p0}, Lcom/android/quickstep/views/RecentsView;->getPageNearestToCenterOfScreen()I\n"
    "\n"
    "    move-result v0\n"
    "\n"
    "    if-ne p1, v0, :cond_0\n"
    "\n"
    "    const/4 v0, 0x1\n"
    "\n"
    "    goto :goto_0\n"
    "\n"
    "    :cond_0\n"
    "    const/4 v0, 0x0\n"
    "\n"
    "    :goto_0\n"
    "    return v0\n"
    ".end method\n"
    "\n"
)
src = read(recents_smali)
if "isTaskViewFrontCard" in src:
    print("sudah dipatch: RecentsView.isTaskViewFrontCard")
else:
    mm = re.search(r"(?m)^\.method public isTaskViewVisible\(", src)
    if not mm:
        die("anchor isTaskViewVisible tidak ditemukan")
    write(recents_smali, src[:mm.start()] + FRONT_CARD + src[mm.start():])
    print("dipatch: RecentsView.isTaskViewFrontCard (metode baru)")

touch = find_smali("com/android/launcher3/uioverrides/touchcontrollers/TaskViewTouchController")
src = read(touch)
old_call = "Lcom/android/quickstep/views/RecentsView;->isTaskViewVisible(Lcom/android/quickstep/views/TaskView;)Z"
new_call = "Lcom/android/quickstep/views/RecentsView;->isTaskViewFrontCard(Lcom/android/quickstep/views/TaskView;)Z"
if new_call in src:
    print("sudah dipatch: TaskViewTouchController -> isTaskViewFrontCard")
else:
    if src.count(old_call) != 1:
        die("TaskViewTouchController: pemanggilan isTaskViewVisible = %d (harus 1)" % src.count(old_call))
    write(touch, src.replace(old_call, new_call))
    print("dipatch: TaskViewTouchController -> isTaskViewFrontCard")

# Kartu yang diketuk selalu memakai animasi buka dari kartu (bukan jatuh ke animasi ikon),
# apa pun posisinya di tumpukan.
tvu = find_smali("com/android/quickstep/TaskViewUtils")
src = read(tvu)
if "# simp: kartu yang diketuk selalu dianimasikan dari kartunya" in src:
    print("sudah dipatch: TaskViewUtils.findTaskViewToLaunch")
else:
    m = method_span(src, r"public static findTaskViewToLaunch\(", "TaskViewUtils.findTaskViewToLaunch")
    body = m.group(0)
    pat = re.compile(r"    if-eqz p0, :cond_0\s+goto :goto_0\n")
    if len(pat.findall(body)) != 1:
        die("findTaskViewToLaunch: pola cabang visibilitas tidak cocok")
    body2 = pat.sub("    # simp: kartu yang diketuk selalu dianimasikan dari kartunya\n    goto :goto_0\n", body, count=1)
    write(tvu, src[:m.start()] + body2 + src[m.end():])
    print("dipatch: TaskViewUtils.findTaskViewToLaunch")

# ---- 4d. swipe ke Home: jendela tidak menyusut ke ikon aplikasi di Home -----------------------
HOME_ICON_ANIMATION = False   # True = perilaku bawaan (menyusut ke ikon)
if not HOME_ICON_ANIMATION:
    ctl = find_smali("com/android/quickstep/LauncherActivityControllerHelper")
    src = read(ctl)
    if "# simp: tanpa ikon saat swipe ke Home" in src:
        print("sudah dipatch: swipe ke Home tanpa ikon")
    else:
        anchor = ("    invoke-virtual {v2, v3, v0}, Lcom/android/launcher3/Workspace;->getFirstMatchForAppClose"
                  "(Ljava/lang/String;Landroid/os/UserHandle;)Landroid/view/View;\n\n    move-result-object v0\n")
        if src.count(anchor) != 1:
            die("LauncherActivityControllerHelper: anchor getFirstMatchForAppClose tidak unik (%d)" % src.count(anchor))
        src = src.replace(anchor, anchor + "\n    # simp: tanpa ikon saat swipe ke Home\n    const/4 v0, 0x0\n")
        write(ctl, src)
        print("dipatch: swipe ke Home tanpa ikon")

# ---- 6a. swipe ke Home: target jendela = kartu di tengah layar ---------------------------
# Tanpa ikon Home (4d) Launcher memakai getDefaultWindowTargetRect: kotak seukuran ikon di dekat
# hotseat, jadi jendela tetap tampak menyusut ke "ikon". Diganti persegi panjang berbentuk kartu.
if not HOME_ICON_ANIMATION:
    home_factory = find_smali("com/android/quickstep/LauncherActivityControllerHelper$1")
    src = read(home_factory)
    if "RecentsMotion;->cardTargetRect" in src:
        print("sudah dipatch: swipe ke Home -> target kartu")
    else:
        old_call = ("invoke-static {v0}, Lcom/android/quickstep/ActivityControlHelper$HomeAnimationFactory;"
                    "->getDefaultWindowTargetRect(Lcom/android/launcher3/DeviceProfile;)Landroid/graphics/RectF;")
        new_call = ("invoke-static {v0}, Lsimp/recents/RecentsMotion;->cardTargetRect"
                    "(Ljava/lang/Object;)Landroid/graphics/RectF;")
        if src.count(old_call) != 1:
            die("HomeAnimationFactory.getWindowTargetRect: getDefaultWindowTargetRect = %d (harus 1)" % src.count(old_call))
        write(home_factory, src.replace(old_call, new_call))
        print("dipatch: swipe ke Home -> target kartu")

# ---- 6b. buka aplikasi dari ikon: animasi scale-up dari kartu, tanpa FloatingIconView -------------
CARD_LAUNCH_FROM_ICON = True   # False = perilaku bawaan (membesar dari ikon, icon pack)
if CARD_LAUNCH_FROM_ICON:
    qatm = find_smali("com/android/launcher3/QuickstepAppTransitionManagerImpl")
    src = read(qatm)
    if "# simp: buka dari ikon -> animasi kartu" in src:
        print("sudah dipatch: buka aplikasi dari ikon -> kartu")
    else:
        m = method_span(src, r"public getActivityLaunchOptions\(Lcom/android/launcher3/Launcher;Landroid/view/View;\)Landroid/app/ActivityOptions;",
                        "QuickstepAppTransitionManagerImpl.getActivityLaunchOptions")
        body = m.group(0)
        pat = re.compile(r"(    invoke-virtual \{p0, p2, p1\}, Lcom/android/launcher3/QuickstepAppTransitionManagerImpl;"
                         r"->isLaunchingFromRecents\(Landroid/view/View;\[Lcom/android/systemui/shared/system/RemoteAnimationTargetCompat;\)Z\s+"
                         r"move-result p1\n)")
        if len(pat.findall(body)) != 1:
            die("getActivityLaunchOptions: pola isLaunchingFromRecents tidak cocok (%d)" % len(pat.findall(body)))
        insert = (
            "\n    # simp: buka dari ikon -> animasi kartu (scale-up sistem, tanpa FloatingIconView)\n"
            "    if-nez p1, :simp_launch_from_recents\n"
            "\n"
            "    invoke-static {p2}, Lsimp/recents/RecentsMotion;->cardLaunchOptions(Landroid/view/View;)Landroid/app/ActivityOptions;\n"
            "\n"
            "    move-result-object v0\n"
            "\n"
            "    if-eqz v0, :simp_launch_from_recents\n"
            "\n"
            "    return-object v0\n"
            "\n"
            "    :simp_launch_from_recents\n"
        )
        body2 = pat.sub(lambda mm: mm.group(1) + insert, body, count=1)
        write(qatm, src[:m.start()] + body2 + src[m.end():])
        print("dipatch: buka aplikasi dari ikon -> kartu")

# ---- 4b. hook attach/detach saat gesture ------------------------------------------
helper = find_smali("com/android/quickstep/LauncherActivityControllerHelper$2")


def hook_attach(method):
    anchor = "    check-cast v0, Lcom/android/quickstep/views/LauncherRecentsView;\n"
    if method.count(anchor) != 1:
        die("setRecentsAttachedToAppWindow: anchor check-cast tidak unik (%d)" % method.count(anchor))
    call = ("\n    # simp: animasi masuk/keluar vertikal\n"
            "    invoke-static {v0, p1, p2}, Lsimp/recents/RecentsMotion;->onAttach"
            "(Landroid/view/ViewGroup;ZZ)V\n")
    return method.replace(anchor, anchor + call)


patch(helper, "RecentsMotion;->onAttach",
      r"public setRecentsAttachedToAppWindow\(ZZ\)V",
      "setRecentsAttachedToAppWindow -> RecentsMotion",
      hook_attach)

# ---- 5. Hapus semua terlihat di semua kartu ------------------------------------------
clear_all = find_smali("com/android/quickstep/views/ClearAllButton")


def always_visible(method):
    anchor = "    iput v1, p0, Lcom/android/quickstep/views/ClearAllButton;->mScrollAlpha:F\n"
    if method.count(anchor) != 1:
        die("ClearAllButton.onPageScroll: anchor mScrollAlpha tidak unik")
    force = "    # simp: Hapus semua selalu terlihat\n    const/high16 v1, 0x3f800000    # 1.0f\n\n"
    return method.replace(anchor, force + anchor)


patch(clear_all, "# simp: Hapus semua selalu terlihat",
      r"public onPageScroll\(Lcom/android/quickstep/views/RecentsView\$ScrollState;\)V",
      "ClearAllButton.onPageScroll -> alpha-scroll 1",
      always_visible)

print("patch_recents_motion selesai")
