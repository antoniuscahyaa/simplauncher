#!/usr/bin/env python3
"""Tahap 3 tema Simp -> Shady: homescreen memakai logika grid SimpLauncher, dock dihapus.

Pemakaian: patch_home_grid.py <folder_decoded>
Tiga perubahan (semua gagal keras bila pola tidak ditemukan tepat sekali):
  1. res/xml/device_profiles.xml: numColumns=3, numRows=4 (numHotseatIcons tidak diubah, supaya kode
     hotseat/default layout tetap konsisten).
  2. smali DeviceProfile.updateWorkspacePadding: di akhir method panggil simp.home.HomeLayout.adjust(...)
     -> grid 3x4 menempel di bawah, tinggi sel = kartu + jarak (sama seperti HomeGrid di SimpLauncher).
  3. smali Hotseat: override setVisibility -> selalu GONE (dock hilang, tidak mengambil ruang, tidak bisa
     dijatuhi ikon). Data hotseat lama tetap ada di database, hanya tidak ditampilkan.
Konstanta kolom/baris: COLS, ROWS di bawah.
"""
import glob
import os
import re
import sys

COLS = 3
ROWS = 4

work = sys.argv[1]


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def find_one(rel):
    c = [p for d in glob.glob(os.path.join(work, "smali*")) for p in [os.path.join(d, rel)] if os.path.isfile(p)]
    if len(c) != 1:
        die("%s ditemukan %d (butuh tepat 1)" % (rel, len(c)))
    return c[0]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1. device_profiles.xml ----
xml = os.path.join(work, "res", "xml", "device_profiles.xml")
if not os.path.isfile(xml):
    die("res/xml/device_profiles.xml tidak ada")
s = read(xml)
n_cols = len(re.findall(r'launcher:numColumns="\d+"', s))
n_rows = len(re.findall(r'launcher:numRows="\d+"', s))
if n_cols == 0 or n_cols != n_rows:
    die("device_profiles.xml: numColumns=%d numRows=%d tidak cocok" % (n_cols, n_rows))
s = re.sub(r'launcher:numColumns="\d+"', 'launcher:numColumns="%d"' % COLS, s)
s = re.sub(r'launcher:numRows="\d+"', 'launcher:numRows="%d"' % ROWS, s)
write(xml, s)
print("device_profiles.xml: %d grid-option -> %dx%d" % (n_cols, COLS, ROWS))

# ---- 2. DeviceProfile.updateWorkspacePadding ----
dp = find_one("com/android/launcher3/DeviceProfile.smali")
src = read(dp)
if "Lsimp/home/HomeLayout;" in src:
    print("DeviceProfile sudah dipatch")
else:
    m = list(re.finditer(r"(?ms)^\.method private updateWorkspacePadding\(\)V\n.*?^\.end method", src))
    if len(m) != 1:
        die("updateWorkspacePadding muncul %d kali (butuh 1)" % len(m))
    body = m[0].group(0)
    if int(re.search(r"\.locals (\d+)", body).group(1)) < 5:
        die("updateWorkspacePadding: .locals < 5, register sementara tidak cukup")
    tail = "    :goto_0\n    return-void\n.end method"
    if body.count(tail) != 1:
        die("akhir updateWorkspacePadding tidak sesuai pola (:goto_0 / return-void)")
    D = "Lcom/android/launcher3/DeviceProfile;"
    hook = (
        "    :goto_0\n"
        "    iget v1, p0, %s->heightPx:I\n\n"
        "    invoke-virtual {p0}, %s->getInsets()Landroid/graphics/Rect;\n\n"
        "    move-result-object v2\n\n"
        "    iget-object v3, p0, %s->inv:Lcom/android/launcher3/InvariantDeviceProfile;\n\n"
        "    iget v3, v3, Lcom/android/launcher3/InvariantDeviceProfile;->numRows:I\n\n"
        "    invoke-virtual {p0}, %s->isVerticalBarLayout()Z\n\n"
        "    move-result v4\n\n"
        "    invoke-static {v0, v1, v2, v3, v4}, Lsimp/home/HomeLayout;->adjust(Landroid/graphics/Rect;ILandroid/graphics/Rect;IZ)V\n\n"
        "    return-void\n.end method"
    ) % (D, D, D, D)
    body = body.replace(tail, hook)
    src = src[: m[0].start()] + body + src[m[0].end():]
    write(dp, src)
    print("smali dipatch: DeviceProfile.updateWorkspacePadding -> HomeLayout.adjust")

# ---- 3. Hotseat.setVisibility -> GONE ----
hs = find_one("com/android/launcher3/Hotseat.smali")
src = read(hs)
if ".method public setVisibility(I)V" in src:
    print("Hotseat sudah dipatch")
else:
    marker = ".method public setInsets(Landroid/graphics/Rect;)V"
    if src.count(marker) != 1:
        die("Hotseat.setInsets muncul %d kali (butuh 1)" % src.count(marker))
    override = (
        ".method public setVisibility(I)V\n"
        "    .locals 1\n\n"
        "    const/16 p1, 0x8\n\n"
        "    invoke-super {p0, p1}, Lcom/android/launcher3/CellLayout;->setVisibility(I)V\n\n"
        "    return-void\n"
        ".end method\n\n"
    )
    src = src.replace(marker, override + marker)
    write(hs, src)
    print("smali dipatch: Hotseat.setVisibility -> selalu GONE")
print("patch grid selesai")
