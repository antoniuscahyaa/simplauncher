#!/usr/bin/env python3
"""Salin APK hasil apktool dan tambahkan dex baru sebagai classes<N+1>.dex.

Pemakaian: inject_dex.py <apk_masuk> <dex_baru> <apk_keluar>
Tanda tangan lama (META-INF/*.RSA|SF|MF) dibuang; tanda tangan baru dibuat setelahnya.
"""
import re
import sys
import zipfile

src, dex, out = sys.argv[1:4]

with zipfile.ZipFile(src) as zin:
    names = zin.namelist()
    nums = [1]
    for n in names:
        m = re.fullmatch(r"classes(\d*)\.dex", n)
        if m:
            nums.append(int(m.group(1) or 1))
    new_name = "classes%d.dex" % (max(nums) + 1)
    print("dex baru ->", new_name, "(sudah ada:", sorted(n for n in names if n.endswith(".dex")), ")")
    with zipfile.ZipFile(out, "w") as zout:
        for info in zin.infolist():
            n = info.filename
            if n.startswith("META-INF/") and re.search(r"\.(RSA|SF|MF|DSA|EC)$", n):
                continue
            data = zin.read(n)
            zi = zipfile.ZipInfo(n, date_time=(2009, 1, 1, 0, 0, 0))
            zi.compress_type = info.compress_type
            zi.external_attr = info.external_attr
            zout.writestr(zi, data)
        with open(dex, "rb") as f:
            zi = zipfile.ZipInfo(new_name, date_time=(2009, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(zi, f.read())
print("selesai:", out)
