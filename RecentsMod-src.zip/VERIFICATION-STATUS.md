# Verification status — carousel compile fix

## Source log diagnosis
The supplied GitHub Actions log (`logs_118833461098.zip`) reports exactly three Java compiler errors in `src/simp/recents/RecentsStackCarousel.java` at lines 79, 84, and 89. All three are unresolved calls to `originalAlpha(View)`.

## Fix applied
Added `originalAlpha(View)`, backed by the existing `WeakHashMap<View, Float> ORIGINAL_ALPHA`. The helper captures each TaskView's initial Launcher-provided alpha once, then reuses it when applying the stack dimming factors. This prevents repeated carousel updates from progressively reducing alpha.

## Checks completed
- `javac` compilation of `RecentsStackCarousel.java` against minimal Android API stubs: passed.
- `python3 -m py_compile` for `tools/patch.py` and `tools/inject_dex.py`: passed.
- `bash -n build.sh`: passed.
- ZIP integrity (`unzip -t`): passed.

## Not yet verified
A full APK build has not been run in this environment. The project build script requires an installed Android SDK (`ANDROID_HOME` or `ANDROID_SDK_ROOT`), Android build-tools, `android.jar`, Apktool, and signing-key download access. Therefore this ZIP is a source fix, not a rebuilt or device-tested APK.

## Next validation
Run the repository's GitHub Actions workflow with this ZIP as the source input. If a new error appears after Java compilation proceeds, provide that fresh log for the next diagnosis.
