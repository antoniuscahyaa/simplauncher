#!/usr/bin/env python3
"""Terapkan patch tampilan Recents ke hasil `apktool d` (folder decoded).

Pemakaian: patch.py <folder_decoded> <folder_patch>
Gagal keras (exit 1) bila bagian penting tidak ditemukan, supaya build tidak
menghasilkan APK yang setengah jadi.
"""
import glob
import os
import re
import shutil
import sys

work, patch = sys.argv[1], sys.argv[2]
res = os.path.join(work, "res")

# Nilai yang diubah (dp). Header kartu 28dp, ikon asli dikecilkan hingga tak terlihat.
DIMENS = {
    "task_thumbnail_top_margin": "28.0dip",
    "task_thumbnail_icon_size": "1.0dip",
}
SIDE_MARGIN = "9dp"  # padding kiri/kanan/bawah thumbnail di dalam bingkai kaca


def die(msg):
    print("GAGAL:", msg)
    sys.exit(1)


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


# ---- 1. dimens -------------------------------------------------------------
found = {k: 0 for k in DIMENS}
for path in glob.glob(os.path.join(res, "values*", "*.xml")):
    s = read(path)
    new = s
    for name, val in DIMENS.items():
        pat = re.compile(r'(<dimen\b[^>]*\bname="%s"[^>]*>)([^<]*)(</dimen>)' % re.escape(name))

        def sub(m, val=val, name=name):
            found[name] += 1
            print("dimen %s: %s -> %s  (%s)" % (name, m.group(2), val, os.path.relpath(path, work)))
            return m.group(1) + val + m.group(3)

        new = pat.sub(sub, new)
    if new != s:
        write(path, new)
for name, n in found.items():
    if n == 0:
        die("dimen %s tidak ditemukan" % name)

# ---- 2. drawable baru ------------------------------------------------------
dd = os.path.join(res, "drawable")
os.makedirs(dd, exist_ok=True)
shutil.copy(os.path.join(patch, "task_glass_bg.xml"), os.path.join(dd, "task_glass_bg.xml"))
shutil.copy(os.path.join(patch, "clear_all_bg.xml"), os.path.join(dd, "clear_all_bg.xml"))

# ---- 3. layout task.xml ----------------------------------------------------
task_path = os.path.join(res, "layout", "task.xml")
if not os.path.exists(task_path):
    die("res/layout/task.xml tidak ada")
t = read(task_path)

ROOT = "com.android.quickstep.views.TaskView"
THUMB = "com.android.quickstep.views.TaskThumbnailView"

if "task_glass_bg" in t:
    die("task.xml sudah dipatch (jalankan dari hasil decode yang bersih)")

# bingkai kaca di root
m = re.search(r"<%s\b" % re.escape(ROOT), t)
if not m:
    die("tag root TaskView tidak ditemukan")
t = t[: m.end()] + '\n    android:background="@drawable/task_glass_bg"' + t[m.end():]

# margin thumbnail
m = re.search(r"<%s\b" % re.escape(THUMB), t)
if not m:
    die("tag TaskThumbnailView tidak ditemukan")
ins = (
    '\n    android:layout_marginStart="%s"'
    '\n    android:layout_marginEnd="%s"'
    '\n    android:layout_marginBottom="%s"' % (SIDE_MARGIN, SIDE_MARGIN, SIDE_MARGIN)
)
t = t[: m.end()] + ins + t[m.end():]

# label di paling atas (terakhir = paling depan)
label = (
    '    <simp.recents.TaskLabelView\n'
    '        android:layout_width="match_parent"\n'
    '        android:layout_height="@dimen/task_thumbnail_top_margin"\n'
    '        android:layout_gravity="top|start"\n'
    '        android:paddingStart="12dp"\n'
    '        android:paddingEnd="12dp" />\n'
)
close = "</%s>" % ROOT
idx = t.rfind(close)
if idx < 0:
    die("penutup root TaskView tidak ditemukan")
t = t[:idx] + label + t[idx:]
write(task_path, t)
print("task.xml dipatch")

# ---- 4. tombol Hapus semua ---------------------------------------------------
ca_path = os.path.join(res, "layout", "overview_clear_all_button.xml")
if os.path.exists(ca_path):
    c = read(ca_path)
    m = re.search(r"<com\.android\.quickstep\.views\.ClearAllButton\b", c)
    if m and "clear_all_bg" not in c:
        c = re.sub(r'\s+android:textColor="[^"]*"', "", c)
        m = re.search(r"<com\.android\.quickstep\.views\.ClearAllButton\b", c)
        add = (
            '\n    android:background="@drawable/clear_all_bg"'
            '\n    android:textColor="#FF14243A"'
            '\n    android:paddingStart="20dp"'
            '\n    android:paddingEnd="20dp"'
            '\n    android:minHeight="40dp"'
        )
        c = c[: m.end()] + add + c[m.end():]
        write(ca_path, c)
        print("overview_clear_all_button.xml dipatch")
    else:
        print("PERINGATAN: ClearAllButton tidak dipatch")
else:
    print("PERINGATAN: overview_clear_all_button.xml tidak ada")

print("patch selesai")
