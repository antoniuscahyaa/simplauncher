package simp.recents;

import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;

/**
 * Label nama aplikasi di header kartu Recents (rata kiri, tanpa ikon) dengan satu tombol
 * dropdown di kanan. Tombol membuka baris opsi (App info, Split screen, Kill, ...) yang
 * menutupi bagian atas pratinjau; label dan ikon opsi diambil dari shortcut bawaan launcher
 * sehingga otomatis mengikuti bahasa sistem.
 * Tidak memakai class hidden secara langsung: semua lewat refleksi, dan semua
 * kegagalan ditelan supaya Recents tidak pernah crash karena view ini.
 */
public class TaskLabelView extends View {

    private static final HashMap<String, String> CACHE = new HashMap<String, String>();
    private static final long TICK_MS = 500L;

    private final TextPaint mPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mBtnPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mChevPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path mChevPath = new Path();
    private final float mDp;
    private boolean mDownOnBtn;
    private View mPanel;
    private Object mPanelTask;
    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            if (mPanel != null && currentTask() != mPanelTask) {
                collapse();
            }
            invalidate();
            if (isAttachedToWindow()) {
                postDelayed(this, TICK_MS);
            }
        }
    };

    public TaskLabelView(Context context) {
        this(context, null);
    }

    public TaskLabelView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TaskLabelView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        float sp = context.getResources().getDisplayMetrics().scaledDensity;
        mPaint.setTextSize(12f * sp);
        mPaint.setColor(0xFF14243A);
        try {
            mPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        } catch (Throwable t) {
            mPaint.setTypeface(Typeface.DEFAULT_BOLD);
        }
        mDp = context.getResources().getDisplayMetrics().density;
        mBtnPaint.setColor(0x1A14243A);
        mChevPaint.setColor(0xFF14243A);
        mChevPaint.setStyle(Paint.Style.STROKE);
        mChevPaint.setStrokeWidth(1.75f * mDp);
        mChevPaint.setStrokeCap(Paint.Cap.ROUND);
        mChevPaint.setStrokeJoin(Paint.Join.ROUND);
    }

    private int dp(float v) {
        return Math.round(v * mDp);
    }

    /** Daerah sentuh tombol dropdown: 44dp paling kanan. Sentuhan lain diteruskan ke kartu. */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        boolean in = e.getX() >= getWidth() - dp(44);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mDownOnBtn = in;
                return in;
            case MotionEvent.ACTION_UP:
                boolean fire = mDownOnBtn && in;
                boolean handled = mDownOnBtn;
                mDownOnBtn = false;
                if (fire) {
                    toggle();
                }
                return handled;
            case MotionEvent.ACTION_CANCEL:
                mDownOnBtn = false;
                return false;
            default:
                return mDownOnBtn;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(mTick);
        post(mTick);
        if (mPanel != null) {
            post(new Runnable() {
                @Override
                public void run() {
                    collapse();
                }
            });
        }
        try {
            BlurScrimDrawable.install(this);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        try {
            String label = resolveLabel();
            if (label == null || label.length() == 0) {
                return;
            }
            int left = getPaddingLeft();
            drawChevron(canvas);
            int avail = getWidth() - left - dp(40);
            if (avail <= 0) {
                return;
            }
            CharSequence text = TextUtils.ellipsize(label, mPaint, avail, TextUtils.TruncateAt.END);
            Paint.FontMetrics fm = mPaint.getFontMetrics();
            float baseline = (getHeight() - (fm.descent + fm.ascent)) / 2f;
            canvas.drawText(text, 0, text.length(), left, baseline, mPaint);
        } catch (Throwable ignored) {
        }
    }

    private void drawChevron(Canvas canvas) {
        float r = dp(11);
        float cx = getWidth() - dp(8) - r;
        float cy = getHeight() / 2f;
        canvas.drawCircle(cx, cy, r, mBtnPaint);
        float w = dp(4);
        float h = dp(2);
        float dir = mPanel != null ? -1f : 1f;
        mChevPath.reset();
        mChevPath.moveTo(cx - w, cy - h * dir);
        mChevPath.lineTo(cx, cy + h * dir);
        mChevPath.lineTo(cx + w, cy - h * dir);
        canvas.drawPath(mChevPath, mChevPaint);
    }

    private void toggle() {
        if (mPanel != null) {
            collapse();
        } else {
            expand();
        }
    }

    private void collapse() {
        try {
            View p = mPanel;
            mPanel = null;
            mPanelTask = null;
            if (p != null && p.getParent() instanceof ViewGroup) {
                ((ViewGroup) p.getParent()).removeView(p);
            }
        } catch (Throwable ignored) {
        }
        invalidate();
    }

    private void expand() {
        try {
            ViewParent vp = getParent();
            if (!(vp instanceof FrameLayout)) {
                openMenu();
                return;
            }
            FrameLayout taskView = (FrameLayout) vp;
            LinearLayout panel = buildPanel(taskView);
            if (panel == null || panel.getChildCount() == 0) {
                openMenu();
                return;
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.START);
            lp.setMargins(dp(9), getHeight() + dp(2), dp(9), 0);
            taskView.addView(panel, lp);
            mPanel = panel;
            mPanelTask = currentTask();
            invalidate();
        } catch (Throwable t) {
            openMenu();
        }
    }

    /** Baris opsi putih: ikon di atas teks, berjajar mendatar. */
    private LinearLayout buildPanel(FrameLayout taskView) throws Exception {
        ClassLoader cl = taskView.getClass().getClassLoader();
        Context ctx = getContext();

        Class<?> factoryCls = Class.forName("com.android.quickstep.TaskOverlayFactory", true, cl);
        Class<?> holderCls = Class.forName("com.android.launcher3.util.MainThreadInitializedObject", true, cl);
        Object holder = factoryCls.getField("INSTANCE").get(null);
        Object factory = find(holderCls, "get", 1).invoke(holder, ctx);
        List<?> shortcuts = (List<?>) find(factoryCls, "getEnabledShortcuts", 1).invoke(factory, taskView);

        Class<?> scCls = Class.forName("com.android.quickstep.TaskSystemShortcut", true, cl);
        Method getListener = find(scCls, "getOnClickListener", 2);
        Method setIconLabel = find(scCls, "setIconAndLabelFor", 2);
        Object activity = findActivity(cl, ctx);

        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setPadding(dp(4), dp(4), dp(4), dp(4));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFFFFFF);
        bg.setCornerRadius(dp(12));
        bg.setStroke(Math.max(1, dp(0.5f)), 0x1F000000);
        panel.setBackground(bg);
        panel.setClickable(true);

        for (Object sc : shortcuts) {
            final View.OnClickListener l =
                    (View.OnClickListener) getListener.invoke(sc, activity, taskView);
            if (l == null) {
                continue;
            }
            LinearLayout opt = new LinearLayout(ctx);
            opt.setOrientation(LinearLayout.VERTICAL);
            opt.setGravity(Gravity.CENTER_HORIZONTAL);
            opt.setPadding(dp(2), dp(8), dp(2), dp(8));
            opt.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), null,
                    new ColorDrawable(0xFFFFFFFF)));

            View icon = new View(ctx);
            TextView label = new TextView(ctx);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            label.setGravity(Gravity.CENTER_HORIZONTAL);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            setIconLabel.invoke(sc, icon, label);
            icon.setBackgroundTintList(ColorStateList.valueOf(0xFF5F6368));
            label.setTextColor(0xFF14243A);

            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(22), dp(22));
            opt.addView(icon, ilp);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.topMargin = dp(4);
            opt.addView(label, tlp);

            opt.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        l.onClick(v);
                    } catch (Throwable ignored) {
                    }
                    post(new Runnable() {
                        @Override
                        public void run() {
                            collapse();
                        }
                    });
                }
            });
            panel.addView(opt, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        return panel;
    }

    private static Method find(Class<?> c, String name, int params) throws NoSuchMethodException {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == params) {
                return m;
            }
        }
        throw new NoSuchMethodException(c.getName() + "." + name);
    }

    private Object findActivity(ClassLoader cl, Context ctx) {
        try {
            Class<?> ba = Class.forName("com.android.launcher3.BaseActivity", true, cl);
            return find(ba, "fromContext", 1).invoke(null, ctx);
        } catch (Throwable t) {
            Context c = ctx;
            while (c instanceof ContextWrapper) {
                if (c instanceof android.app.Activity) {
                    return c;
                }
                c = ((ContextWrapper) c).getBaseContext();
            }
            return null;
        }
    }

    private Object currentTask() {
        try {
            ViewParent p = getParent();
            return p == null ? null : p.getClass().getMethod("getTask").invoke(p);
        } catch (Throwable t) {
            return null;
        }
    }

    private void openMenu() {
        try {
            ViewParent p = getParent();
            if (p == null) {
                return;
            }
            Method m = p.getClass().getMethod("getIconView");
            Object icon = m.invoke(p);
            if (icon instanceof View) {
                ((View) icon).performClick();
            }
        } catch (Throwable ignored) {
        }
    }

    private String resolveLabel() {
        try {
            ViewParent p = getParent();
            if (p == null) {
                return null;
            }
            Method getTask = p.getClass().getMethod("getTask");
            Object task = getTask.invoke(p);
            if (task == null) {
                return null;
            }
            Field keyField = task.getClass().getField("key");
            Object key = keyField.get(task);
            if (key == null) {
                return fallbackTitle(task);
            }
            Field intentField = key.getClass().getField("baseIntent");
            Intent intent = (Intent) intentField.get(key);
            ComponentName cn = intent == null ? null : intent.getComponent();
            if (cn == null) {
                return fallbackTitle(task);
            }
            String id = cn.flattenToShortString();
            String cached = CACHE.get(id);
            if (cached != null) {
                return cached;
            }
            String label = loadLabel(cn);
            if (label == null || label.length() == 0) {
                label = fallbackTitle(task);
            }
            if (label != null && label.length() > 0) {
                CACHE.put(id, label);
            }
            return label;
        } catch (Throwable t) {
            return null;
        }
    }

    private String loadLabel(ComponentName cn) {
        try {
            PackageManager pm = getContext().getPackageManager();
            try {
                ActivityInfo ai = pm.getActivityInfo(cn, 0);
                CharSequence l = ai.loadLabel(pm);
                if (l != null && l.length() > 0) {
                    return l.toString();
                }
            } catch (Throwable ignored) {
            }
            ApplicationInfo app = pm.getApplicationInfo(cn.getPackageName(), 0);
            CharSequence l = pm.getApplicationLabel(app);
            return l == null ? null : l.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private String fallbackTitle(Object task) {
        try {
            Object t = task.getClass().getField("title").get(task);
            return t == null ? null : t.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
