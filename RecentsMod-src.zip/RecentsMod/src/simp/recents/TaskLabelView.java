package simp.recents;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * Label nama aplikasi di header kartu Recents (rata kiri, tanpa ikon).
 * Tidak memakai class hidden secara langsung: semua lewat refleksi, dan semua
 * kegagalan ditelan supaya Recents tidak pernah crash karena view ini.
 */
public class TaskLabelView extends View {

    private static final HashMap<String, String> CACHE = new HashMap<String, String>();
    private static final long TICK_MS = 500L;

    private final TextPaint mPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Runnable mTick = new Runnable() {
        @Override
        public void run() {
            invalidate();
            if (isAttachedToWindow()) {
                postDelayed(this, TICK_MS);
            }
        }
    };

    public TaskLabelView(Context context) {
        this(context, null);
    }

    public TaskLabelView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TaskLabelView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        float sp = context.getResources().getDisplayMetrics().scaledDensity;
        mPaint.setTextSize(12f * sp);
        mPaint.setColor(0xFF14243A);
        try {
            mPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        } catch (Throwable t) {
            mPaint.setTypeface(Typeface.DEFAULT_BOLD);
        }
        setClickable(true);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(mTick);
        post(mTick);
        try {
            BlurScrimDrawable.install(this);
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(mTick);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        try {
            String label = resolveLabel();
            if (label == null || label.length() == 0) {
                return;
            }
            int left = getPaddingLeft();
            int avail = getWidth() - left - getPaddingRight();
            if (avail <= 0) {
                return;
            }
            CharSequence text = TextUtils.ellipsize(label, mPaint, avail, TextUtils.TruncateAt.END);
            Paint.FontMetrics fm = mPaint.getFontMetrics();
            float baseline = (getHeight() - (fm.descent + fm.ascent)) / 2f;
            canvas.drawText(text, 0, text.length(), left, baseline, mPaint);
        } catch (Throwable ignored) {
        }
    }

    private void openMenu() {
        try {
            ViewParent p = getParent();
            if (p == null) {
                return;
            }
            Method m = p.getClass().getMethod("getIconView");
            Object icon = m.invoke(p);
            if (icon instanceof View) {
                ((View) icon).performClick();
            }
        } catch (Throwable ignored) {
        }
    }

    private String resolveLabel() {
        try {
            ViewParent p = getParent();
            if (p == null) {
                return null;
            }
            Method getTask = p.getClass().getMethod("getTask");
            Object task = getTask.invoke(p);
            if (task == null) {
                return null;
            }
            Field keyField = task.getClass().getField("key");
            Object key = keyField.get(task);
            if (key == null) {
                return fallbackTitle(task);
            }
            Field intentField = key.getClass().getField("baseIntent");
            Intent intent = (Intent) intentField.get(key);
            ComponentName cn = intent == null ? null : intent.getComponent();
            if (cn == null) {
                return fallbackTitle(task);
            }
            String id = cn.flattenToShortString();
            String cached = CACHE.get(id);
            if (cached != null) {
                return cached;
            }
            String label = loadLabel(cn);
            if (label == null || label.length() == 0) {
                label = fallbackTitle(task);
            }
            if (label != null && label.length() > 0) {
                CACHE.put(id, label);
            }
            return label;
        } catch (Throwable t) {
            return null;
        }
    }

    private String loadLabel(ComponentName cn) {
        try {
            PackageManager pm = getContext().getPackageManager();
            try {
                ActivityInfo ai = pm.getActivityInfo(cn, 0);
                CharSequence l = ai.loadLabel(pm);
                if (l != null && l.length() > 0) {
                    return l.toString();
                }
            } catch (Throwable ignored) {
            }
            ApplicationInfo app = pm.getApplicationInfo(cn.getPackageName(), 0);
            CharSequence l = pm.getApplicationLabel(app);
            return l == null ? null : l.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private String fallbackTitle(Object task) {
        try {
            Object t = task.getClass().getField("title").get(task);
            return t == null ? null : t.toString();
        } catch (Throwable t) {
            return null;
        }
    }
}
