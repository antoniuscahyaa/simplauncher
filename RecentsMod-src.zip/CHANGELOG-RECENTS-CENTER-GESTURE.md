# Recents center-card gesture fix

- Raised the visually centered TaskView substantially above neighboring cards using translationZ.
- Kept neighboring cards visible and behind the active card; no page count, task list, swipe controller, or dismiss animation logic was changed.
- Intended to make Android's overlapping-child hit testing route a swipe beginning on the centered card to that same TaskView.

## Verification
- Java source reviewed and ZIP integrity checked.
- Full Android APK compilation and device runtime test were not performed in this environment.
- Confirm on device by swiping up from the visible center card and checking that the same app card dismisses.
